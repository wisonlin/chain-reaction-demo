# 星渡 iOS 调试和自动化验收

这套流程验证原生 iPhone 和 iPad 版本的操作、资源与性能。游戏规则仍来自 `src/flight-game.js`；优化渲染和音效时必须保留规则一致性测试。

## 一条命令运行

在仓库根目录运行：

```sh
npm run test:native
```

需要 macOS、Xcode 及 iOS 26.3 Simulator、Node、XcodeGen、AXe。准备美术时使用已安装 Pillow 和 NumPy 的 Python，可通过 `STARBORNE_PYTHON` 指定。模拟器名称、机型、运行时间和性能预算在 `.asc/native-qa.json`；默认仅操作两个名为 `Starborne QA iPhone` 和 `Starborne QA iPad` 的专用模拟器。

入口脚本 `scripts/test-native-ios.py` 依次执行共享规则测试、诊断工具测试、资源准备、XcodeGen、两种设备的 XCTest 与 XCUITest，以及 Release 性能采样。任一步骤失败都会返回非零退出码，并保存日志和 `summary.json`，不得以“没有采到数据”作为通过。

结果默认保存在 `artifacts/native-qa/runs/<时间>/`。可指定独立输出目录：

```sh
npm run test:native -- --output artifacts/native-qa/my-run
npm run test:native -- --trace
```

`--trace` 会额外对正在运行的星渡进程进行有时间限制的 Time Profiler 采样，不录制其他应用。

## 检查范围

| 层次 | 验证内容 |
| --- | --- |
| JavaScript 共享规则 | 六角色 × 两难度的原生适配器与浏览器核心逐步一致；移动、大招、三关顺序；v4 授权的回血、六级火力、补给与难度曲线 |
| 原生单测 | 两首完整音乐、变体音效资源；JavaScriptCore 载入；双击只消耗一次大招；暂停冻结；屏幕尺寸变化保留资源；六角色三档全身立绘及飞行姿态完整；音效提交不阻塞一帧 |
| iPhone 和 iPad UI | 大字号生命/火力显示、大招触达尺寸、独立音乐开关；六位旅人选择、困难模式、三档立绘打开关闭、单指拖动、双击大招、暂停恢复、切后台自动暂停、三次重开复用同一个场景 |
| Release 性能 | 音乐与音效同时开启的霁弦激光、青翎困难追踪；另有 6 级散射/追踪从第三关后段开局的压力场景。种子 42，排除两秒预热，压力场景无新增生命或无敌，可能正常失败 |

UI 截图作为 XCTest 附件保留，可通过 `xcresulttool export attachments` 导出。性能场景通过仅模拟器可用的启动参数自动开始，避免依赖 XCTest 结束后暂不可用的辅助功能传输；真实点击和拖动仍由 XCUITest 独立验证。AXe 用于原始截图，该截图自动化工具链仍按实验性质对待，最终状态由 XCTest 断言和诊断数据核对。

## 性能数据如何解释

模拟器启动参数 `--native-qa` 会显示 FPS、节点数和绘制次数，并将帧间隔、逻辑处理、事件处理、渲染、观察者通知耗时写入应用沙盒的 `Documents/native-qa.json`。诊断模式在物理设备构建中不能启用。正常玩法不使用测试随机种子。

预算由 `scripts/check-native-performance.py` 检查：至少 300 个有效战斗样本，帧间隔 P95 不超过 25 ms，逻辑和渲染 P95 各不超过 8 ms，事件处理 P95 不超过 2 ms，节点数不超过 1000，超过 50 ms 的慢帧占比不超过 1%。这些是当前模拟器环境的回归阈值，不是所有 iPhone 的帧率承诺。

可以单独对已经编译的 Release 模拟器应用采样：

```sh
python3 scripts/profile-native-ios.py \
  --udid <专用模拟器UDID> \
  --app <Release-iphonesimulator/Starborne.app> \
  --output artifacts/native-qa/profile \
  --character lune --duration 14 --trace
python3 scripts/check-native-performance.py artifacts/native-qa/profile/frames.json
```

使用 `--muted` 做关声音对照，使用 `--character aster --hard` 检查追踪弹场景。每次比较保持设备、Release 配置、声音设置、种子和输入一致；采集性能时不要同时编译或录屏。

## 2026 年 10 月 24 日卡顿记录

同一场景的 Release 模拟器对照中，原实现开声音的帧间隔 P95 为 45.81 ms，关声音后为 16.67 ms。拆分计时发现事件处理 P95 为 26.01 ms，而渲染 P95 仅约 0.67 ms；Time Profiler 调用栈中出现主线程的 `NativeAudio.play`。

原实现每次在游戏线程调用 `AVAudioPlayer.currentTime` 和 `play`，并在第一次播放时读取和建立播放器。修复为一个持久的 `AVAudioEngine`、预解码 PCM 缓冲和有限的复用声部，在串行音频队列调度。相同开声音场景的帧间隔 P95 降为 16.67 ms，事件处理 P95 降为 0.05 ms。原始对照摘要保存在 `qa/audio-regression-baseline.json`，共享规则未修改。

这证明并修复了模拟器上这一处主线程停顿，不能证明所有实机卡顿都已消失。后续在真机检查 GPU、温度、能耗和长时间运行；不要只凭一次模拟器截图或“编译成功”宣布性能验收通过。

## 调用栈解析与资料保留

```sh
xcrun xctrace export --input <cpu.trace> \
  --xpath '/trace-toc/run/data/table[@schema="time-profile"]' \
  --output <profile.xml>
python3 scripts/analyze-native-trace.py <profile.xml> --output <cpu-summary.json>
```

解析器处理 XML 的 `id/ref` 引用并分别统计应用和主线程栈，避免直接搜索 XML 导致漏算。包含占比会重叠，不能相加。没有录到的 GPU 或实机指标会明确标为未测量。

`artifacts/` 中的原始日志、trace、签名和联系人资料不进入源码。公开报告仅发布明确列出的截图、摘要和操作视频；禁止递归上传整个 artifacts 文件夹。手机交付使用已验证的公网 HTTPS 链接，不使用 localhost 或本地文件地址。

## v4 质量设计记录

完整决策与素材授权见 `../design/game-quality-v4.md`。长音乐使用 AVAudioPlayer 从本地压缩文件播放；短音继续走缓存 PCM 和音频队列。性能验收必须同时开音乐和音效，额外的高火力场景通过 `--power 6 --stage 2` 启动。不得把模拟器压力测试预设用于真机发行版本。

## 共鸣之旅 2.0 / Web 5.0

新增自动支援、三种元素反应、守卫护甲、三选一祝福、本机角色成长与常驻试炼。新增规则测试覆盖固定种子、合法选择、冻结恢复、奖励去重及六角色长场景终态；原生新增两项单测、两项界面测试，两种设备分别执行。

`--qa-draft true` 仅在专用模拟器中打开测试祝福，不推进关卡时间。测试应先消费事件，再比较冻结状态，避免把事件队列正常出队误判为逻辑运动。模拟器自动开始性能采样时自动选牌，正常玩法等待手指选择。

性能保留 `legacy-laser-audio` 对照：Release、种子 42、霁弦、默认火力、开声音、不启用新策略；与 v4 相同场景比较。其他场景启用新策略，六级火力后段场景分别测试夜珩破甲与岚珀护盾支援。`--legacy` 和 `--support` 参数已纳入采样脚本。物理设备不会接受 QA 参数。

失败时同样导出 xcresult 附件和摘要，保留原失败目录，修复后使用新输出目录。NavigationStack 的标题与工具栏必须挂在内部内容视图，自动化实际点击关闭按钮验证可退出。

## 祈星远航 3.0 / Web 6.0

养成与抽取共用 `collection.js`，profile schema 2 在保留旧进度的同时添加本机背包。新增检查保底跨重启、精炼保护、材料原子扣除、命座与突破上限、试炼忽略养成、衣装不加属性和实际射弹效果。原生工作坊 UI 测试会消耗免费券、升级角色及武器、穿衣装，再重启核对进度。

仅 QA 模拟器接受 `--qa-fresh-camp true` 用于隔离测试存档；`--qa-camp-max true` 准备 Lv.60 / C6 / R5 专武及新衣装压力场景。物理设备不接受这些参数。性能用例新增 `max-collection-audio`；每次 XCTest 完成后停止该 QA 模拟器游戏进程，避免另一个模拟器后台战斗干扰测量。

序列化去重测试同时核对字段顺序，避免把结构相同但键顺序不同的本机记录误判为二次结算。保留失败日志、附件及修复后的独立运行目录。
