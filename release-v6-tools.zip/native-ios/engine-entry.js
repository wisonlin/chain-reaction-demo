import {WEAPONS,SKINS} from '../src/collection-data.js';
import {campAction} from '../src/collection.js';
import {normalizeProgress,settleProgress} from '../src/flight-progress.js';
import {TRIALS} from '../src/flight-expedition-data.js';
import {VerticalShooter} from '../src/flight-game.js';
import {FLIGHT_CHARACTERS} from '../src/flight-characters.js';
import {HeroMotion} from '../src/hero-motion.js';
import {SingleThumbInput} from '../src/single-thumb-input.js';

function seeded(seed){return ()=>((seed=(seed*1664525+1013904223)>>>0)/4294967296);}
let game=new VerticalShooter(),motion=new HeroMotion(),thumb=new SingleThumbInput(),accumulator=0,character='lune';
const api={
  reset(options){const trial=options.strategy&&TRIALS.find(t=>t.id===options.trial);character=trial?trial.main:FLIGHT_CHARACTERS[options.character]?options.character:'lune';game=new VerticalShooter(options.seed===undefined?Math.random:seeded(options.seed),{height:options.height||850});game.reset({...options,camp:options.campRaw?normalizeProgress(options.campRaw).camp:options.camp,character,weapon:FLIGHT_CHARACTERS[character].weapon,hard:!!options.hard});motion.reset();thumb.reset();accumulator=0;return api.frame();},
  ready(options){api.reset(options);game.state='ready';game.events=[];return api.frame();},
  benchmark(options){if(options.draft){game.strategy?.offer();return api.frame()}game.enterStage(Math.max(0,Math.min(2,options.stage||0)));game.stageTime=game.stage.duration*.65;game.player.power=Math.max(1,Math.min(6,options.power||1));if(options.draft)game.strategy?.offer();if(options.finish)game.finish(false);return api.frame();},
  choose(id){thumb.reset();accumulator=0;return game.strategy?.choose(id)||false;},
  profile(raw){return JSON.stringify(normalizeProgress(raw));},
  qaProfile(raw){const p=normalizeProgress(raw);for(const a of Object.values(p.camp.actors))Object.assign(a,{level:60,ascension:2,constellation:6});for(const w of p.camp.weapons)Object.assign(w,{level:60,ascension:2,refine:5});for(const d of WEAPONS.filter(w=>w.rarity===5)){const w={id:'w'+p.camp.nextWeapon++,base:d.id,level:60,ascension:2,refine:5};p.camp.weapons.push(w);p.camp.actors[d.owner].weapon=w.id;}p.camp.skins=SKINS.map(s=>s.id);for(const s of SKINS)p.camp.actors[s.hero].skin=s.id;return JSON.stringify(p)},
  camp(raw,action){const p=normalizeProgress(raw),r=campAction(p.camp,action);p.camp=r.camp;return JSON.stringify({profile:p,ok:r.ok,message:r.message,draws:r.draws})},
  settle(raw){return JSON.stringify(game.state==='over'&&game.strategy?settleProgress(raw,game.strategy.result()):normalizeProgress(raw));},
  resize(height){game.resize(height);thumb.reset();return api.frame();},
  pause(){thumb.reset();accumulator=0;return game.pause();},
  resume(){thumb.reset();accumulator=0;return game.resume();},
  bomb(){return game.useBomb();},
  touchBegin(x,y,time){return thumb.begin(1,x,y,time);},
  touchMove(x,y){thumb.move(1,x,y);},
  touchEnd(x,y,time){return thumb.end(1,x,y,time);},
  cancelTouch(){thumb.reset();},
  step(dt,input){
    dt=Math.max(0,Math.min(.08,dt));
    if(game.state==='playing'){
      accumulator+=dt;
      while(accumulator>=1/120&&game.state==='playing'){game.update(1/120,input||{});accumulator-=1/120;}
    }else accumulator=0;
    const events=game.events.splice(0);for(const event of events)motion.emit(event);
    motion.step(game.player,dt,{paused:['paused','draft'].includes(game.state)});
    return api.frame(events);
  },
  frame(events=[]){
    const p=game.player;
    return JSON.stringify({state:game.state,character,expedition:game.strategy?.snapshot()||null,hard:game.hard,worldHeight:game.world.height,elapsed:game.elapsed,scroll:game.scroll,score:game.score,tension:game.tension,grazes:game.grazes,maxTension:game.maxTension,threatLevel:game.threatLevel,breather:game.breather,stageIndex:game.stageIndex,phase:game.phase,progress:game.progress,stage:game.stage,won:!!game.won,player:p,shake:game.shake,bombCooldown:game.bombCooldown,bombTime:game.bombTime,motion:motion.frame(),enemies:game.enemies,bullets:game.bullets,shots:game.shots,pickups:game.pickups,hazards:game.hazards,laser:game.laser,spirit:game.spirit,events});
  },
  debugState(){return JSON.stringify(game);}
};
globalThis.NativeStarborne=api;
