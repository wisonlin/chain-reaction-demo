import XCTest

final class StarborneUITests:XCTestCase {
    private var app:XCUIApplication!
    override func setUpWithError() throws {
        continueAfterFailure=false
        app=XCUIApplication()
        app.launchArguments=["--native-qa","--qa-character","lune","--qa-muted","true","--qa-duration","45","--qa-fresh-camp","true"]
        app.launch()
        XCTAssertTrue(app.buttons["primary-action"].waitForExistence(timeout:10))
    }
    private func state()throws->[String:Any] {
        let probe=app.staticTexts["qa-state"]
        guard probe.exists,let value=probe.value as? String,let data=value.data(using:.utf8),let state=try JSONSerialization.jsonObject(with:data) as? [String:Any] else{throw NSError(domain:"StarborneUITests",code:1,userInfo:[NSLocalizedDescriptionKey:"QA state unavailable during view transition"])}
        return state
    }
    private func wait(_ condition:@escaping()->Bool,file:StaticString=#filePath,line:UInt=#line){
        let predicate=NSPredicate{_,_ in condition()}
        XCTAssertEqual(XCTWaiter.wait(for:[XCTNSPredicateExpectation(predicate:predicate,object:nil)],timeout:5),.completed,file:file,line:line)
    }
    private func attach(_ name:String){Thread.sleep(forTimeInterval:0.35);let a=XCTAttachment(screenshot:app.screenshot());a.name=name;a.lifetime = .keepAlways;add(a)}
    func testSixTravellersAndThreeHealthPortraits()throws {
        for name in ["岚珀","霁弦","澜歌","绯穗","夜珩","青翎"] {
            app.buttons["选择\(name)"].tap()
        }
        XCTAssertEqual(try state()["character"] as? String,"aster")
        app.buttons["open-gallery"].tap()
        XCTAssertTrue(app.buttons["关闭立绘"].waitForExistence(timeout:3))
        for label in ["满血 · 从容","负伤 · 破损","濒危 · 战损"] {app.buttons[label].tap();attach(label)}
        app.buttons["关闭立绘"].tap()
        XCTAssertTrue(app.buttons["primary-action"].waitForExistence(timeout:3))
        app.buttons["深空试炼"].tap()
        XCTAssertEqual(try state()["hard"] as? Bool,true)
        attach("roster")
    }
    func testSingleThumbMovementDoubleTapAndPause()throws {
        app.buttons["primary-action"].tap()
        let before=try state(),initialX=try XCTUnwrap(before["x"] as? Double)
        let from=app.coordinate(withNormalizedOffset:CGVector(dx:0.5,dy:0.72))
        let to=app.coordinate(withNormalizedOffset:CGVector(dx:0.25,dy:0.66))
        from.press(forDuration:0.05,thenDragTo:to)
        wait{(try? self.state()["x"] as? Double).flatMap{$0}.map{$0<initialX-60} ?? false}
        app.coordinate(withNormalizedOffset:CGVector(dx:0.5,dy:0.7)).doubleTap()
        wait{(try? self.state()["bombs"] as? Int)==1}
        attach("double-tap-ultimate")
        app.buttons["暂停游戏"].tap()
        wait{(try? self.state()["state"] as? String)=="paused"}
        let paused=try XCTUnwrap(state()["elapsed"] as? Double)
        Thread.sleep(forTimeInterval:1.2)
        XCTAssertEqual(try state()["elapsed"] as? Double,paused)
        app.buttons["primary-action"].tap()
        wait{(try? self.state()["elapsed"] as? Double).flatMap{$0}.map{$0>paused} ?? false}
        XCUIDevice.shared.press(.home);app.activate()
        wait{(try? self.state()["state"] as? String)=="paused"}
        attach("background-paused")
    }
    func testReadableCombatHUDAndIndependentMusicControl()throws {
        app.buttons["primary-action"].tap()
        let ultimate=app.buttons["ultimate-button"]
        XCTAssertTrue(ultimate.waitForExistence(timeout:4));XCTAssertGreaterThanOrEqual(ultimate.frame.width,80)
        XCTAssertGreaterThanOrEqual(app.buttons["暂停游戏"].frame.width,44)
        let health=app.descendants(matching:.any)["health-status"],power=app.descendants(matching:.any)["power-status"]
        XCTAssertTrue(health.exists);XCTAssertTrue(health.label.contains("生命 3/3"));XCTAssertGreaterThanOrEqual(health.frame.height,18)
        XCTAssertTrue(power.exists);XCTAssertTrue(power.label.contains("/6"))
        XCTAssertTrue(app.buttons["开启音乐"].exists);app.buttons["开启音乐"].tap()
        wait{(try? self.state()["musicMuted"] as? Bool)==false}
        XCTAssertTrue(app.buttons["关闭音乐"].exists);XCTAssertTrue(app.buttons["开启音效"].exists)
        attach("readable-hud")
    }
    func testSupportJournalAndPermanentTrials()throws {
        app.buttons["支援岚珀"].tap()
        XCTAssertEqual(try state()["support"] as? String,"ember")
        app.buttons["open-journal"].tap()
        XCTAssertTrue(app.buttons["关闭手记"].waitForExistence(timeout:3));attach("journal")
        app.buttons["关闭手记"].tap()
        if !app.buttons["open-trials"].isHittable{app.swipeUp()}
        app.buttons["open-trials"].tap()
        XCTAssertTrue(app.buttons["trial-circuit"].waitForExistence(timeout:3));attach("trials")
        app.buttons["trial-circuit"].tap()
        wait{(try? self.state()["state"] as? String)=="playing"}
        XCTAssertEqual(try state()["trial"] as? String,"circuit")
        XCTAssertEqual(try state()["support"] as? String,"nerine")
    }
    func testBlessingChoiceFreezesAndResumesWithOneTap()throws {
        app.terminate();app.launchArguments += ["--qa-draft","true"];app.launch()
        app.buttons["primary-action"].tap()
        wait{(try? self.state()["state"] as? String)=="draft"}
        let before=try state(),elapsed=before["elapsed"] as? Double
        Thread.sleep(forTimeInterval:1)
        XCTAssertEqual(try state()["elapsed"] as? Double,elapsed)
        let cards=app.buttons.matching(NSPredicate(format:"identifier BEGINSWITH %@","blessing-"))
        XCTAssertEqual(cards.count,3);XCTAssertGreaterThanOrEqual(cards.element(boundBy:0).frame.height,126)
        attach("blessing-draft");cards.element(boundBy:0).tap()
        wait{(try? self.state()["state"] as? String)=="playing"}
        XCTAssertEqual(try state()["choices"] as? Int,1)
        attach("blessing-chosen")
    }
    func testOfflineWishesUpgradesAndSkinPersist()throws {
        app.buttons["open-workshop"].tap()
        XCTAssertTrue(app.buttons["wish-ten"].waitForExistence(timeout:4));attach("wish-banner")
        app.buttons["wish-ten"].tap()
        XCTAssertTrue(app.buttons["wish-result-close"].waitForExistence(timeout:4));attach("wish-results")
        if !app.buttons["wish-result-close"].isHittable{app.swipeUp()};app.buttons["wish-result-close"].tap()
        app.buttons["camp-tab-旅人"].tap();app.buttons["养成霁弦"].tap()
        app.buttons["hero-level"].tap();attach("hero-growth")
        app.buttons["camp-tab-武器"].tap();app.buttons["weapon-level"].tap();attach("weapon-growth")
        app.buttons["camp-tab-命座"].tap();attach("constellations")
        app.buttons["camp-tab-衣装"].tap()
        if !app.buttons["skin-moonlit"].isHittable{app.swipeUp()};app.buttons["skin-moonlit"].tap();attach("skin-equipped")
        app.buttons["camp-close"].tap()
        XCTAssertEqual(try state()["tickets"] as? Int,20);XCTAssertEqual(try state()["campLevel"] as? Int,2);XCTAssertEqual(try state()["weaponLevel"] as? Int,2);XCTAssertEqual(try state()["skin"] as? String,"moonlit")
        app.terminate();app.launchArguments.removeAll{$0=="--qa-fresh-camp"};if let i=app.launchArguments.lastIndex(of:"true"){app.launchArguments.remove(at:i)};app.launch()
        XCTAssertTrue(app.buttons["primary-action"].waitForExistence(timeout:8));XCTAssertEqual(try state()["campLevel"] as? Int,2);XCTAssertEqual(try state()["tickets"] as? Int,20);XCTAssertEqual(try state()["skin"] as? String,"moonlit")
    }
    func testRestartKeepsOneSceneAndResetsResources()throws {
        let scene=try state()["sceneID"] as? String
        for _ in 0..<3 {
            app.buttons["primary-action"].tap()
            XCTAssertEqual(try state()["bombs"] as? Int,2)
            app.buttons["暂停游戏"].tap()
            app.buttons["返回云海"].tap()
            wait{(try? self.state()["state"] as? String)=="ready"}
            XCTAssertEqual(try state()["sceneID"] as? String,scene)
        }
    }
}
