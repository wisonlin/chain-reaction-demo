import SwiftUI
private let cwGold=Color(hex:"ecd4a0"),cwText=Color(hex:"edf0e9"),cwMist=Color(hex:"b7d0de"),cwPanel=Color(hex:"1b3b52")
struct CollectionWorkshop:View {
 @ObservedObject var game:GameStore
 @Environment(\.dismiss) private var dismiss
 @State private var tab="祈星"
 @State private var pool="character"
 @State private var focusedWeapon=""
 private let tabs=["祈星","旅人","武器","命座","衣装","背包"]
 private var camp:CampState?{game.progress.camp}
 private var chosenWeapon:CampWeapon?{camp?.weapons.first{$0.id==(focusedWeapon.isEmpty ? game.actor.weapon:focusedWeapon)}}
 var body:some View{
  NavigationStack{
   ZStack{
    Color(hex:"102b3e").ignoresSafeArea()
    VStack(spacing:0){
     ScrollView(.horizontal){HStack(spacing:8){ForEach(tabs,id:\.self){name in Button{tab=name;game.wishResults=[]}label:{Text(name).font(.system(size:16,weight:.semibold)).foregroundStyle(tab==name ? Color(hex:"243e50"):cwMist).frame(width:62,height:44).background(tab==name ? cwGold:cwPanel,in:RoundedRectangle(cornerRadius:8))}.buttonStyle(.plain).accessibilityIdentifier("camp-tab-\(name)")}}.padding(.horizontal,16)}.scrollIndicators(.hidden).padding(.vertical,12)
     ScrollView{
      VStack(alignment:.leading,spacing:17){
       HStack{Text("◈ \(camp?.wallet["coins"] ?? 0)");Spacer();Text("✧ \(camp?.wallet["tickets"] ?? 0) 祈星券");Spacer();Text("❖ \(camp?.wallet["threads"] ?? 0)")}.font(.system(size:14,weight:.semibold)).foregroundStyle(cwGold)
       if !game.campMessage.isEmpty{Text(game.campMessage).font(.system(size:15,weight:.medium)).foregroundStyle(cwGold).accessibilityIdentifier("camp-message")}
       if !["祈星","背包"].contains(tab){roster}
       if tab=="祈星"{wishing}else if tab=="旅人"{hero}else if tab=="武器"{weapons}else if tab=="命座"{constellation}else if tab=="衣装"{skins}else{backpack}
      }.padding(18).padding(.bottom,25)
     }.scrollIndicators(.hidden)
    }
    if !game.wishResults.isEmpty{WishReveal(game:game)}
   }.navigationTitle("祈星与养成").navigationBarTitleDisplayMode(.inline).toolbar{ToolbarItem(placement:.topBarTrailing){Button("关闭"){dismiss()}.accessibilityIdentifier("camp-close")}}
  }.preferredColorScheme(.dark)
 }
 private var roster:some View{
  ScrollView(.horizontal){HStack(spacing:10){ForEach(game.travellers){t in Button{game.select(t.id);focusedWeapon=""}label:{VStack(spacing:5){Image(uiImage:UIImage(named:"\(t.id)-face") ?? UIImage()).resizable().scaledToFill().frame(width:47,height:47).clipShape(Circle());Text(t.name).font(.system(size:14));Text(String(repeating:"★",count:game.collection.rarity[t.id] ?? 4)).font(.system(size:9))}.foregroundStyle(game.selected==t.id ? cwGold:cwMist).padding(7).background(game.selected==t.id ? cwPanel:.clear,in:RoundedRectangle(cornerRadius:9))}.buttonStyle(.plain).accessibilityLabel("养成\(t.name)")}}}.scrollIndicators(.hidden)
 }
 private func action(_ title:String,id:String="",disabled:Bool=false,_ payload:[String:Any])->some View{
  Button{game.campAction(payload)}label:{Text(title).contentTransition(.identity).font(.system(size:16,weight:.semibold)).frame(maxWidth:.infinity,minHeight:48).padding(.horizontal,8).foregroundStyle(disabled ? cwMist:Color(hex:"253f50")).background(disabled ? cwPanel:cwGold,in:RoundedRectangle(cornerRadius:9))}.buttonStyle(.plain).disabled(disabled).accessibilityIdentifier(id).transaction{$0.disablesAnimations=true}
 }
 private func heading(_ title:String,_ detail:String)->some View{VStack(alignment:.leading,spacing:8){Text(title).font(.system(size:27,weight:.medium,design:.serif)).foregroundStyle(cwText);Text(detail).font(.system(size:15)).foregroundStyle(cwMist).lineSpacing(4)}}
 private func weaponArt(_ w:WeaponDefinition?,size:CGFloat=100)->some View{Image(uiImage:UIImage(named:"weapon-\(w?.id ?? "compass")") ?? UIImage()).resizable().scaledToFit().frame(width:size,height:size).clipShape(RoundedRectangle(cornerRadius:12))}
 private var wishing:some View{
  VStack(alignment:.leading,spacing:16){
   Picker("卡池",selection:$pool){Text("旅人祈星").tag("character");Text("武器祈星").tag("weapon")}.pickerStyle(.segmented).accessibilityIdentifier("wish-pool")
   let pity=camp?.pity[pool],target=pity?.target ?? (pool=="character" ? "ember":"daybreak")
   HStack(spacing:16){
    if pool=="character"{Image(uiImage:UIImage(named:game.artName(target,"healthy")) ?? UIImage()).resizable().scaledToFit().frame(width:125,height:230)}else{weaponArt(game.collection.weapon(target),size:135)}
    VStack(alignment:.leading,spacing:10){Text("★★★★★").foregroundStyle(cwGold);Text(pool=="character" ? game.travellers.first{$0.id==target}?.name ?? "":game.collection.weapon(target)?.name ?? "").font(.system(size:27,weight:.medium,design:.serif));Text("定轨目标").font(.system(size:14));Text(pity?.guaranteed==true ? "下一次五星必为定轨目标":"五星有 50% 为定轨目标，未命中后下一次必定命中").font(.system(size:14)).foregroundStyle(cwMist)}.foregroundStyle(cwText)
   }.frame(maxWidth:.infinity).padding(13).background(LinearGradient(colors:[Color(hex:"5d5162"),cwPanel],startPoint:.topLeading,endPoint:.bottomTrailing),in:RoundedRectangle(cornerRadius:14))
   Menu{if pool=="character"{ForEach(game.travellers.filter{game.collection.rarity[$0.id]==5}){t in Button(t.name){game.campAction(["type":"target","pool":pool,"target":t.id])}}}else{ForEach(game.collection.weapons.filter{$0.rarity==5}){w in Button(w.name){game.campAction(["type":"target","pool":pool,"target":w.id])}}}}label:{Label("更换定轨目标 · 保底不清零",systemImage:"scope").font(.system(size:15)).foregroundStyle(cwGold).frame(minHeight:44)}
   Text("已累计 \(pity?.count ?? 0)/30 抽 · 两池分别累计").font(.system(size:17,weight:.semibold)).foregroundStyle(cwGold)
   ProgressView(value:Double(pity?.count ?? 0),total:30).tint(cwGold)
   HStack(spacing:12){action("祈星一次 · 1 券",id:"wish-one",disabled:(camp?.wallet["tickets"] ?? 0)<1,["type":"wish","pool":pool,"count":1]);action("祈星十次 · 10 券",id:"wish-ten",disabled:(camp?.wallet["tickets"] ?? 0)<10,["type":"wish","pool":pool,"count":10])}
   heading("永久常驻，无需等待","初始五星概率 5%；从第 21 抽起每抽增加 10 个百分点，第 30 抽必出五星。所有结果至少四星。抽到五星后次数清零，未命中定轨时下次五星必定命中。切换目标保留保底。")
   Text("六位旅人均已加入；重复角色获得命星，用于主动点亮命座。未培养的同名武器可用于精炼。祈星券只从游戏内获得，不提供付费购买。").font(.system(size:15)).foregroundStyle(cwMist)
   ForEach(Array((camp?.history.suffix(8).reversed() ?? []).enumerated()),id:\.offset){_,r in Text("\(String(repeating:"★",count:r.rarity))  \(r.kind=="hero" ? game.travellers.first{$0.id==r.item}?.name ?? "":game.collection.weapon(r.item)?.name ?? "") · \(r.kind=="hero" ? "命星 / 满命转材料":"武器入库")").font(.system(size:14)).foregroundStyle(r.rarity==5 ? cwGold:cwMist)}
  }
 }
 private var hero:some View{
  VStack(alignment:.leading,spacing:15){
   HStack{Image(uiImage:UIImage(named:game.artName(game.selected,"healthy")) ?? UIImage()).resizable().scaledToFit().frame(width:140,height:260);VStack(alignment:.leading,spacing:10){Text(String(repeating:"★",count:game.collection.rarity[game.selected] ?? 4)).foregroundStyle(cwGold);heading(game.traveller?.name ?? "","Lv.\(game.actor.level) / \(game.actor.cap) · 命座 C\(game.actor.constellation)");Text("自身等级伤害 +\(Int((Double(game.actor.level)-1)*0.3))%").font(.system(size:15)).foregroundStyle(cwMist)}}
   action("升级 · \(70+game.actor.level*8) 币 + \(1+game.actor.level/15) 札记",id:"hero-level",disabled:game.actor.level>=game.actor.cap,["type":"levelHero","hero":game.selected])
   action("突破 · \(400*(game.actor.ascension+1)) 币 + \(2*(game.actor.ascension+1)) 元素印",id:"hero-ascend",disabled:game.actor.level<game.actor.cap || game.actor.ascension>=2,["type":"ascendHero","hero":game.selected])
   heading("升级与突破","20 / 40 级突破，最高 60 级。角色消耗旅人札记，突破消耗对应元素印；主战和支援的养成都有作用。熟练与手记进度继续保留。")
   Text("札记 \(camp?.wallet["books"] ?? 0) · 辉晶印 \(camp?.wallet["crystal"] ?? 0) · 雷羽印 \(camp?.wallet["thunder"] ?? 0) · 潮汐印 \(camp?.wallet["tide"] ?? 0)").font(.system(size:15)).foregroundStyle(cwGold)
  }
 }
 private var weapons:some View{
  VStack(alignment:.leading,spacing:15){
   heading("武器工坊","适配 \(game.collection.kinds[game.traveller?.weapon ?? ""] ?? "") · 同一把武器由一位旅人持有。装备已被持有的武器会交换双方武器。")
   if let w=chosenWeapon,let d=game.collection.weapon(w.base){
    HStack(spacing:13){weaponArt(d,size:100);VStack(alignment:.leading,spacing:7){Text(String(repeating:"★",count:d.rarity)).foregroundStyle(cwGold);Text(d.name).font(.system(size:23,weight:.semibold,design:.serif)).foregroundStyle(cwText);Text("Lv.\(w.level)/\(w.cap) · 精炼 R\(w.refine)").font(.system(size:16)).foregroundStyle(cwGold)}}
    Text(d.detail).font(.system(size:16)).foregroundStyle(cwMist)
    if !d.owner.isEmpty{Text("专属旅人：\(game.travellers.first{$0.id==d.owner}?.name ?? "") · 其他适配旅人可装备，专属效果需本人触发").font(.system(size:14)).foregroundStyle(cwGold)}
    action(game.actor.weapon==w.id ? "当前已装备":"装备给\(game.traveller?.name ?? "")",id:"weapon-equip",disabled:game.actor.weapon==w.id,["type":"equip","hero":game.selected,"weapon":w.id])
    action("升级 · \(60+w.level*7) 币 + \(1+w.level/15) 锻星矿",id:"weapon-level",disabled:w.level>=w.cap,["type":"levelWeapon","weapon":w.id])
    HStack{action("突破上限",id:"weapon-ascend",disabled:w.level<w.cap || w.ascension>=2,["type":"ascendWeapon","weapon":w.id]);action("精炼 · 同名武器",id:"weapon-refine",disabled:w.refine>=5,["type":"refine","weapon":w.id])}
   }
   LazyVGrid(columns:[GridItem(.flexible()),GridItem(.flexible())],spacing:10){ForEach(camp?.weapons.filter{game.collection.weapon($0.base)?.kind==game.traveller?.weapon} ?? []){w in let d=game.collection.weapon(w.base)
    Button{focusedWeapon=w.id}label:{VStack(spacing:6){weaponArt(d,size:90);Text(d?.name ?? "").font(.system(size:16,weight:.medium));Text("\(String(repeating:"★",count:d?.rarity ?? 4)) · Lv.\(w.level) R\(w.refine)").font(.system(size:12))}.foregroundStyle(cwGold).frame(maxWidth:.infinity).padding(12).background(cwPanel,in:RoundedRectangle(cornerRadius:10)).overlay(RoundedRectangle(cornerRadius:10).stroke(chosenWeapon?.id==w.id ? cwGold:.clear))}.buttonStyle(.plain).accessibilityLabel("武器\(d?.name ?? "")，\(w.id)")
   }}
   Text("突破消耗 400 / 800 币与 2 / 4 个对应元素印。精炼只消耗未装备、未升级、未精炼的同名武器，最高 R5；不会自动吞掉培养过的武器。").font(.system(size:14)).foregroundStyle(cwMist)
  }
 }
 private var constellation:some View{
  VStack(alignment:.leading,spacing:14){
   heading("\(game.traveller?.name ?? "") · 命座 C\(game.actor.constellation)","现有命星 \(game.actor.shards) · 每阶消耗一个同名命星，最高 C6。")
   ForEach(0..<6,id:\.self){i in HStack(spacing:14){Text("✦").font(.system(size:31)).foregroundStyle(game.actor.constellation>i ? cwGold:cwMist.opacity(0.35)).frame(width:44);VStack(alignment:.leading,spacing:7){Text("C\(i+1) · \(game.collection.constellations[i].name)").font(.system(size:19,weight:.semibold));Text(i==5 ? game.collection.c6[game.selected] ?? "":game.collection.constellations[i].text).font(.system(size:15)).foregroundStyle(cwMist)};Spacer()}.foregroundStyle(cwText).padding(15).frame(minHeight:96).background(cwPanel,in:RoundedRectangle(cornerRadius:12))}
   action("点亮下一阶命座",id:"constellation-unlock",disabled:game.actor.constellation>=6 || game.actor.shards<1,["type":"constellation","hero":game.selected])
   Text("满命且命星已足够时，再获得同名角色会转为札记、锻星矿与织梦丝。固定试炼不使用养成加成。").font(.system(size:14)).foregroundStyle(cwMist)
  }
 }
 private var skins:some View{
  VStack(alignment:.leading,spacing:16){
   heading("衣装馆","服装只改变外观，不增加伤害。立绘、大招与飞行姿态同步更换，保留三档血量表现。")
   action("使用原始衣装",id:"skin-base",disabled:game.actor.skin=="base",["type":"skin","hero":game.selected,"skin":"base"])
   ForEach(game.collection.skins.filter{$0.hero==game.selected}){s in
    Image(uiImage:UIImage(named:"skin-\(s.id)-healthy") ?? UIImage()).resizable().scaledToFit().frame(maxWidth:.infinity).frame(height:330)
    heading(s.name,s.detail)
    action(game.actor.skin==s.id ? "当前已穿戴":camp?.skins.contains(s.id)==true ? "穿戴衣装":"解锁并穿戴 · \(s.cost) 织梦丝",id:"skin-\(s.id)",disabled:game.actor.skin==s.id,["type":"skin","hero":game.selected,"skin":s.id])
   }
   if !game.collection.skins.contains(where:{$0.hero==game.selected}){Text("本版衣装：霁弦「月夜邮差」、岚珀「黎明航海家」。可在上方选择对应旅人查看。").font(.system(size:16)).foregroundStyle(cwMist)}
  }
 }
 private var backpack:some View{
  VStack(alignment:.leading,spacing:15){heading("航行背包","掉落与结算都会保存本机。失败也保留本次结算材料；不需要联网或等待体力。")
   ForEach(["coins","books","ore","crystal","thunder","tide","tickets","threads"],id:\.self){k in HStack{Text(game.collection.materials[k]?.icon ?? "◆").font(.system(size:25)).frame(width:36);VStack(alignment:.leading,spacing:5){Text(game.collection.materials[k]?.name ?? k).font(.system(size:18,weight:.semibold));Text(k=="tickets" ? "持续战斗与通关获得，用于祈星":k=="threads" ? "通关及满命重复获得，用于衣装":k=="books" ? "战斗掉落，用于角色升级":k=="ore" ? "战斗掉落，用于武器升级":k=="coins" ? "战斗结算，用于升级、突破、精炼":"对应主战元素的战斗掉落及通关奖励，用于突破").font(.system(size:13)).foregroundStyle(cwMist)};Spacer();Text("\(camp?.wallet[k] ?? 0)").font(.system(size:22,weight:.semibold)).monospacedDigit()}.foregroundStyle(cwGold).padding(14).background(cwPanel,in:RoundedRectangle(cornerRadius:11))}
  }
 }
}
private struct WishReveal:View {
 @ObservedObject var game:GameStore
 var body:some View{
  let five=game.wishResults.contains{$0.rarity==5}
  ZStack{LinearGradient(colors:[Color(hex:five ? "705334":"3a456c"),Color(hex:"102638")],startPoint:.topLeading,endPoint:.bottomTrailing).ignoresSafeArea()
   ScrollView{VStack(spacing:18){Text(five ? "✦ 星光回应 ✦":"星轨相逢").font(.system(size:32,weight:.medium,design:.serif)).foregroundStyle(cwGold);Text("结果已经保存本机").font(.system(size:15)).foregroundStyle(cwMist)
    LazyVGrid(columns:[GridItem(.flexible()),GridItem(.flexible())],spacing:12){ForEach(Array(game.wishResults.enumerated()),id:\.offset){_,r in
     VStack(spacing:9){Image(uiImage:UIImage(named:r.kind=="hero" ? "\(r.item)-face":"weapon-\(r.item)") ?? UIImage()).resizable().scaledToFit().frame(height:92);Text(r.kind=="hero" ? game.travellers.first{$0.id==r.item}?.name ?? "":game.collection.weapon(r.item)?.name ?? "").font(.system(size:17,weight:.semibold));Text(String(repeating:"★",count:r.rarity)).font(.system(size:14));Text(r.reward ?? (r.kind=="hero" ? "命星 +1":"武器入库")).font(.system(size:12)).foregroundStyle(cwMist)}.foregroundStyle(r.rarity==5 ? cwGold:Color(hex:"d2c3ff")).frame(maxWidth:.infinity).padding(12).background(cwPanel,in:RoundedRectangle(cornerRadius:12)).overlay(RoundedRectangle(cornerRadius:12).stroke(r.rarity==5 ? cwGold:Color(hex:"a393d4")))
    }}
    Button{game.wishResults=[]}label:{Text("收下并继续").font(.system(size:18,weight:.semibold)).foregroundStyle(Color(hex:"253e50")).frame(maxWidth:.infinity,minHeight:54).background(cwGold,in:RoundedRectangle(cornerRadius:11))}.buttonStyle(.plain).accessibilityIdentifier("wish-result-close")
   }.padding(22)}
  }.accessibilityIdentifier("wish-reveal")
 }
}
