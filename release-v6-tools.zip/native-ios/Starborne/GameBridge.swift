import Foundation
import JavaScriptCore

struct Pilot: Decodable {
    let x, y, r, invincible, bank: Double
    let lives, power, bombs, shield: Int
    let weapon: String
    let spirit: Bool
}
struct HeroFrame: Decodable {
    let time, bank, lag, pitch, bob, roll, stretch, recoil: Double
    let weights: [Double]
}
struct Enemy: Decodable {
    let id: Int
    let type: String
    let x, y, hp, maxHp, rx, ry, seed, flash: Double
    let dead, ground: Bool
    let parts: [EnemyPart]?
    let element:String?
    let armor,armorMax,exposed:Double?
}
struct EnemyPart: Decodable { let x, y, hp, maxHp: Double }
struct EnemyBullet: Decodable { let x, y, vx, vy, r: Double; let kind: String; let dead: Bool }
struct PlayerShot: Decodable { let id: Int; let x, y, angle: Double; let kind: String; let spirit: Bool?; let dead: Bool }
struct Pickup: Decodable { let id: Int; let type: String; let x, y, seed: Double; let dead: Bool }
struct Hazard: Decodable { let x, width, age, warmup: Double }
struct BeamEnd: Decodable { let x, y: Double }
struct Beam: Decodable { let x, y, endX, endY: Double }
struct LaserFrame: Decodable { let time: Double; let ends: [BeamEnd] }
struct SpiritFrame: Decodable { let time: Double; let beams: [Beam] }
struct Stage: Decodable { let name, code, boss: String }
struct GameEvent: Decodable {
    let type: String
    let x, y, size, value: Double?
    let lives, index, power: Int?
    let name, weapon, enemyType, kind: String?
    let spirit: Bool?
}
struct GameFrame: Decodable {
    let state, character, phase: String
    let hard, won: Bool
    let worldHeight, elapsed, scroll, score, progress, shake, bombCooldown, bombTime: Double
    let tension, grazes, maxTension, stageIndex: Int
    let threatLevel: Int
    let breather: Bool
    let stage: Stage
    let expedition:ExpeditionFrame?
    let player: Pilot
    let motion: HeroFrame
    let enemies: [Enemy]
    let bullets: [EnemyBullet]
    let shots: [PlayerShot]
    let pickups: [Pickup]
    let hazards: [Hazard]
    let laser: LaserFrame
    let spirit: SpiritFrame
    let events: [GameEvent]
    var boss: Enemy? { enemies.first { $0.type == "boss" && !$0.dead } }
}
struct Traveller: Decodable, Identifiable {
    let id, name, title, weapon, color, normal, spirit, spell, quote, alt: String
    private enum Keys: String, CodingKey { case name,title,weapon,color,normal,spirit,spell,quote,alt }
    init(id: String, decoder: Decoder) throws {
        self.id=id; let c=try decoder.container(keyedBy:Keys.self)
        name=try c.decode(String.self,forKey:.name);title=try c.decode(String.self,forKey:.title)
        weapon=try c.decode(String.self,forKey:.weapon);color=try c.decode(String.self,forKey:.color)
        normal=try c.decode(String.self,forKey:.normal);spirit=try c.decode(String.self,forKey:.spirit)
        spell=try c.decode(String.self,forKey:.spell);quote=try c.decode(String.self,forKey:.quote);alt=try c.decode(String.self,forKey:.alt)
    }
    init(from decoder: Decoder) throws { try self.init(id:"",decoder:decoder) }
    init(id: String, value: Traveller) {
        self.id=id;name=value.name;title=value.title;weapon=value.weapon;color=value.color;normal=value.normal;spirit=value.spirit;spell=value.spell;quote=value.quote;alt=value.alt
    }
    static func load() -> [Traveller] {
        guard let url=Bundle.main.url(forResource:"characters",withExtension:"json"),let data=try? Data(contentsOf:url),let values=try? JSONDecoder().decode([String:Traveller].self,from:data) else { return [] }
        return ["ember","lune","nerine","sol","vesper","aster"].compactMap { id in values[id].map { Traveller(id:id,value:$0) } }
    }
}
final class GameBridge {
    enum Error: Swift.Error { case missingCore, invalidJavaScript(String), invalidFrame }
    private let context: JSContext
    private let runtime: JSValue
    private let decoder=JSONDecoder()
    init(bundle:Bundle = .main) throws {
        guard let path=bundle.url(forResource:"NativeCore",withExtension:"js") else { throw Error.missingCore }
        context=JSContext()!
        context.exceptionHandler={ _, error in NSLog("Starborne engine: %@",error?.toString() ?? "unknown JavaScript error") }
        context.evaluateScript(try String(contentsOf:path,encoding:.utf8))
        guard let value=context.objectForKeyedSubscript("NativeStarborne"),!value.isUndefined else { throw Error.invalidJavaScript(context.exception?.toString() ?? "Missing runtime") }
        runtime=value
    }
    @discardableResult func call(_ method:String,_ arguments:[Any]=[]) -> JSValue? { runtime.invokeMethod(method,withArguments:arguments) }
    func frame(_ value:JSValue?) throws -> GameFrame {
        guard let string=value?.toString(),let data=string.data(using:.utf8) else { throw Error.invalidFrame }
        return try decoder.decode(GameFrame.self,from:data)
    }
    func ready(character:String,hard:Bool,height:Double,support:String="nerine",trial:String="voyage",talent:String="balanced",campRaw:String?=nil) throws -> GameFrame {var options:[String:Any]=["character":character,"hard":hard,"height":height,"support":support,"trial":trial,"talent":talent,"strategy":true];if let campRaw{options["campRaw"]=campRaw};return try frame(call("ready",[options]))}
    func reset(character:String,hard:Bool,height:Double,seed:Int? = nil,support:String="nerine",trial:String="voyage",talent:String="balanced",autoDraft:Bool=false,legacy:Bool=false,campRaw:String?=nil) throws -> GameFrame {
        var options:[String:Any]=["character":character,"hard":hard,"height":height,"support":support,"trial":trial,"talent":talent,"strategy": !legacy,"autoDraft":autoDraft,"runId":UUID().uuidString]
        if let seed {options["seed"]=seed}
        if let campRaw,!legacy{options["campRaw"]=campRaw}
        return try frame(call("reset",[options]))
    }
    func step(_ dt:Double,target:CGPoint?) throws -> GameFrame {
        let input:[String:Any]=target.map{["target":["x":Double($0.x),"y":Double($0.y)]]} ?? [:]
        return try frame(call("step",[dt,input]))
    }
}
