import SpriteKit
import UIKit
import AVFoundation
import simd

extension UIColor {
    convenience init(hex:String) { let n=UInt32(hex.trimmingCharacters(in:CharacterSet.alphanumerics.inverted),radix:16) ?? 0xF1DFC0;self.init(red:CGFloat((n>>16)&255)/255,green:CGFloat((n>>8)&255)/255,blue:CGFloat(n&255)/255,alpha:1) }
}
protocol FlightSceneObserver: AnyObject { func sceneUpdated(_ gameFrame:GameFrame);func sceneFailed(_ message:String) }
final class SpritePool {
    private let parent:SKNode
    private var items:[SKSpriteNode]=[]
    private var used=0
    init(_ parent:SKNode){self.parent=parent}
    func begin(){used=0}
    func sprite(_ texture:SKTexture,at point:CGPoint,size:CGSize,rotation:CGFloat=0,alpha:CGFloat=1,color:UIColor?=nil,add:Bool=false)->SKSpriteNode {
        let n:SKSpriteNode
        if used<items.count { n=items[used] } else { n=SKSpriteNode();parent.addChild(n);items.append(n) }
        used+=1;n.isHidden=false;n.texture=texture;n.position=point;n.size=size;n.zRotation=rotation;n.alpha=alpha;n.color=color ?? .white;n.colorBlendFactor=color == nil ? 0 : 0.45;n.blendMode=add ? .add:.alpha;n.warpGeometry=nil
        return n
    }
    func end(){if used<items.count {for i in used..<items.count{items[i].isHidden=true}}}
}
final class FlightScene: SKScene {
    weak var observer:FlightSceneObserver?
    let bridge:GameBridge
    let audio=NativeAudio()
    private let diagnostics=NativeDiagnostics()
    private(set) var gameFrame:GameFrame?
    private var layers:[String:SKNode]=[:],pools:[String:SpritePool]=[:],textures:[String:SKTexture]=[:]
    private var lastTime:TimeInterval=0,visualTime:Double=0,lastShotSound:Double = -1
    private var target:CGPoint?,lastTouch:CGPoint?,activeTouch:UITouch?
    private var core=SKShapeNode(circleOfRadius:4.5),coreCenter=SKShapeNode(circleOfRadius:1.5)
    private var portrait=SKSpriteNode(),portraitShade=SKSpriteNode(color:.black,size:.zero),spellLabel=SKLabelNode(fontNamed:"STSongti-SC-Regular"),spellRemaining:Double=0
    private var banner=SKLabelNode(fontNamed:"STSongti-SC-Regular"),bannerRemaining:Double=0
    private var bannerNote=SKLabelNode(fontNamed:"AvenirNext-Regular")
    private var trails:[Int:[CGPoint]]=[:],trailNodes:[Int:SKShapeNode]=[:],lastTrailElapsed:Double = -1
    private var ambient:SKEmitterNode?
    private var lastCharacter="lune",lastHard=false
    private let travellers=Dictionary(uniqueKeysWithValues:Traveller.load().map{($0.id,$0)})
    private var reducedMotion=UIAccessibility.isReduceMotionEnabled
    private let gridSource:[SIMD2<Float>]=(0..<13).flatMap{y in (0..<7).map{x in SIMD2<Float>(Float(x)/6,Float(y)/12)}}
    override init(size:CGSize){
        bridge=try! GameBridge()
        super.init(size:size);scaleMode = .aspectFill;backgroundColor=UIColor(hex:"102b40")
        for (index,key) in ["terrain","cutin","shadows","actors","shots","pickups","hero","effects","hazards","bullets","core"].enumerated(){let node=SKNode();node.zPosition=CGFloat(index*10);addChild(node);layers[key]=node;pools[key]=SpritePool(node)}
        makeTextures();setupPortrait();setupAtmosphere()
        core.fillColor=UIColor(hex:"f1fff9");core.strokeColor=UIColor(hex:"07121d");core.lineWidth=1.5;core.glowWidth=0.5;coreCenter.fillColor=UIColor(hex:"51c8b4");coreCenter.strokeColor = .clear
        layers["core"]!.addChild(core);core.addChild(coreCenter)
        banner.fontSize=31;banner.fontColor=UIColor(hex:"f4e5c8");banner.zPosition=1;banner.horizontalAlignmentMode = .center
        bannerNote.fontSize=17;bannerNote.fontColor=UIColor(hex:"c7dce6");bannerNote.horizontalAlignmentMode = .center
        layers["effects"]!.addChild(banner);layers["effects"]!.addChild(bannerNote)
    }
    required init?(coder:NSCoder){fatalError("Use init(size:)")}
    override func didMove(to view:SKView){
        if NativeQA.enabled {view.showsFPS=true;view.showsNodeCount=true;view.showsDrawCount=true;view.showsPhysics=true}
    }
    private func point(_ x:Double,_ y:Double)->CGPoint{CGPoint(x:x,y:Double(size.height)-y)}
    private func artKey(_ frame:GameFrame,_ suffix:String)->String{let skin=frame.expedition?.skin ?? "base";return skin=="base" ? "\(frame.character)-\(suffix)":"skin-\(skin)-\(suffix)"}
    private func texture(_ key:String)->SKTexture { if let t=textures[key]{return t};let t=SKTexture(imageNamed:key);t.filteringMode = .linear;textures[key]=t;return t }
    private func drawTexture(_ key:String,_ size:CGSize,_ drawing:(CGContext)->Void){
        let renderer=UIGraphicsImageRenderer(size:size);let image=renderer.image{drawing($0.cgContext)};textures[key]=SKTexture(image:image)
    }
    private func makeTextures(){
        for (key,glyph,color) in [("crystal","◇","f4ca79"),("thunder","ϟ","c7a0ff"),("tide","≈","8fdbf5")]{
            drawTexture("element-\(key)",CGSize(width:28,height:28)){_ in
                NSAttributedString(string:glyph,attributes:[.font:UIFont.systemFont(ofSize:24,weight:.heavy),.foregroundColor:UIColor(hex:color),.strokeColor:UIColor(hex:"102335"),.strokeWidth: -3]).draw(at:CGPoint(x:3,y:0))
            }
        }

        for (key,color) in [("pink",UIColor(hex:"ff683e")),("cyan",UIColor(hex:"ffbb45")),("rose",UIColor(hex:"ff467d"))]{
            for petal in [false,true]{drawTexture("bullet-\(key)-\(petal ? "petal":"round")",CGSize(width:24,height:32)){c in
                let rect=CGRect(x:4,y:petal ? 3:7,width:16,height:petal ? 26:18);c.setFillColor(UIColor(hex:"18101e").cgColor);c.fillEllipse(in:rect)
                c.setFillColor(color.cgColor);c.fillEllipse(in:rect.insetBy(dx:2,dy:2));c.setFillColor(UIColor(hex:"fff3cd").cgColor);c.fillEllipse(in:rect.insetBy(dx:5,dy:5));c.setFillColor(color.cgColor);c.fillEllipse(in:rect.insetBy(dx:6.5,dy:6.5))
            }}
        }
        for (key,color) in [("crystal",UIColor(hex:"f5d18e")),("water",UIColor(hex:"94e5fa")),("violet",UIColor(hex:"d7baff")),("leaf",UIColor(hex:"b2f5ce"))]{
            drawTexture(key,CGSize(width:24,height:48)){c in
                c.setFillColor(color.cgColor);c.move(to:CGPoint(x:12,y:0));c.addLine(to:CGPoint(x:23,y:24));c.addLine(to:CGPoint(x:12,y:48));c.addLine(to:CGPoint(x:1,y:24));c.closePath();c.fillPath()
                c.setStrokeColor(UIColor.white.withAlphaComponent(0.9).cgColor);c.setLineWidth(1.6);c.move(to:CGPoint(x:12,y:4));c.addLine(to:CGPoint(x:12,y:44));c.strokePath()
            }
        }
        drawTexture("beam",CGSize(width:32,height:128)){c in
            let colors=[UIColor.clear.cgColor,UIColor.white.cgColor,UIColor.clear.cgColor] as CFArray
            let gradient=CGGradient(colorsSpace:CGColorSpaceCreateDeviceRGB(),colors:colors,locations:[0,0.5,1])!
            c.drawLinearGradient(gradient,start:CGPoint(x:0,y:64),end:CGPoint(x:32,y:64),options:[])
        }
        drawTexture("friendly-shot",CGSize(width:16,height:48)){c in
            c.setFillColor(UIColor(hex:"67e4ff").withAlphaComponent(0.45).cgColor);c.fill(CGRect(x:3,y:5,width:10,height:42));c.setFillColor(UIColor(hex:"d3faff").cgColor);c.fill(CGRect(x:6,y:0,width:4,height:36))
        }
        for (key,color,label) in [("power",UIColor(hex:"81c4ff"),"↑"),("burst",UIColor(hex:"e0b3ff"),"✦"),("heal",UIColor(hex:"75f7b2"),"+"),("shield",UIColor(hex:"b0daff"),"⬡"),("material",UIColor(hex:"ffd28a"),"◆")]{
            drawTexture(key,CGSize(width:40,height:48)){c in
                c.setFillColor(UIColor(hex:"20475e").cgColor);let p=UIBezierPath(roundedRect:CGRect(x:3,y:3,width:34,height:42),cornerRadius:8);p.fill();color.setStroke();p.lineWidth=2;p.stroke()
                let text=NSAttributedString(string:label,attributes:[.font:UIFont.systemFont(ofSize:28,weight:.heavy),.foregroundColor:color]);text.draw(at:CGPoint(x:9,y:5))
            }
        }
    }
    private func expeditionEffects(_ f:GameFrame){
        guard let e=f.expedition else{return}
        let p=f.player
        if p.shield>0{_=image("effects","shield",p.x,p.y,72,height:80,alpha:0.23)}
        if e.castFlash>0{_=image("hero",(e.supportSkin ?? "base")=="base" ? "\(e.support)-3":"skin-\(e.supportSkin!)-3",p.x+(p.x<240 ? 67:-67),p.y-48,71,height:89,alpha:min(0.65,e.castFlash))}
        for fx in e.fx{
            let color=UIColor(hex:fx.kind=="fracture" ? "ffd092":fx.kind=="ward" ? "a8dcff":"c1d6ff")
            if fx.kind=="chain" || fx.kind=="assist"{beam(fx.x,fx.y,fx.toX,fx.toY,color:color)}
            glow("effects",fx.toX,fx.toY,fx.kind=="fracture" ? 35:22,color,min(0.35,fx.life))
        }
        for enemy in f.enemies where !enemy.dead{
            if let element=enemy.element,!element.isEmpty{_=image("actors","element-\(element)",enemy.x,enemy.y-enemy.ry-15,20,height:20,alpha:0.95)}
        }
    }
    private func setupPortrait(){
        layers["cutin"]!.addChild(portraitShade);layers["cutin"]!.addChild(portrait);layers["cutin"]!.addChild(spellLabel)
        portraitShade.alpha=0;portrait.alpha=0;spellLabel.alpha=0;spellLabel.fontSize=28;spellLabel.fontColor=UIColor(hex:"fff1cc")
    }
    private func setupAtmosphere(){
        let emitter=SKEmitterNode();emitter.particleTexture=texture("glow");emitter.particleBirthRate=reducedMotion ? 0:9;emitter.particleLifetime=34;emitter.particleLifetimeRange=10;emitter.particleSpeed=22;emitter.particleSpeedRange=10;emitter.emissionAngle = -.pi/2;emitter.emissionAngleRange=0.3;emitter.particlePositionRange=CGVector(dx:480,dy:20);emitter.particleAlpha=0.13;emitter.particleAlphaRange=0.06;emitter.particleScale=0.04;emitter.particleScaleRange=0.025;emitter.particleBlendMode = .add;emitter.particleColor=UIColor(hex:"bbe8ed");emitter.particleColorBlendFactor=1;layers["terrain"]!.addChild(emitter);ambient=emitter
    }
    func configure(height:Double){
        let h=max(640,height);guard abs(Double(size.height)-h)>0.5 else{return};size=CGSize(width:480,height:h);lastTime=0;clearInput();ambient?.position=CGPoint(x:240,y:h+40)
        _=bridge.call("resize",[h])
    }
    func home(character:String,hard:Bool,support:String="nerine",trial:String="voyage",talent:String="balanced",campRaw:String?=nil){
        lastCharacter=character;lastHard=hard;lastShotSound = -1;clearInput();clearEffects();gameFrame=try? bridge.ready(character:character,hard:hard,height:Double(size.height),support:support,trial:trial,talent:talent,campRaw:campRaw);lastTime=0
        if let gameFrame{render(gameFrame,dt:0);observer?.sceneUpdated(gameFrame);audio.setScene(state:gameFrame.state,boss:gameFrame.phase=="boss")}
    }
    func start(character:String,hard:Bool,support:String="nerine",trial:String="voyage",talent:String="balanced",campRaw:String?=nil){
        lastCharacter=character;lastHard=hard;lastShotSound = -1;clearInput();clearEffects();diagnostics.reset();gameFrame=try? bridge.reset(character:character,hard:hard,height:Double(size.height),seed:NativeQA.enabled ? 42:nil,support:support,trial:trial,talent:talent,autoDraft:NativeQA.value("--qa-autostart")=="true",legacy:NativeQA.value("--qa-legacy")=="true",campRaw:campRaw);lastTime=0
        if NativeQA.value("--qa-draft")=="true"{gameFrame=try? bridge.frame(bridge.call("benchmark",[["draft":true]]))}
        if let power=NativeQA.value("--qa-power").flatMap(Int.init){gameFrame=try? bridge.frame(bridge.call("benchmark",[["power":power,"stage":Int(NativeQA.value("--qa-stage") ?? "0") ?? 0]]))}
        if let gameFrame{render(gameFrame,dt:0);observer?.sceneUpdated(gameFrame)}
    }
    func pause(){guard gameFrame?.state == "playing" else{return};_=bridge.call("pause");clearInput();audio.setScene(state:"paused",boss:false);gameFrame=try? bridge.step(0,target:nil);if let gameFrame{observer?.sceneUpdated(gameFrame)}}
    func resume(){guard gameFrame?.state == "paused" else{return};_=bridge.call("resume");lastTime=0;clearInput();gameFrame=try? bridge.step(0,target:nil);if let gameFrame{observer?.sceneUpdated(gameFrame)}}
    func choose(_ id:String){_=bridge.call("choose",[id]);lastTime=0;clearInput();gameFrame=try? bridge.step(0,target:nil);if let gameFrame{observer?.sceneUpdated(gameFrame)}}
    func cast(){if bridge.call("bomb")?.toBool()==true { UIImpactFeedbackGenerator(style:.medium).impactOccurred() }}
    func clearInput(){activeTouch=nil;lastTouch=nil;target=nil;_=bridge.call("cancelTouch")}
    private func clearEffects(){
        for key in ["effects"]{layers[key]?.children.filter{$0.name == "transient"}.forEach{$0.removeFromParent()}}
        spellRemaining=0;portrait.alpha=0;portraitShade.alpha=0;spellLabel.alpha=0;banner.alpha=0;bannerNote.alpha=0;bannerRemaining=0;trails.removeAll();for n in trailNodes.values{n.removeFromParent()};trailNodes.removeAll();lastTrailElapsed = -1
    }
    override func update(_ currentTime:TimeInterval){
        let dt=lastTime==0 ? 0:min(0.08,currentTime-lastTime);lastTime=currentTime
        let begin=CACurrentMediaTime()
        let interval=NativeQA.enabled ? NativeQA.signposter.beginInterval("GameFrame"):nil
        do {let next=try bridge.step(dt,target:target);gameFrame=next
            let engineEnd=CACurrentMediaTime()
            if next.state == "playing" || next.state == "ready"{visualTime+=dt};if let t=target,hypot(t.x-next.player.x,t.y-next.player.y)<1,activeTouch==nil{target=nil}
            for event in next.events{handle(event,gameFrame:next)}
            audio.setScene(state:next.state=="draft" ? "paused":next.state,boss:next.phase=="boss")
            let eventsEnd=CACurrentMediaTime()
            render(next,dt:dt);let renderEnd=CACurrentMediaTime();observer?.sceneUpdated(next)
            diagnostics.sample(time:currentTime,engineMS:(engineEnd-begin)*1000,renderMS:(renderEnd-eventsEnd)*1000,observerMS:(CACurrentMediaTime()-renderEnd)*1000,eventsMS:(eventsEnd-engineEnd)*1000,scene:self,frame:next)
        }catch{observer?.sceneFailed("游戏载入失败：\(error.localizedDescription)")}
        if let interval {NativeQA.signposter.endInterval("GameFrame",interval)}
    }
    private func handle(_ event:GameEvent,gameFrame f:GameFrame){
        let x=event.x ?? f.player.x,y=event.y ?? f.player.y
        switch event.type {
        case "shoot":if f.elapsed-lastShotSound>0.08{audio.play("shot");lastShotSound=f.elapsed}
        case "kill","partDown":burst(x,y,size:event.size ?? 25,color:event.spirit == true ? UIColor(hex:"9ff4d6"):UIColor(hex:"ffd1ac"));audio.play("kill")
        case "hit":if !reducedMotion{burst(x,y,size:3,color:UIColor(hex:"e5dbff"),count:3)}
        case "hurt":burst(x,y,size:40,color:UIColor(hex:"f2a5af"));audio.play("hurt");UINotificationFeedbackGenerator().notificationOccurred(.warning)
        case "pickup":audio.play("pickup")
        case "draft":clearInput();spellRemaining=0;portrait.alpha=0;portraitShade.alpha=0;spellLabel.alpha=0
        case "blessing":audio.play("powerup");notice(event.name ?? "祝福已生效",x:x,y:y,color:UIColor(hex:"f4dfa8"))
        case "reaction":audio.play("pickup");if !reducedMotion{ring(x,y,radius:45,color:UIColor(hex:"bce5ff"),duration:0.35)}
        case "shield","shieldBlock":audio.play("heal");ring(x,y,radius:48,color:UIColor(hex:"a7dfff"),duration:0.4);notice(event.name ?? "星帆庇护",x:x,y:y,color:UIColor(hex:"a7dfff"))
        case "armorBreak":audio.play("bomb");notice(event.name ?? "护甲击破",x:x,y:y,color:UIColor(hex:"ffd899"))
        case "powerup":audio.play("powerup");notice(event.kind=="bomb" ? "大招 +1":"火力 \(event.power ?? f.player.power)/6",x:x,y:y,color:UIColor(hex:"b9e5ff"))
        case "heal":audio.play("heal");ring(x,y,radius:95,color:UIColor(hex:"7df2b1"),duration:0.65);notice("生命 +1",x:x,y:y,color:UIColor(hex:"7df2b1"));UINotificationFeedbackGenerator().notificationOccurred(.success)
        case "supply":banner.text="补给间歇";bannerNote.text="↑ 火力  ·  + 恢复生命";bannerRemaining=1.6
        case "recoverySupply":notice("+ 回血补给",x:x,y:y,color:UIColor(hex:"7df2b1"))
        case "graze":if !reducedMotion{ring(x,y,radius:31,color:UIColor(hex:"ffdfa0"),duration:0.25)}
        case "bomb":showSpell(f,health:event.lives ?? f.player.lives);ring(x,y,radius:Double(size.height),color:UIColor(hex:"f4dfa8"),duration:1.3);burst(x,y,size:90,color:UIColor(hex:"fff0c6"),count:48);audio.play("bomb")
        case "stage":banner.text=f.stage.name;bannerNote.text="STAGE 0\(f.stageIndex+1) / \(f.stage.code)";bannerRemaining=2.5
        case "boss":banner.text="守卫显现";bannerNote.text=f.stage.boss;bannerRemaining=2.1
        case "stageClear":banner.text=f.stageIndex==2 ? "星轨重连":"云境通过";bannerNote.text="爆发充能 +1";bannerRemaining=2.5
        default:break
        }
    }
    private func notice(_ text:String,x:Double,y:Double,color:UIColor){
        guard let layer=layers["effects"],layer.children.count<100 else{return}
        let label=SKLabelNode(fontNamed:"PingFangSC-Semibold");label.name="transient";label.text=text;label.fontSize=24;label.fontColor=color;label.position=point(x,min(Double(size.height)-145,max(230,y-65)));layer.addChild(label)
        label.run(.sequence([.group([.moveBy(x:0,y:38,duration:1.15),.sequence([.wait(forDuration:0.7),.fadeOut(withDuration:0.45)])]),.removeFromParent()]))
    }
    private func showSpell(_ f:GameFrame,health:Int){
        let tier=health>=3 ? "healthy":health==2 ? "wounded":"critical"
        portrait.texture=texture(artKey(f,tier))
        let h=Double(size.height),top=max(150,min(340,h*0.32)),height=h-125-top,width=height/2
        portrait.size=CGSize(width:width,height:height);portrait.position=point(240+(f.player.x<=240 ? 12:-12),top+height/2)
        portraitShade.size=size;portraitShade.position=CGPoint(x:240,y:size.height/2);spellLabel.position=point(240,h-99)
        spellLabel.text=travellers[f.character]?.spell ?? "星渡";spellRemaining=reducedMotion ? 0.85:1.15
        // Leave the full figure clear of introductory banners.
        bannerRemaining=0;banner.alpha=0;bannerNote.alpha=0
    }
    private func ring(_ x:Double,_ y:Double,radius:Double,color:UIColor,duration:Double){
        guard let layer=layers["effects"],layer.children.count<100 else{return}
        let n=SKShapeNode(circleOfRadius:8);n.name="transient";n.strokeColor=color;n.lineWidth=2;n.glowWidth=reducedMotion ? 0:3;n.fillColor = .clear;n.position=point(x,y);layer.addChild(n)
        n.run(.sequence([.group([.scale(to:CGFloat(radius/8),duration:duration),.fadeOut(withDuration:duration)]),.removeFromParent()]))
    }
    private func burst(_ x:Double,_ y:Double,size:Double,color:UIColor,count:Int?=nil){
        guard let layer=layers["effects"],layer.children.count<100 else{return}
        let e=SKEmitterNode();e.name="transient";e.particleTexture=texture("glow");let number=count ?? (reducedMotion ? 7:min(40,Int(10+size*0.4)))
        e.numParticlesToEmit=number;e.particleBirthRate=500;e.particleLifetime=0.4;e.particleLifetimeRange=0.25;e.particleSpeed=CGFloat(45+size);e.particleSpeedRange=70;e.emissionAngleRange = .pi*2;e.particleScale=0.05;e.particleScaleRange=0.03;e.particleScaleSpeed = -0.04;e.particleAlpha=0.9;e.particleAlphaSpeed = -1.5;e.particleColor=color;e.particleColorBlendFactor=1;e.particleBlendMode = .add;e.position=point(x,y);layer.addChild(e);e.run(.sequence([.wait(forDuration:0.9),.removeFromParent()]))
    }
    private func image(_ layer:String,_ key:String,_ x:Double,_ y:Double,_ width:Double,height:Double?=nil,rotation:Double=0,alpha:Double=1,color:UIColor?=nil,add:Bool=false)->SKSpriteNode{
        let t=texture(key),aspect=t.size().height/max(1,t.size().width)
        return pools[layer]!.sprite(t,at:point(x,y),size:CGSize(width:width,height:height ?? width*aspect),rotation:CGFloat(-rotation),alpha:CGFloat(alpha),color:color,add:add)
    }
    private func glow(_ layer:String,_ x:Double,_ y:Double,_ r:Double,_ color:UIColor,_ alpha:Double){_=image(layer,"glow",x,y,r*2,height:r*2,alpha:alpha,color:color,add:true)}
    private func render(_ f:GameFrame,dt:Double){
        for pool in pools.values{pool.begin()};let h=Double(size.height),t=reducedMotion ? 0:visualTime,p=f.player
        for layer in layers.values{layer.isPaused=f.state == "paused" || f.state == "draft"}
        ambient?.position=CGPoint(x:240,y:h+40)
        let scroll=f.state == "ready" ? visualTime*22:f.scroll*0.6
        for i in 0...Int(ceil(h/720)) {let y=Double(i)*720+scroll.truncatingRemainder(dividingBy:720)-360;_=image("terrain","sky",240,y,480,height:720,color:f.stageIndex==2 ? UIColor(hex:"9ebedc"):nil)}
        let color=UIColor(hex:travellers[f.character]?.color ?? "c7a0ff")
        if f.state != "ready" {
            for e in f.enemies where !e.dead{
                let key=e.type=="boss" || e.type=="carrier" || e.type=="gunship" ? "boss":e.type=="sweeper" || e.type=="tank" ? "sentinel":"wisp"
                let w:Double=e.type=="boss" ? 210:e.type=="gunship" ? 124:e.type=="carrier" ? 92:e.type=="tank" ? 60:e.type=="sweeper" ? 62:54
                glow("shadows",e.x,e.y+20,w*0.5,UIColor.black,0.7)
                glow("actors",e.x,e.y,w*0.5,UIColor(hex:e.type=="boss" ? "c081e4":"ff8064"),0.25)
                _=image("actors",key,e.x,e.y+(reducedMotion ? 0:sin(t*2.6+e.seed)*3),w,rotation:e.type=="diver" ? .pi:sin(t*1.2+e.seed)*0.045,alpha:e.flash>0 ? 0.7:1)
                for part in e.parts ?? [] where part.hp>0{_=image("actors","crystal",e.x+part.x,e.y+part.y,24,height:36,rotation:t*0.25);glow("effects",e.x+part.x,e.y+part.y,23,UIColor(hex:"ebb8ef"),0.22)}
            }
        }
        expeditionEffects(f)
        updateTrails(f,color:color)
        for shot in f.shots where !shot.dead{
            let key="friendly-shot",guided=shot.kind=="missile" || shot.kind=="feather"
            _=image("shots",key,shot.x,shot.y,guided ? 10:6,height:guided ? 28:32,rotation:shot.angle + .pi/2,alpha:0.9)
            if guided{glow("effects",shot.x,shot.y,shot.spirit == true ? 18:11,color,0.26)}
        }
        if f.laser.time>0&&f.state != "ready"{for end in f.laser.ends{beam(end.x,p.y-30,end.x,end.y,color:UIColor(hex:"cca7ff"))}}
        if p.spirit&&f.spirit.time>0{for b in f.spirit.beams{beam(b.x,b.y,b.endX,b.endY,color:UIColor(hex:"dfc7ff"))}}
        for q in f.pickups where !q.dead{
            let key=q.type=="material" ? "material":q.type=="medal" ? "crystal":q.type=="bomb" ? "burst":q.type=="heal" ? "heal":q.type=="shield" ? "shield":"power"
            _=image("pickups",key,q.x,q.y,q.type=="medal" ? 8:35,rotation:sin(t*3+q.seed)*0.06);glow("effects",q.x,q.y,q.type=="medal" ? 10:24,UIColor(hex:q.type=="heal" ? "75f7b2":q.type=="bomb" ? "e0b3ff":"81c4ff"),0.18)
        }
        if f.state != "over" {
            if f.state != "ready"{for side in [-1.0,1.0]{let x=p.x+side*(p.spirit ? 47:35),y=p.y-30+sin(t*4+side)*4;glow("effects",x,y,22,color,p.spirit ? 0.35:0.13);_=image("hero",p.weapon=="spread" ? "crystal":p.weapon=="laser" ? "violet":"water",x,y,p.weapon=="laser" ? 16:23,height:p.weapon=="laser" ? 34:26,rotation:side*sin(t*2)*0.13)}}
            let m=f.motion
            let warp=clothWarp(m)
            for pose in 0..<4 {
                let weight=reducedMotion ? (pose==0 ? 1.0:0):m.weights[pose];if weight<0.015{continue}
                let n=image("hero",artKey(f,String(pose)),p.x,p.y-22+(reducedMotion ? 0:m.bob+m.recoil),128*(1-abs(m.bank)*0.04),height:144*(reducedMotion ? 1:m.stretch),rotation:reducedMotion ? 0:m.roll,alpha:weight*(p.invincible>0 ? 0.8+sin(t*23)*0.12:1));n.warpGeometry=warp
            }
            core.position=point(p.x,p.y);core.isHidden=false
            glow("core",p.x,p.y,10,UIColor(hex:"afffea"),activeTouch==nil ? 0.16:0.3)
        } else {core.isHidden=true}
        for hazard in f.hazards{let active=hazard.age>=hazard.warmup;_=image("hazards","beam",hazard.x,h/2,active ? hazard.width:3,height:h,alpha:active ? 0.75:0.42,color:UIColor(hex:"f7a9e1"),add:true)}
        for b in f.bullets where !b.dead{
            let key=b.kind=="petal" ? "bullet-pink-petal":b.kind=="arc" ? "bullet-cyan-round":"bullet-rose-round"
            _=image("bullets",key,b.x,b.y,b.r*3.2,height:b.r*(b.kind=="petal" ? 4.8:4.3),rotation:atan2(b.vy,b.vx)+Double.pi/2)
        }
        if f.state != "paused" {spellRemaining=max(0,spellRemaining-dt);bannerRemaining=max(0,bannerRemaining-dt)}
        let duration=reducedMotion ? 0.85:1.15,spellProgress=1-spellRemaining/duration,spellOpacity=spellRemaining>0 ? min(1,min(spellProgress/0.14,(1-spellProgress)/0.2)):0
        portrait.alpha=spellOpacity*0.72;portraitShade.alpha=spellOpacity*0.28;spellLabel.alpha=spellOpacity
        banner.position=point(240,h*0.34);bannerNote.position=point(240,h*0.34-40);banner.alpha=bannerRemaining>0 ? min(1,bannerRemaining*2):0;bannerNote.alpha=banner.alpha
        if spellRemaining>0{banner.alpha=0;bannerNote.alpha=0}
        for pool in pools.values{pool.end()}
    }
    private func clothWarp(_ motion:HeroFrame)->SKWarpGeometryGrid? {
        if reducedMotion{return nil}
        var points:[SIMD2<Float>]=[]
        for value in gridSource {
            let u=Double(value.x),v=1-Double(value.y)
            let tail=max(0,(v-0.3)/0.7)
            let edge=pow(abs(u-0.5)*2,1.5)
            let flutter=sin(motion.time*5.5-v*7)*0.022
            let lag=(motion.lag-motion.bank)*0.13
            let sleeve=edge*sin(motion.time*4-v*5)*0.009
            let dx=tail*tail*(flutter+lag)+sleeve
            let dy=edge*sin(motion.time*4.3+u*5)*0.012*tail
            points.append(SIMD2<Float>(value.x+Float(dx),value.y-Float(dy)))
        }
        return SKWarpGeometryGrid(columns:6,rows:12,sourcePositions:gridSource,destinationPositions:points)
    }
    private func beam(_ x:Double,_ y:Double,_ endX:Double,_ endY:Double,color:UIColor){
        let dx=endX-x,dy=endY-y,length=hypot(dx,dy),rotation=atan2(dy,dx)+Double.pi/2
        _=image("effects","beam",(x+endX)/2,(y+endY)/2,16,height:length,rotation:rotation,alpha:0.32,color:color,add:true)
        _=image("shots","beam",(x+endX)/2,(y+endY)/2,4,height:length,rotation:rotation,alpha:0.95,color:color,add:true)
        glow("effects",endX,endY,23,color,0.45)
    }
    private func updateTrails(_ f:GameFrame,color:UIColor){
        let ids=Set(f.shots.filter{!$0.dead&&($0.kind=="missile" || $0.kind=="feather")}.map{$0.id})
        for id in Array(trails.keys) where !ids.contains(id){trails.removeValue(forKey:id);trailNodes.removeValue(forKey:id)?.removeFromParent()}
        guard f.elapsed != lastTrailElapsed else{return};lastTrailElapsed=f.elapsed
        for shot in f.shots where ids.contains(shot.id){
            var points=trails[shot.id] ?? [];points.append(point(shot.x,shot.y));if points.count>9{points.removeFirst(points.count-9)};trails[shot.id]=points
            let node:SKShapeNode;if let old=trailNodes[shot.id]{node=old}else{node=SKShapeNode();node.lineWidth=2;node.glowWidth=2;node.fillColor = .clear;layers["effects"]!.addChild(node);trailNodes[shot.id]=node}
            let path=CGMutablePath();if let start=points.first{path.move(to:start);for p in points.dropFirst(){path.addLine(to:p)}};node.path=path;node.strokeColor=color.withAlphaComponent(reducedMotion ? 0:0.3)
        }
    }
    override func touchesBegan(_ touches:Set<UITouch>,with event:UIEvent?){
        guard gameFrame?.state == "playing",activeTouch==nil,let touch=touches.first,let v=view,let p=gameFrame?.player else{return}
        activeTouch=touch;lastTouch=touch.location(in:v);target=CGPoint(x:p.x,y:p.y)
        if let q=lastTouch{_=bridge.call("touchBegin",[Double(q.x),Double(q.y),touch.timestamp*1000])}
    }
    override func touchesMoved(_ touches:Set<UITouch>,with event:UIEvent?){
        guard let touch=activeTouch,touches.contains(touch),let v=view,let old=lastTouch,var next=target else{return}
        let q=touch.location(in:v),scale=v.bounds.width/480
        next.x=max(24,min(456,next.x+(q.x-old.x)/scale*1.12));next.y=max(100,min(size.height-70,next.y+(q.y-old.y)/scale*1.12))
        lastTouch=q;target=next;_=bridge.call("touchMove",[Double(q.x),Double(q.y)])
    }
    override func touchesEnded(_ touches:Set<UITouch>,with event:UIEvent?){
        guard let touch=activeTouch,touches.contains(touch),let v=view else{return}
        let q=touch.location(in:v),cast=bridge.call("touchEnd",[Double(q.x),Double(q.y),touch.timestamp*1000])?.toBool() ?? false
        activeTouch=nil;lastTouch=nil;if cast{self.cast()}
    }
    override func touchesCancelled(_ touches:Set<UITouch>,with event:UIEvent?){clearInput()}
}
