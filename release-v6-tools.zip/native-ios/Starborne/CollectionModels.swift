import Foundation
struct CampActor:Decodable {var level=1,ascension=0,constellation=0,shards=0;var weapon="",skin="base";var cap:Int{20+ascension*20}}
struct CampWeapon:Decodable,Identifiable {let id,base:String;let level,ascension,refine:Int;var cap:Int{20+ascension*20}}
struct WishPity:Decodable {let count:Int;let guaranteed:Bool;let target:String}
struct WishResult:Decodable {let pool,kind,item:String;let rarity:Int;let duplicate:Bool;let reward:String?}
struct CampState:Decodable {let version:Int;let wallet:[String:Int];let actors:[String:CampActor];let weapons:[CampWeapon];let skins:[String];let pity:[String:WishPity];let history:[WishResult];let lastDrops:[String:Int]}
struct WeaponDefinition:Decodable,Identifiable {let id,name,kind,perk,owner,detail:String;let rarity,icon:Int}
struct SkinDefinition:Decodable,Identifiable {let id,hero,name,detail:String;let cost:Int}
struct MaterialDefinition:Decodable {let name,icon:String}
struct ConstellationDefinition:Decodable {let name,text:String}
struct CollectionContent:Decodable {
 let rarity:[String:Int],weapons:[WeaponDefinition],skins:[SkinDefinition],materials:[String:MaterialDefinition],constellations:[ConstellationDefinition],c6:[String:String],kinds:[String:String]
 static let shared:CollectionContent = {try! JSONDecoder().decode(CollectionContent.self,from:Data(contentsOf:Bundle.main.url(forResource:"collection",withExtension:"json")!))}()
 func weapon(_ id:String)->WeaponDefinition?{weapons.first{$0.id==id}}
}
