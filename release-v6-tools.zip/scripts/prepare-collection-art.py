"""Prepare generated sprite atlases with chroma-key helper, connected component extraction and WebP bundling."""
from pathlib import Path
from PIL import Image,ImageOps
import numpy as np,json,base64,subprocess,sys
R=Path(__file__).resolve().parents[1];A=R/'assets/collection-v6';S=A/'source'
helper=Path.home()/'.codex/skills/.system/imagegen/scripts/remove_chroma_key.py'
# Run-length connected components keeps limbs intact even when an atlas cell is wider than planned.
def figures(image,count,rows=1):
 ar=np.asarray(image);mask=ar[:,:,3]>32;parents=[0];runs=[];prev=[]
 def root(x):
  while parents[x]!=x:parents[x]=parents[parents[x]];x=parents[x]
  return x
 for y,row in enumerate(mask):
  edges=np.flatnonzero(np.diff(np.r_[False,row,False]));current=[];j=0
  for left,right in zip(edges[::2],edges[1::2]):
   while j<len(prev) and prev[j][1]<left:j+=1
   labels=[];k=j
   while k<len(prev) and prev[k][0]<=right:labels.append(root(prev[k][2]));k+=1
   if labels:
    lab=min(labels)
    for n in labels:parents[root(n)]=lab
   else:lab=len(parents);parents.append(lab)
   current.append((left,right,lab));runs.append((y,left,right,lab))
  prev=current
 groups={}
 for y,l,r,n in runs:
  n=root(n);g=groups.setdefault(n,[0,image.width,image.height,0,0]);g[0]+=r-l;g[1]=min(g[1],l);g[2]=min(g[2],y);g[3]=max(g[3],r);g[4]=max(g[4],y+1)
 main=sorted(groups,key=lambda n:groups[n][0],reverse=True)[:count];assert len(main)==count
 if rows>1:
  main=sorted(main,key=lambda n:(groups[n][2]+groups[n][4])/2);cols=count//rows;main=[n for row in range(rows) for n in sorted(main[row*cols:(row+1)*cols],key=lambda n:groups[n][1])]
 else:main=sorted(main,key=lambda n:groups[n][1])
 print('Sprite component areas:',[groups[n][0] for n in main])
 assert min(groups[n][0] for n in main)>10000,'Atlas figures touch or missing; inspect generated source'
 centers=[((groups[n][1]+groups[n][3])/2,(groups[n][2]+groups[n][4])/2) for n in main];assignment={n:min(range(count),key=lambda i:((g[1]+g[3])/2-centers[i][0])**2+(((g[2]+g[4])/2-centers[i][1])**2 if rows>1 else 0)) for n,g in groups.items()}
 result=[]
 for i in range(count):
  alpha=np.zeros(mask.shape,np.uint8)
  for y,l,r,n in runs:
   if assignment[root(n)]==i:alpha[y,l:r]=ar[y,l:r,3]
  rgba=ar.copy();rgba[:,:,3]=alpha;im=Image.fromarray(rgba);box=im.getbbox();assert box;result.append(im.crop(box))
 return result
meta={'weapons':{},'skins':{}};weaponIDs=['compass','lantern','daybreak','sunribbon','quill','violet','courier','eclipse','pearl','sprout','seashell','windmap']
weaponAlpha=S/'weapons-alpha.png'
subprocess.run([sys.executable,str(helper),'--input',str(S/'weapons-key.png'),'--out',str(weaponAlpha),'--auto-key','border','--soft-matte','--transparent-threshold','12','--opaque-threshold','220','--despill','--force'],check=True,stdout=subprocess.DEVNULL)
weaponFigures=figures(Image.open(weaponAlpha).convert('RGBA'),12,3)
for id,tile in zip(weaponIDs,weaponFigures):
 tile.thumbnail((232,232),Image.Resampling.LANCZOS);out=Image.new('RGBA',(256,256));out.alpha_composite(tile,((256-tile.width)//2,(256-tile.height)//2));path=A/f'weapon-{id}.webp';temp=path.with_suffix('.pending.webp');out.save(temp,quality=88,method=6);temp.replace(path);meta['weapons'][id]=path
for skin in ['moonlit','daysea']:
 meta['skins'][skin]={}
 for suffix,count,size,labels in [('',3,(512,1024),['healthy','wounded','critical']),('-poses',4,(236,256),['0','1','2','3'])]:
  key=S/f'{skin}{suffix}-key.png';alpha=S/f'{skin}{suffix}-alpha.png'
  subprocess.run([sys.executable,str(helper),'--input',str(key),'--out',str(alpha),'--auto-key','border','--soft-matte','--transparent-threshold','12','--opaque-threshold','220','--despill','--force'],check=True,stdout=subprocess.DEVNULL)
  sprites=figures(Image.open(alpha).convert('RGBA'),count)
  for label,im in zip(labels,sprites):
   pad=14 if count==3 else 10;im.thumbnail((size[0]-pad*2,size[1]-pad*2),Image.Resampling.LANCZOS);out=Image.new('RGBA',size);out.alpha_composite(im,((size[0]-im.width)//2,(size[1]-im.height)//2));path=A/f'skin-{skin}-{label}.webp';temp=path.with_suffix('.pending.webp');out.save(temp,quality=88,method=6);temp.replace(path)
   pixels=np.asarray(out);assert pixels[0,0,3]==0;assert np.count_nonzero(pixels[:,:,3])>size[0]*size[1]*.10
   meta['skins'][skin][label]=path
# Export a self-contained ES module; native preparation copies these same sources.
def embed(x):
 if isinstance(x,Path):return 'data:image/webp;base64,'+base64.b64encode(x.read_bytes()).decode()
 return {k:embed(v) for k,v in x.items()}
module=R/'src/collection-assets.js';pending=module.with_suffix('.pending.js');pending.write_text('export const COLLECTION_ART='+json.dumps(embed(meta),separators=(',',':'))+';\n');pending.replace(module)
(A/'manifest.json').write_text(json.dumps({'generator':'built-in image_gen','preparation':'official chroma-key helper; connected component extraction; contain resizing','files':[p.name for p in A.glob('*.webp')]},indent=2)+'\n')
print('Prepared',len(list(A.glob('*.webp'))),'assets')
