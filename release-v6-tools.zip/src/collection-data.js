export const HERO_RARITY={ember:5,lune:4,nerine:4,sol:4,vesper:5,aster:5};
export const MATERIALS={coins:{name:'星铸币',icon:'◈'},books:{name:'旅人札记',icon:'▤'},ore:{name:'锻星矿',icon:'◆'},crystal:{name:'辉晶印',icon:'◇'},thunder:{name:'雷羽印',icon:'ϟ'},tide:{name:'潮汐印',icon:'≈'},tickets:{name:'祈星券',icon:'✧'},threads:{name:'织梦丝',icon:'❖'}};
const w=(id,name,rarity,kind,icon,perk,owner='',detail='')=>({id,name,rarity,kind,icon,perk,owner,detail});
export const WEAPONS=[
 w('compass','远航罗盘',4,'spread',0,'force','','常驻：伤害 +4%，精炼每阶再 +1%。'),w('lantern','流萤星灯',4,'spread',1,'haste','','常驻：支援间隔 -4%，精炼每阶再 -1%。'),
 w('daybreak','黎明星盘',5,'spread',2,'pierce','ember','岚珀专属：普通弹额外穿透一次，精炼提高精英伤害。'),w('sunribbon','日冕流苏',5,'spread',3,'fracture','sol','绯穗专属：晶雷破甲效果增强，精炼提高反应伤害。'),
 w('quill','逐光短刃',4,'laser',4,'force','','常驻：伤害 +4%，精炼每阶再 +1%。'),w('violet','紫电信标',4,'laser',5,'haste','','常驻：支援间隔 -4%，精炼每阶再 -1%。'),
 w('courier','长夜回函',5,'laser',6,'haste','lune','霁弦专属：支援间隔 -10%，精炼每阶再 -1.5%。'),w('eclipse','月蚀之锋',5,'laser',7,'elite','vesper','夜珩专属：对精英与守卫增伤 15%，精炼每阶再 +3%。'),
 w('pearl','潮声贝珠',4,'homing',8,'force','','常驻：伤害 +4%，精炼每阶再 +1%。'),w('sprout','新叶星仪',4,'homing',9,'haste','','常驻：支援间隔 -4%，精炼每阶再 -1%。'),
 w('seashell','归潮明珠',5,'homing',10,'harvest','nerine','澜歌专属：实际回血时获得护盾，精炼提高反应伤害。'),w('windmap','万叶航图',5,'homing',11,'magnet','aster','青翎专属：补给吸取范围 +70，精炼每阶再 +10。')];
export const KIND_NAMES={spread:'星铳',laser:'光刃',homing:'星仪'};
export const SKINS=[{id:'moonlit',hero:'lune',name:'月夜邮差',cost:15,detail:'象牙白与深蓝礼装，银色星纹与长围巾。仅改变立绘、飞行姿态与大招外观。'},{id:'daysea',hero:'ember',name:'黎明航海家',cost:15,detail:'深青与珍珠白航海长衣，黄铜星盘与金色罗盘纹。仅改变外观。'}];
export const CONSTELLATIONS=[{name:'同行之星',text:'全队支援间隔缩短 5%。'},{name:'共鸣之星',text:'元素反应伤害提高 10%。'},{name:'追光之星',text:'自身伤害提高 6%。'},{name:'守望之星',text:'作为主战时，护盾上限 +1。'},{name:'破晓之星',text:'作为主战时，对精英与守卫增伤 10%。'},{name:'归航之星',text:'解锁旅人专属命座效果。'}];
export const C6_TEXT={ember:'主战普通弹额外穿透一次。',lune:'雷潮连锁额外波及一个目标。',nerine:'实际回血时获得一层护盾。',sol:'晶雷额外削减 10 点护甲。',vesper:'主战对精英与守卫再增伤 12%。',aster:'主战补给吸取范围增加 80。'};
export const WISH_RULES={baseRate:.05,softStart:20,hardPity:30,rateStep:.10,targetRate:.5,historyLimit:80,inventoryLimit:120};
