import {FLIGHT_CHARACTERS as HEROES} from './flight-characters.js';
import {ROLES} from './flight-expedition-data.js';
import {HERO_RARITY,WEAPONS,SKINS,WISH_RULES} from './collection-data.js';
const ids=Object.keys(HEROES),valid=id=>ids.includes(id),num=(v,max=999999)=>Math.max(0,Math.min(max,Math.floor(Number(v)||0))),def=id=>WEAPONS.find(w=>w.id===id);
export function freshCamp(){
 const weapons=WEAPONS.filter(w=>w.rarity===4).map((w,i)=>({id:'w'+(i+1),base:w.id,level:1,ascension:0,refine:1})),actors={};
 for(const [i,id]of ids.entries())actors[id]={level:1,ascension:0,constellation:0,shards:0,weapon:weapons.filter(w=>def(w.base).kind===HEROES[id].weapon)[['ember','lune','nerine'].includes(id)?0:1].id,skin:'base'};
 return {version:1,wallet:{coins:2400,books:40,ore:40,crystal:4,thunder:4,tide:4,tickets:30,threads:30},actors,weapons,nextWeapon:7,pity:{character:{count:0,guaranteed:false,target:'ember'},weapon:{count:0,guaranteed:false,target:'daybreak'}},skins:[],history:[],lastDrops:{coins:0,books:0,ore:0,crystal:0,thunder:0,tide:0,tickets:0,threads:0}};
}
export function normalizeCamp(input){
 if(!input||typeof input!=='object'||input.version!==1)return freshCamp();const base=freshCamp(),c={...base,wallet:{},actors:{},weapons:[],skins:[],history:[],lastDrops:{coins:0,books:0,ore:0,crystal:0,thunder:0,tide:0,tickets:0,threads:0}};
 for(const k of Object.keys(base.wallet)){c.wallet[k]=num(input.wallet?.[k]);c.lastDrops[k]=num(input.lastDrops?.[k]);}
 const seen=new Set();for(const x of (Array.isArray(input.weapons)?input.weapons:[]).slice(0,120)){if(!def(x.base)||typeof x.id!=='string'||!/^w\d{1,9}$/.test(x.id)||seen.has(x.id))continue;seen.add(x.id);const a=num(x.ascension,2);c.weapons.push({id:x.id,base:x.base,level:Math.max(1,Math.min(20+a*20,num(x.level,60))),ascension:a,refine:Math.max(1,num(x.refine,5))});}
 if(!c.weapons.length)c.weapons=base.weapons;
 const equipped=new Set();for(const id of ids){const a=input.actors?.[id]||{},asc=num(a.ascension,2);let weapon=c.weapons.find(w=>w.id===a.weapon&&def(w.base).kind===HEROES[id].weapon&&!equipped.has(w.id));if(weapon)equipped.add(weapon.id);c.actors[id]={level:Math.max(1,Math.min(20+asc*20,num(a.level,60))),ascension:asc,constellation:num(a.constellation,6),shards:num(a.shards,99),weapon:weapon?.id||'',skin:SKINS.some(s=>s.id===a.skin&&s.hero===id)&&input.skins?.includes(a.skin)?a.skin:'base'};}
 c.skins=SKINS.filter(s=>Array.isArray(input.skins)&&input.skins.includes(s.id)).map(s=>s.id);
 c.nextWeapon=Math.min(999999999,Math.max(7,num(input.nextWeapon,999999999),...c.weapons.map(w=>Number(w.id.slice(1))+1)));
 for(const pool of ['character','weapon']){const p=input.pity?.[pool]||{},target=pool==='character'?HERO_RARITY[p.target]===5:p.target&&def(p.target)?.rarity===5;c.pity[pool]={count:num(p.count,29),guaranteed:p.guaranteed===true,target:target?p.target:base.pity[pool].target};}
 c.history=(Array.isArray(input.history)?input.history:[]).filter(x=>['character','weapon'].includes(x.pool)&&((x.kind==='hero'&&valid(x.item))||(x.kind==='weapon'&&def(x.item)))).slice(-80).map(x=>({pool:x.pool,kind:x.kind,item:x.item,rarity:x.kind==='hero'?HERO_RARITY[x.item]:def(x.item).rarity,duplicate:!!x.duplicate,reward:['命星 +1','满命转养成材料','武器 +1','武器库已满，转锻星矿'].includes(x.reward)?x.reward:(x.kind==='hero'?'命星 +1':'武器 +1')}));return c;
}
const fail=(camp,message)=>({camp,ok:false,message,draws:[]});
const spend=(c,cost)=>{if(Object.entries(cost).some(([k,n])=>c.wallet[k]<n))return false;for(const[k,n]of Object.entries(cost))c.wallet[k]-=n;return true;};
export function nextCost(c,kind,id){
 if(kind==='hero'){const a=c.actors[id];return a?{coins:70+a.level*8,books:1+Math.floor(a.level/15)}:{}}
 const w=c.weapons.find(w=>w.id===id);return w?{coins:60+w.level*7,ore:1+Math.floor(w.level/15)}:{};
}
export function campAction(input,action={},random=Math.random){
 const c=normalizeCamp(input),a=c.actors[action.hero],w=c.weapons.find(w=>w.id===action.weapon);let message='';
 if(action.type==='target'){
  if(!['character','weapon'].includes(action.pool))return fail(c,'未知卡池');const good=action.pool==='character'?HERO_RARITY[action.target]===5:def(action.target)?.rarity===5;if(!good)return fail(c,'请选择五星定轨目标');c.pity[action.pool].target=action.target;message='定轨已更新，保底进度保留';
 }else if(action.type==='wish'){
  if(!['character','weapon'].includes(action.pool)||![1,10].includes(action.count))return fail(c,'请选择单抽或十连');if(!spend(c,{tickets:action.count}))return fail(c,'祈星券不足；出航与通关可获得');const p=c.pity[action.pool],draws=[];
  const pick=arr=>arr[Math.min(arr.length-1,Math.floor(Math.max(0,Math.min(.999999,Number(random())||0))*arr.length))];
  for(let i=0;i<action.count;i++){
   p.count++;const rate=p.count>=30?1:Math.min(1,.05+Math.max(0,p.count-20)*.10),five=p.count>=30||Number(random())<rate;let item;
   if(five){const target=p.guaranteed||Number(random())<.5;if(action.pool==='character')item=target?p.target:pick(ids.filter(id=>HERO_RARITY[id]===5&&id!==p.target));else item=target?p.target:pick(WEAPONS.filter(w=>w.rarity===5&&w.id!==p.target)).id;p.guaranteed=item!==p.target;p.count=0;}
   else item=action.pool==='character'?pick(ids.filter(id=>HERO_RARITY[id]===4)):pick(WEAPONS.filter(w=>w.rarity===4)).id;
   const result={pool:action.pool,kind:action.pool==='character'?'hero':'weapon',item,rarity:five?5:4,duplicate:action.pool==='character'||c.weapons.some(w=>w.base===item)};
   if(action.pool==='character'){const h=c.actors[item];if(h.constellation+h.shards<6){h.shards++;result.reward='命星 +1'}else{result.reward='满命转养成材料';c.wallet.books+=five?8:3;c.wallet.ore+=five?8:3;c.wallet.threads+=five?2:1;}}
   else if(c.weapons.length<120){c.weapons.push({id:'w'+c.nextWeapon++,base:item,level:1,ascension:0,refine:1});result.reward='武器 +1'}else{c.wallet.ore+=five?20:8;result.reward='武器库已满，转锻星矿'}
   c.history.push(result);draws.push(result);
  }
  c.history=c.history.slice(-80);return {camp:c,ok:true,message:'祈星完成，结果已保存本机',draws};
 }else if(action.type==='levelHero'||action.type==='levelWeapon'){
  const kind=action.type==='levelHero'?'hero':'weapon',x=kind==='hero'?a:w;if(!x)return fail(c,'未找到养成对象');if(x.level>=60)return fail(c,'已达最高等级 60');if(x.level>=20+x.ascension*20)return fail(c,'需要先突破等级上限');const cost=nextCost(c,kind,kind==='hero'?action.hero:action.weapon);if(!spend(c,cost))return fail(c,'升级材料不足');x.level++;message='升级成功 · Lv.'+x.level;
 }else if(action.type==='ascendHero'||action.type==='ascendWeapon'){
  const x=action.type==='ascendHero'?a:w;if(!x)return fail(c,'未找到突破对象');if(x.ascension>=2||x.level<20+x.ascension*20)return fail(c,'20 / 40 级时可以突破');const element=action.type==='ascendHero'?ROLES[action.hero].element:{spread:'crystal',laser:'thunder',homing:'tide'}[def(w.base).kind];if(!spend(c,{coins:400*(x.ascension+1),[element]:2*(x.ascension+1)}))return fail(c,'突破材料不足');x.ascension++;message='突破成功 · 等级上限 '+(20+x.ascension*20);
 }else if(action.type==='constellation'){
  if(!a)return fail(c,'未知旅人');if(a.constellation>=6)return fail(c,'命座已经圆满');if(a.shards<1)return fail(c,'抽到同名旅人可获得命星');a.shards--;a.constellation++;message='命座点亮 · C'+a.constellation;
 }else if(action.type==='equip'){
  if(!a||!w||def(w.base).kind!==HEROES[action.hero].weapon)return fail(c,'武器类型不适合该旅人');const owner=ids.find(id=>c.actors[id].weapon===w.id);if(owner&&owner!==action.hero)c.actors[owner].weapon=a.weapon;a.weapon=w.id;message=owner&&owner!==action.hero?'已交换两位旅人的武器':'武器已装备';
 }else if(action.type==='refine'){
  if(!w||w.refine>=5)return fail(c,'武器精炼已达上限');const equipped=Object.values(c.actors).map(a=>a.weapon),copy=c.weapons.find(v=>v.id!==w.id&&v.base===w.base&&v.level===1&&v.refine===1&&!equipped.includes(v.id));if(!copy)return fail(c,'需要一把未装备、未培养的同名武器');if(!spend(c,{coins:200*w.refine}))return fail(c,'星铸币不足');c.weapons=c.weapons.filter(v=>v.id!==copy.id);w.refine++;message='精炼成功 · R'+w.refine;
 }else if(action.type==='skin'){
  const skin=SKINS.find(s=>s.id===action.skin);if(!a||(action.skin!=='base'&&skin?.hero!==action.hero))return fail(c,'服装不属于这位旅人');if(skin&&!c.skins.includes(skin.id)){if(!spend(c,{threads:skin.cost}))return fail(c,'织梦丝不足；通关和满命重复可获得');c.skins.push(skin.id)}a.skin=action.skin;message='外观已更换 · 不影响战斗属性';
 }else return fail(c,'未知养成操作');
 return {camp:c,ok:true,message,draws:[]};
}
export function battleBuild(input,main,support,trial='voyage'){
 const c=normalizeCamp(input),make=id=>{
  const a=c.actors[id]||{level:1,constellation:0,skin:'base'},w=c.weapons.find(w=>w.id===a.weapon),d=w&&def(w.base),r=w?.refine||1,C=a.constellation;
  const b={damage:1+(a.level-1)*.003+(w?(w.level-1)*.003:0)+(C>=3?.06:0),interval:C>=1?.95:1,reaction:C>=2?.1:0,shieldCap:C>=4?1:0,elite:C>=5?.1:0,pierce:0,chain:0,magnet:0,harvest:false,armor:0,skin:a.skin,level:a.level,constellation:C,weapon:d?.name||'基础武装'};
  if(d?.rarity===4){if(d.perk==='force')b.damage+=.04+(r-1)*.01;else b.interval*=1-.04-(r-1)*.01;}
  if(d?.rarity===5){b.damage+=.06;if(d.owner===id){if(d.perk==='pierce'){b.pierce++;b.elite+=(r-1)*.025}if(d.perk==='haste')b.interval*=.90-(r-1)*.015;if(d.perk==='elite')b.elite+=.15+(r-1)*.03;if(d.perk==='fracture'){b.armor+=5+r*2;b.reaction+=(r-1)*.03}if(d.perk==='harvest'){b.harvest=true;b.reaction+=(r-1)*.03}if(d.perk==='magnet')b.magnet+=70+(r-1)*10;}}
  if(C>=6){if(id==='ember')b.pierce++;if(id==='lune')b.chain++;if(id==='nerine')b.harvest=true;if(id==='sol')b.armor+=10;if(id==='vesper')b.elite+=.12;if(id==='aster')b.magnet+=80;}
  return b;
 };
 if(trial!=='voyage')return null;return {main:make(main),support:make(support)};
}
export function rewardCamp(input,result){
 const c=normalizeCamp(input),time=Math.min(360,num(result.elapsed)),stages=Math.min(3,num(result.stagesCleared)),active=time>=10||stages>0;
 const drops={coins:active?120+Math.floor(time*3)+stages*200:0,books:active?2+Math.floor(time/30)+stages*2:0,ore:active?2+Math.floor(time/35)+stages*2:0,tickets:active?1+Math.floor(time/60)+stages:0,threads:stages*2,crystal:0,thunder:0,tide:0};
 if(active){const element=ROLES[result.main]?.element||'crystal';drops[element]=stages;for(const k of ['books','ore','coins','crystal','thunder','tide'])drops[k]+=Math.min(30,num(result.loot?.[k]));}
 for(const [k,v]of Object.entries(drops))c.wallet[k]=Math.min(999999,c.wallet[k]+v);c.lastDrops=Object.fromEntries(Object.keys(c.wallet).map(k=>[k,drops[k]||0]));return c;
}
