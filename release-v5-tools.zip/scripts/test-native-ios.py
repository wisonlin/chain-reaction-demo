#!/usr/bin/env python3
"""One command: shared rules, native XCTest/XCUITest, Release performance gates."""
import argparse,datetime,json,subprocess,sys
from pathlib import Path
ROOT=Path(__file__).resolve().parents[1]
p=argparse.ArgumentParser();p.add_argument('--output',type=Path,default=Path('artifacts/native-qa/runs')/datetime.datetime.now().strftime('%Y%m%d-%H%M%S'));p.add_argument('--trace',action='store_true');a=p.parse_args()
out=a.output.resolve();out.mkdir(parents=True,exist_ok=True)
config=json.loads((ROOT/'.asc/native-qa.json').read_text());results={'schema':1,'startedAt':datetime.datetime.now(datetime.timezone.utc).isoformat(),'tests':[],'performance':[],'passed':False}
def run(args,log=None,check=True):
    if log:
        with (out/log).open('w') as f:r=subprocess.run(args,cwd=ROOT,stdout=f,stderr=subprocess.STDOUT)
        stdout=''
    else:
        r=subprocess.run(args,cwd=ROOT,capture_output=True,text=True);stdout=r.stdout
    if check and r.returncode:raise RuntimeError(f'Failed: {args[:4]}; log={log or r.stderr}')
    return stdout
try:
    run(['npm','test'],'shared.log')
    run([sys.executable,'-m','unittest','discover','-s','scripts','-p','test_native_qa_tools.py'],'qa-tools.log')
    run(['node','scripts/prepare-native-ios.mjs'],'prepare.log')
    run(['xcodegen','generate','--spec','native-ios/project.yml'],'project.log')
    inventory=json.loads(run(['xcrun','simctl','list','devices','-j']))
    devices=[d for group in inventory['devices'].values() for d in group]
    targets=[]
    for s in config['simulators']:
        d=next((d for d in devices if d['name']==s['name'] and d.get('isAvailable')),None)
        udid=d['udid'] if d else run(['xcrun','simctl','create',s['name'],s['type'],config['runtime']]).strip()
        if not d or d['state']!='Booted':run(['xcrun','simctl','boot',udid])
        run(['xcrun','simctl','bootstatus',udid,'-b'],s['name'].replace(' ','-')+'-boot.log')
        targetName='iphone' if 'iPhone' in s['name'] else 'ipad'
        bundle=out/(targetName+'.xcresult')
        run(['xcodebuild','-project',config['project'],'-scheme',config['scheme'],'-configuration','Debug','-destination',f'platform=iOS Simulator,id={udid}','-parallel-testing-enabled','NO','-derivedDataPath',str(out/'TestBuild'),'-resultBundlePath',str(bundle),'CODE_SIGNING_ALLOWED=NO','test'],targetName+'-tests.log',check=False)
        summary=json.loads(run(['xcrun','xcresulttool','get','test-results','summary','--path',str(bundle),'--compact']))
        (out/(targetName+'-summary.json')).write_text(json.dumps(summary,indent=2))
        run(['xcrun','xcresulttool','export','attachments','--path',str(bundle),'--output-path',str(out/(targetName+'-attachments'))],targetName+'-attachments.log')
        results['tests'].append({'target':targetName,'passed':summary.get('failedTests',1)==0,'summary':summary})
        if summary.get('failedTests',1):raise RuntimeError(targetName+' test failures')
        targets.append(udid)
    run(['xcodebuild','-project',config['project'],'-scheme',config['scheme'],'-configuration','Release','-destination',f'platform=iOS Simulator,id={targets[0]}','-derivedDataPath',str(out/'ReleaseBuild'),'CODE_SIGNING_ALLOWED=NO','build'],'release-build.log')
    for case in config['cases']:
        caseOut=out/case['name']
        args=[sys.executable,'scripts/profile-native-ios.py','--udid',targets[0],'--app',str(out/'ReleaseBuild/Build/Products/Release-iphonesimulator/Starborne.app'),'--output',str(caseOut),'--character',case['character'],'--duration',str(case['duration'])]
        if case.get('legacy'):args+=['--legacy']
        if case.get('support'):args+=['--support',case['support']]
        if case['hard']:args+=['--hard']
        if case.get('power'):args+=['--power',str(case['power']),'--stage',str(case.get('stage',0))]
        if a.trace:args+=['--trace']
        run(args,case['name']+'.log')
        result=json.loads(run([sys.executable,'scripts/check-native-performance.py',str(caseOut/'frames.json'),'--output',str(caseOut/'gate.json')]))
        results['performance'].append({'case':case['name'],**result})
    results['passed']=all(t['passed'] for t in results['tests']) and all(t['passed'] for t in results['performance'])
except Exception as e:results['error']=str(e)
finally:
    results['finishedAt']=datetime.datetime.now(datetime.timezone.utc).isoformat()
    (out/'summary.json').write_text(json.dumps(results,ensure_ascii=False,indent=2))
    print(json.dumps({'output':str(out),'passed':results['passed'],'error':results.get('error')}))
raise SystemExit(0 if results['passed'] else 1)
