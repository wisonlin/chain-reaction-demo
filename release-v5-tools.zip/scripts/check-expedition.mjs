import {VerticalShooter,flightClamp,flightSegmentHit} from '../src/flight-game.js';
import {FLIGHT_CHARACTERS} from '../src/flight-characters.js';
import {TRIALS} from '../src/flight-expedition-data.js';
import {writeFile,mkdir} from 'node:fs/promises';

function simulate(seed,character,height=1000,hard=false,trial='voyage'){
  const weapon=FLIGHT_CHARACTERS[character].weapon,forward=true;let state=seed;const random=()=>((state=(state*1664525+1013904223)>>>0)/4294967296),g=new VerticalShooter(random,{height});g.reset({strategy:true,character,support:character==='nerine'?'lune':'nerine',hard,trial,autoDraft:true});
  let target={x:240,y:g.player.y},nextDecision=0,maxBullets=0,maxEnemies=0,firstKill=null,firstPower=null,maxStage=0,frames=0;
  while(g.state==='playing'&&g.elapsed<360&&frames++<30000){
    const p=g.player;
    if(g.elapsed>=nextDecision){
      nextDecision=g.elapsed+.1;
      let goal={x:g.boss?.x||240+Math.sin(g.elapsed*.65)*130,y:forward?Math.min(height*.7,(g.boss?.y||height*.35)+g.spiritRange*.72):height*.75};
      const heavy=g.enemies.filter(e=>!e.dead&&e.y>50&&e.y<p.y-100).sort((a,b)=>(b.type==='gunship'?1000:b.y)-(a.type==='gunship'?1000:a.y))[0];
      if(heavy)goal.x=heavy.x;
      const valuable=g.pickups.filter(q=>q.y>height*.33&&q.y<height-70&&(q.type==='heal'&&p.lives<3||q.type==='power'&&p.power<6||q.type==='bomb'&&p.bombs<3||q.type==='weapon'&&p.power<6&&g.pickupWeapon(q)===weapon)).sort((a,b)=>Math.hypot(a.x-p.x,a.y-p.y)-Math.hypot(b.x-p.x,b.y-p.y))[0];
      if(valuable&&Math.hypot(valuable.x-p.x,valuable.y-p.y)<280)goal={x:valuable.x,y:valuable.y};
      let best=Infinity;
      const candidates=[];for(const dx of [-90,-45,0,45,90])for(const dy of [-55,0,55])candidates.push({x:flightClamp(p.x+dx,30,450),y:flightClamp(p.y+dy,height*.45,height-90)});
      candidates.push({x:flightClamp(goal.x,p.x-90,p.x+90),y:flightClamp(goal.y,p.y-55,p.y+55)});
      for(const c of candidates){
        let risk=Math.hypot(c.x-goal.x,c.y-goal.y)*.035+Math.hypot(c.x-p.x,c.y-p.y)*.012;
        for(const b of g.bullets){if(b.dead)continue;const vx=b.vx*.48,vy=b.vy*.48,t=flightClamp(((c.x-b.x)*vx+(c.y-b.y)*vy)/(vx*vx+vy*vy||1),0,1),d=Math.hypot(b.x+vx*t-c.x,b.y+vy*t-c.y);if(d<95)risk+=(95-d)*(95-d)*.018;if(d<20)risk+=500;}
        for(const e of g.enemies){if(e.ground||e.dead)continue;const d=Math.hypot(c.x-e.x,c.y-e.y);if(d<e.rx+45)risk+=Math.pow(e.rx+45-d,2)*.3;}
        for(const h of g.hazards)if(h.warmup-h.age<.7&&Math.abs(c.x-h.x)<h.width/2+24)risk+=1200;
        if(risk<best){best=risk;target=c;}
      }
      const danger=g.bullets.some(b=>flightSegmentHit(b.x,b.y,b.x+b.vx*.2,b.y+b.vy*.2,p.x,p.y,p.r+b.r+4));
      if(p.invincible<.1&&p.bombs>0&&g.bombCooldown<=0&&(danger||g.boss?.secondPhase&&g.boss.hp>100&&g.boss.hp<g.boss.maxHp*.45))g.useBomb();
    }
    g.update(1/60,{target});maxBullets=Math.max(maxBullets,g.bullets.length);maxEnemies=Math.max(maxEnemies,g.enemies.length);maxStage=Math.max(maxStage,g.stageIndex);
    for(const e of g.events){if(e.type==='kill'&&firstKill===null)firstKill=g.elapsed;if(e.type==='powerup'&&firstPower===null)firstPower=g.elapsed;}g.events=[];
  }
  return {seed,character,trial,hard,choices:g.strategy.choiceCount,reactions:g.strategy.reactions,assists:g.strategy.assists,blessings:g.strategy.snapshot().blessings.map(b=>b.id),weapon,height,strategy:forward?'forward':'rear',grazes:g.grazes,maxTension:g.maxTension,spiritKills:g.spiritKills,won:!!g.won,state:g.state,stage:maxStage+1,seconds:+g.elapsed.toFixed(1),score:g.score,kills:g.kills,lives:g.player.lives,power:g.player.power,bombsUsed:g.bombsUsed,firstKill:+firstKill?.toFixed(2),firstPower:firstPower===null?null:+firstPower.toFixed(2),maxBullets,maxEnemies,bossHp:Math.round(g.boss?.hp||0)};
}
const runs=[];for(const character of Object.keys(FLIGHT_CHARACTERS))for(const hard of [false,true]){const run=simulate(42,character,1000,hard);runs.push(run);console.log(JSON.stringify(run));}
for(const trial of TRIALS){const run=simulate(trial.seed,trial.main,1000,trial.hard,trial.id);runs.push(run);console.log(JSON.stringify(run));}
await mkdir(new URL('../artifacts/balance/',import.meta.url),{recursive:true});await writeFile(new URL('../artifacts/balance/starborne-v5.json',import.meta.url),JSON.stringify({note:'Seeded automated play with normal lives and limited ultimates; not human win rate or fun rating.',runs},null,2)+'\n');
console.log(`${runs.filter(r=>r.won).length}/${runs.length} completed all three sectors.`);
if(runs.some(r=>r.state!=='over'||r.choices>6))throw new Error('Run failed terminal state or choice limit.');
