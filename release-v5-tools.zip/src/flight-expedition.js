import {FLIGHT_CHARACTERS} from './flight-characters.js';
import {ROLES,BLESSINGS,TRIALS} from './flight-expedition-data.js';
const ids=Object.keys(ROLES),dist=(a,b)=>Math.hypot(a.x-b.x,a.y-b.y),elite=e=>['boss','gunship','carrier'].includes(e.type);
export function resolveSquad(main,support){main=ROLES[main]?main:'lune';support=ROLES[support]&&support!==main?support:ids.find(id=>ROLES[id].element!==ROLES[main].element);return {main,support}}
export class FlightExpedition {
 constructor(game,options){
  Object.defineProperty(this,'game',{value:game,enumerable:false});Object.assign(this,resolveSquad(options.character,options.support));this.runId=options.runId||'local';this.trial=TRIALS.some(t=>t.id===options.trial)?options.trial:'voyage';this.talent=options.talent==='signature'&&this.trial==='voyage'?'signature':'balanced';this.autoDraft=!!options.autoDraft;
  this.stacks={};this.draft=[];this.choiceCount=0;this.draftIndex=0;this.castTimer=1.8;this.reactions=0;this.assists=0;this.heals=0;this.lastWard=-99;this.fx=[];this.grazeCount=0;this.castFlash=0;
  if(this.trial==='circuit')this.stacks.chain=1;
 }
 get mainElement(){return ROLES[this.main].element}
 get supportElement(){return ROLES[this.support].element}
 get shieldCap(){return 1+this.level('ward')+(this.talent==='signature'&&this.main==='ember'?1:0)}
 get interval(){return ROLES[this.support].interval*Math.max(.55,1-this.level('resonance')*.12)*(this.main==='aster'?.9:1)*(this.talent==='signature'?(this.main==='lune'?.85:this.main==='nerine'?1.15:this.main==='sol'?1.18:1):1)}
 get magnet(){return this.level('salvage')*70+(this.main==='nerine'?45:0)+(this.talent==='signature'&&this.main==='aster'?80:0)}
 get bulletScale(){return 1+this.level('overdrive')*.08}
 level(id){return this.stacks[id]||0}
 damageScale(enemy){
  let x=1+this.level('overdrive')*.22+(elite(enemy)?this.level('focus')*.22:0);
  if(this.main==='ember'&&this.game.tension>1)x+=.12;if(this.main==='sol'&&this.game.player.power===6)x+=.15;if(this.main==='vesper'&&elite(enemy))x+=.15;
  if(this.talent==='signature'){if(this.main==='sol')x+=.12;if(['ember','lune','aster'].includes(this.main))x-=this.main==='ember'?.06:.08;if(this.main==='vesper')x+=elite(enemy)?.24:-.1;}
  if(enemy.fracture>0)x+=.18;if(enemy.exposed>0)x+=.3;return x;
 }
 shield(amount=1){const p=this.game.player;p.shield=Math.min(this.shieldCap,(p.shield||0)+amount)}
 wardPickup(x,y){
  const g=this.game;if(g.elapsed-this.lastWard<9||g.pickups.some(p=>p.type==='shield'&&!p.dead))return;
  this.lastWard=g.elapsed;g.pickups.push(g.makePickup('shield',x,y));
 }
 effect(kind,e,target=e){this.fx.push({kind,x:e.x,y:e.y,toX:target.x,toY:target.y,life:.38});if(this.fx.length>12)this.fx.shift()}
 breakArmor(e,damage){
  if(!(e.armor>0))return;e.armor=Math.max(0,e.armor-damage);
  if(e.armor===0){e.exposed=5;this.effect('fracture',e);this.game.event('armorBreak',{x:e.x,y:e.y,name:'护甲击破 · 5秒破绽'});}
 }
 onHit(e,element){
  if(!element||e.dead)return;
  if(!e.element||e.element===element||e.elementTime<=0){e.element=element;e.elementTime=3;return;}
  if(e.reactionLock>0)return;
  const g=this.game,p=g.player,pair=[e.element,element].sort().join('+');e.element='';e.elementTime=0;e.reactionLock=.85;
  this.reactions++;const damage=(4+p.power*.9)*(1+this.level('surge')*.25)*(this.main==='lune'?1.18:1);
  let kind='ward',name='晶潮 · 星帆';
  if(pair==='thunder+tide'){
   kind='chain';name='雷潮 · 连锁';const candidates=g.enemies.filter(t=>!t.dead&&t.y>=100&&dist(e,t)<180).sort((a,b)=>dist(e,a)-dist(e,b)).slice(0,3+this.level('chain'));
   for(const t of candidates){this.effect(kind,e,t);g.damageEnemy(t,damage,true,false)}
  }else if(pair==='crystal+thunder'){
   kind='fracture';name='晶雷 · 破甲';e.fracture=3.2;this.effect(kind,e);this.breakArmor(e,30);g.damageEnemy(e,damage*1.35,true,false);
  }else{this.effect(kind,e);this.wardPickup(e.x,e.y);g.damageEnemy(e,damage*.65,true,false)}
  this.breakArmor(e,8);g.event('reaction',{x:e.x,y:e.y,kind,name});
  if(this.level('covenant')&&this.reactions%10===0&&this.heals<2&&p.lives<3){this.heals++;g.collect(g.makePickup('heal',p.x,p.y))}
 }
 cast(){
  const g=this.game,p=g.player;let targets=g.enemies.filter(e=>!e.dead&&e.y>=100&&e.y<p.y+30&&!(e.type==='boss'&&e.intro>0));
  if(!targets.length){this.castTimer=.2;return}
  if(this.support==='vesper')targets.sort((a,b)=>b.maxHp-a.maxHp);else targets.sort((a,b)=>dist(a,p)-dist(b,p));
  const count=ROLES[this.support].targets+(this.talent==='signature'&&this.main==='nerine'?2:0);this.assists++;this.castTimer=this.interval;this.castFlash=.65;
  for(const e of targets.slice(0,count)){
   this.effect('assist',{x:p.x,y:p.y-35},e);
   g.damageEnemy(e,(this.support==='vesper'?13:this.support==='sol'?7:3.2)+p.power*.7,true,this.supportElement);
   if(this.support==='vesper')this.breakArmor(e,18);
  }
  if(this.support==='ember'&&this.assists%2===0)this.wardPickup(p.x,Math.max(150,p.y-140));
  if(this.support==='aster')for(const q of g.pickups)if(q.type==='medal'&&dist(q,p)<350)q.homing=true;
  g.event('assist',{x:p.x,y:p.y,kind:this.supportElement,name:ROLES[this.support].support});
 }
 offer(){
  if(this.game.state!=='playing')return false;
  const available=BLESSINGS.filter(b=>this.level(b.id)<b.max&&(b.id!=='chain'||new Set([this.mainElement,this.supportElement]).has('thunder')&&new Set([this.mainElement,this.supportElement]).has('tide')));
  const pick=pool=>{if(!pool.length)return null;return pool[Math.floor(this.game.random()*pool.length)]};
  const options=[];for(const category of ['reaction','attack','survival']){const b=pick(available.filter(x=>x.category===category&&!options.includes(x)));if(b)options.push(b)}
  if(this.choiceCount%2===1){const risk=pick(available.filter(x=>x.category==='risk'));if(risk)options[1]=risk}
  if(!options.length)return false;
  this.draft=options.map(b=>({...b,stacks:this.level(b.id)}));this.game.state='draft';this.game.event('draft',{name:'航路祝福'});
  if(this.autoDraft)this.choose(this.draft[this.choiceCount%this.draft.length].id);return true;
 }
 choose(id){
  if(this.game.state!=='draft'||!this.draft.some(b=>b.id===id))return false;
  const b=BLESSINGS.find(b=>b.id===id);this.stacks[id]=Math.min(b.max,this.level(id)+1);this.choiceCount++;this.draft=[];
  if(id==='ward')this.shield();if(id==='resonance')this.castTimer=Math.min(this.castTimer,this.interval);
  this.game.state='playing';this.game.player.invincible=Math.max(this.game.player.invincible,.65);this.game.event('blessing',{name:b.name,kind:id,x:this.game.player.x,y:this.game.player.y});return true;
 }
 onEvent(type,data){
  if(type==='graze'&&this.level('graze')){this.grazeCount++;if(this.grazeCount%5===0)this.castTimer=Math.max(0,this.castTimer-1.2*this.level('graze'))}
  if(type==='bomb'&&this.level('pulse'))this.castTimer=0;
  if(type==='heal'&&(this.level('harvest')||this.support==='nerine'))this.shield();
  if(type==='partDown'){const boss=this.game.boss;if(boss)this.breakArmor(boss,32)}
 }
 update(dt){
  this.castFlash=Math.max(0,this.castFlash-dt);this.castTimer-=dt;this.fx=this.fx.filter(f=>(f.life-=dt)>0);
  for(const e of this.game.enemies){e.elementTime=Math.max(0,(e.elementTime||0)-dt);e.reactionLock=Math.max(0,(e.reactionLock||0)-dt);e.fracture=Math.max(0,(e.fracture||0)-dt);e.exposed=Math.max(0,(e.exposed||0)-dt);if(!e.elementTime)e.element=''}
  if(this.castTimer<=0&&this.game.phase!=='clear')this.cast();
  if(this.game.phase==='approach'&&this.draftIndex<2&&this.game.stageTime>=(this.draftIndex===0?12:32)){this.draftIndex++;this.offer()}
 }
 snapshot(){return {main:this.main,support:this.support,element:this.mainElement,supportElement:this.supportElement,supportCharge:Math.max(0,Math.min(1,1-this.castTimer/this.interval)),castFlash:this.castFlash,reactions:this.reactions,assists:this.assists,choiceCount:this.choiceCount,trial:this.trial,talent:this.talent,draft:this.draft,blessings:BLESSINGS.filter(b=>this.level(b.id)).map(b=>({...b,stacks:this.level(b.id)})),fx:this.fx}}
 result(){const g=this.game;return {runId:this.runId,main:this.main,support:this.support,trial:this.trial,won:!!g.won,score:g.score,elapsed:g.elapsed,reactions:this.reactions,assists:this.assists}}
}
