import {FLIGHT_CHARACTERS} from './flight-characters.js';
import {TRIALS,MASTERY_STEPS} from './flight-expedition-data.js';
const number=(x,max=1e9)=>Math.max(0,Math.min(max,Math.floor(Number(x)||0)));
export function normalizeProgress(input={}){
 if(typeof input==='string'){try{input=JSON.parse(input)}catch{input={}}}if(!input||typeof input!=='object')input={};
 const heroes={};for(const id of Object.keys(FLIGHT_CHARACTERS)){const h=input.heroes?.[id]||{};heroes[id]={xp:number(h.xp,99999),runs:number(h.runs),wins:number(h.wins),reactions:number(h.reactions)}}
 const trialBest={};for(const t of TRIALS)trialBest[t.id]=number(input.trialBest?.[t.id]);
 return {schema:1,runs:number(input.runs),wins:number(input.wins),totalScore:number(input.totalScore),heroes,trialBest,recent:(Array.isArray(input.recent)?input.recent:[]).filter(x=>typeof x==='string').slice(-64)};
}
export function masteryLevel(xp){return MASTERY_STEPS.slice(1).filter(n=>xp>=n).length}
export function settleProgress(input,result){
 const p=normalizeProgress(input);if(!result||!result.runId||!FLIGHT_CHARACTERS[result.main]||!FLIGHT_CHARACTERS[result.support]||p.recent.includes(result.runId))return p;
 p.recent.push(String(result.runId));p.recent=p.recent.slice(-64);p.runs++;p.wins+=Number(!!result.won);p.totalScore=number(p.totalScore+number(result.score));
 const xp=Math.min(160,20+Math.floor(Math.min(360,number(result.elapsed))*.28)+Math.min(40,number(result.reactions))*2+(result.won?45:0));
 for(const [id,mult] of [[result.main,1],[result.support,.55]]){const h=p.heroes[id];h.xp=number(h.xp+Math.round(xp*mult),99999);h.runs++;h.wins+=Number(!!result.won);h.reactions+=number(result.reactions)}
 if(TRIALS.some(t=>t.id===result.trial))p.trialBest[result.trial]=Math.max(p.trialBest[result.trial],number(result.score));
 return p;
}
