import {ROLES,ELEMENTS,TRIALS,MEMORIES} from './flight-expedition-data.js';
import {normalizeProgress,settleProgress,masteryLevel} from './flight-progress.js';
import {FLIGHT_CHARACTERS as HEROES} from './flight-characters.js';
import {PORTRAIT_ASSETS} from './portrait-assets.js';
const $=id=>document.getElementById(id),key='starborne.expedition.progress.v1';
export class ExpeditionUI {
 constructor({game,character,select,start,clearInput}){
  Object.assign(this,{game,character,select,start,clearInput});this.trial='voyage';this.support='nerine';this.talent='balanced';this.progress=normalizeProgress({});
  try{this.progress=normalizeProgress(localStorage.getItem(key));this.support=localStorage.getItem('starborne-support')||'nerine';}catch{}
  $('home-options').insertAdjacentHTML('beforeend','<section class="squad-box"><div class="loadout-label"><span>自动支援</span><button id="journal-open">旅人手记 ↗</button></div><div id="support-list" class="support-list"></div><p id="squad-detail"></p><button id="talent-select" class="talent-select"></button><button id="trial-open" class="trial-open">常驻试炼 <span>固定航路 · 本机纪录 ↗</span></button></section>');
  $('battle-panel').insertAdjacentHTML('beforeend','<div class="support-status"><span id="support-state"></span><span id="ward-state"></span><i><b id="support-charge"></b></i></div>');
  document.body.insertAdjacentHTML('beforeend','<dialog id="expedition-dialog" class="expedition-dialog"><button class="dialog-close" aria-label="关闭">×</button><div id="expedition-content"></div></dialog>');
  $('game-wrap').insertAdjacentHTML('beforeend','<div id="blessing-draft" class="blessing-draft" hidden><div><small>航路祝福 / 时间已暂停</small><h2>选一份力量，<br>走自己的航路。</h2><p id="draft-count"></p><div id="blessing-choices"></div><p class="draft-tip">点击即继续 · 组合效果叠加至本局结束</p></div></div>');
  $('expedition-dialog').querySelector('.dialog-close').onclick=()=>$('expedition-dialog').close();
  $('trial-open').onclick=()=>this.trials();$('journal-open').onclick=()=>this.journal();
  $('talent-select').onclick=()=>{this.talent=this.talent==='signature'?'balanced':'signature';this.refresh(false);};
 }
 refresh(loadTalent=true){
  const main=this.character(),role=ROLES[main],hero=HEROES[main],xp=this.progress.heroes[main].xp;
  if(!ROLES[this.support]||this.support===main)this.support=Object.keys(ROLES).find(id=>ROLES[id].element!==role.element);
  if(loadTalent){try{this.talent=localStorage.getItem('starborne-talent-'+main)||'balanced';}catch{}}
  if(xp<80)this.talent='balanced';
  try{localStorage.setItem('starborne-support',this.support);localStorage.setItem('starborne-talent-'+main,this.talent);}catch{}
  $('support-list').replaceChildren(...Object.keys(ROLES).filter(id=>id!==main).map(id=>{
   const b=document.createElement('button');b.setAttribute('aria-pressed',String(id===this.support));b.setAttribute('aria-label','支援'+HEROES[id].name);b.innerHTML=`<img src="${PORTRAIT_ASSETS[id].thumbnail}" alt=""><strong>${HEROES[id].name}</strong><small>${ELEMENTS[ROLES[id].element].name}</small>`;
   b.onclick=()=>{this.support=id;this.trial='voyage';this.refresh(false);};return b;
  }));
  const partner=ROLES[this.support],pair=[role.element,partner.element].sort().join('+'),reaction=pair==='thunder+tide'?'雷潮连锁 · 波及附近敌人':pair==='crystal+thunder'?'晶雷破甲 · 打出守卫破绽':pair==='crystal+tide'?'晶潮星帆 · 掉落抵伤护盾':'同元素 · 专注支援火力';
  $('squad-detail').innerHTML=`<strong>${reaction}</strong><br>主战：${role.passive}<br>支援：每 ${partner.interval} 秒 · ${partner.detail}`;
  const b=$('talent-select');b.disabled=xp<80;b.textContent=xp<80?`熟练 ${xp}/80 · 解锁专长与第一篇手记`:(this.talent==='signature'?`${role.talent} · ${role.tradeoff}`:'均衡航行 · 点击切换角色专长');b.setAttribute('aria-pressed',String(this.talent==='signature'));
  $('character-method').textContent=`${ELEMENTS[role.element].name} · ${hero.normal} · 熟练 ${xp}`;
 }
 options(){return {strategy:true,character:this.character(),support:this.support,trial:this.trial,talent:this.talent,runId:globalThis.crypto?.randomUUID?.()||Date.now().toString(36)+Math.random().toString(36).slice(2)}}
 settle(){const g=this.game();if(!g.strategy)return;const before=this.progress.heroes[this.character()].xp;this.progress=settleProgress(this.progress,g.strategy.result());try{localStorage.setItem(key,JSON.stringify(this.progress));}catch{}return this.progress.heroes[this.character()].xp-before}
 hud(){const g=this.game(),s=g.strategy; if(!s){$('support-state').textContent='伙伴自动协战';$('ward-state').textContent='护盾 0';$('support-charge').style.width='0%';return}
  $('support-state').textContent=`${HEROES[s.support].name} · 支援`; $('ward-state').textContent=`护盾 ${g.player.shield} · 连携 ${s.reactions}`;$('support-charge').style.width=(s.snapshot().supportCharge*100)+'%';
 }
 draft(){
  const g=this.game(),root=$('blessing-draft');if(g.state!=='draft'){root.hidden=true;return}if(!root.hidden)return;
  this.clearInput();root.hidden=false;$('draft-count').textContent=`第 ${g.strategy.choiceCount+1}/6 次抉择 · 已获得 ${g.strategy.snapshot().blessings.map(b=>b.name+' '+g.strategy.level(b.id)).join(' / ')||'无'}`;
  $('blessing-choices').replaceChildren(...g.strategy.draft.map(b=>{const el=document.createElement('button');el.className='blessing-card';el.dataset.blessing=b.id;el.innerHTML=`<span>${b.icon}</span><div><small>${{reaction:'元素连携',attack:'火力强化',survival:'生存策略',risk:'风险契约'}[b.category]} · ${b.stacks+1}/${b.max}</small><strong>${b.name}</strong><p>${b.text}</p></div><b>↗</b>`;el.onclick=()=>{this.clearInput();if(g.strategy.choose(b.id)){root.hidden=true;$('game').focus({preventScroll:true});}};return el}));
 }
 open(html){$('expedition-content').innerHTML=html;$('expedition-dialog').showModal();$('expedition-dialog').scrollTop=0;}
 trials(){this.open(`<small>永远开放 / 离线单人</small><h2>常驻试炼</h2><p>固定配队、固定种子与初始条件。祝福由你选，纪录只留在这台设备。</p><div class="trial-cards">${TRIALS.map(t=>`<button data-trial="${t.id}"><small>${t.subtitle}</small><h3>${t.name}</h3><p>${HEROES[t.main].name} + ${HEROES[t.support].name} · ${t.hard?'困难':'普通'}</p><p>${t.detail}</p><strong>本机最高 ${(this.progress.trialBest[t.id]||0).toLocaleString()}　开始 ↗</strong></button>`).join('')}</div>`);
  for(const b of document.querySelectorAll('[data-trial]'))b.onclick=()=>{const t=TRIALS.find(t=>t.id===b.dataset.trial);this.select(t.main);this.support=t.support;this.trial=t.id;this.talent='balanced';$('expedition-dialog').close();this.start(t.hard);};
 }
 journal(){const id=this.character(),hero=HEROES[id],p=this.progress.heroes[id],level=masteryLevel(p.xp);this.open(`<small>本机成长 / 无需登录</small><h2>${hero.name} · 旅人手记</h2><div class="journal-hero"><img src="${PORTRAIT_ASSETS[id].image}" alt="${hero.name}全身立绘"><div><h3>熟练 ${p.xp}</h3><p>航行 ${p.runs} 次<br>通关 ${p.wins} 次<br>连携 ${p.reactions} 次</p><p>${level?'已解锁专长：'+ROLES[id].talent:'80 熟练解锁角色专长'}</p></div></div><p>出航和连携都会积累熟练。主战获得完整熟练，支援获得 55%；专长有取舍，不强制提高数值。</p>${MEMORIES[id].map((chapter,i)=>`<article class="memory"><small>手记 ${i+1} · ${[80,220,450][i]} 熟练</small><h3>${level>i?chapter[0]:'尚未抵达的回忆'}</h3><p>${level>i?chapter[1]:'继续带这位旅人出航，即可读到新的故事。'}</p></article>`).join('')}`);}
}
