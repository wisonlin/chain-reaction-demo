export const ELEMENTS={crystal:{name:'辉晶',icon:'◇',color:'#f4ca79'},thunder:{name:'雷电',icon:'ϟ',color:'#c7a0ff'},tide:{name:'潮汐',icon:'≈',color:'#8fdbf5'}};
export const ROLES={
 ember:{element:'crystal',passive:'星势达到 ×2 时，主武器增伤 12%',support:'星帆庇护',detail:'每 7 秒晶击三名敌人；每两次支援生成护盾碎片。',interval:7,targets:3,talent:'近卫星帆',tradeoff:'护盾上限 +1，主武器伤害降低 6%'},
 lune:{element:'thunder',passive:'元素联动伤害提高 18%',support:'电羽齐鸣',detail:'每 5 秒雷击四名敌人，适合与潮汐连锁清场。',interval:5,targets:4,talent:'疾雷传讯',tradeoff:'支援间隔缩短 15%，主武器伤害降低 8%'},
 nerine:{element:'tide',passive:'补给吸附范围扩大 45',support:'万潮留痕',detail:'每 5.5 秒为四名敌人附加潮印；回血时获得额外护盾。',interval:5.5,targets:4,talent:'长潮回声',tradeoff:'支援多命中两名敌人，支援间隔增加 15%'},
 sol:{element:'crystal',passive:'满火力时主武器增伤 15%',support:'朝阳巡光',detail:'每 6 秒晶击三名敌人，伤害更高，适合攻坚。',interval:6,targets:3,talent:'炽晶航路',tradeoff:'主武器增伤 12%，支援间隔增加 18%'},
 vesper:{element:'thunder',passive:'对精英与守卫增伤 15%',support:'孤星破阵',detail:'每 6 秒集中打击最强敌人，并额外削减守卫护甲。',interval:6,targets:1,talent:'孤星誓言',tradeoff:'对精英再增伤 24%，对普通敌人伤害降低 10%'},
 aster:{element:'tide',passive:'支援间隔缩短 10%',support:'回风引潮',detail:'每 4.5 秒攻击三名敌人；支援时吸附附近得分碎片。',interval:4.5,targets:3,talent:'回风引航',tradeoff:'补给吸附范围再扩大 80，主武器伤害降低 8%'}
};
export const BLESSINGS=[
 {id:'chain',name:'连珠电羽',text:'雷链额外跳跃 1 个目标。',icon:'ϟ',category:'reaction',max:2},
 {id:'surge',name:'共鸣潮汐',text:'所有元素联动伤害提高 25%。',icon:'≈',category:'reaction',max:3},
 {id:'resonance',name:'并肩而行',text:'自动支援间隔缩短 12%。',icon:'✦',category:'reaction',max:3},
 {id:'prism',name:'透光棱镜',text:'普通弹额外贯穿 1 次；激光多贯穿 1 个目标。',icon:'◇',category:'attack',max:2},
 {id:'focus',name:'守卫猎手',text:'对精英与守卫增伤 22%。',icon:'⌖',category:'attack',max:3},
 {id:'overdrive',name:'风暴契约',text:'主武器增伤 22%，后续敌弹加快 8%。',icon:'!',category:'risk',max:1},
 {id:'harvest',name:'归航之露',text:'回血补给同时恢复 1 层护盾。',icon:'+',category:'survival',max:1},
 {id:'graze',name:'借险成势',text:'每擦过 5 枚敌弹，支援提前 1.2 秒。',icon:'↗',category:'reaction',max:2},
 {id:'ward',name:'星帆加固',text:'护盾上限 +1，并立即获得 1 层护盾。',icon:'⬡',category:'survival',max:1},
 {id:'pulse',name:'长夜余响',text:'释放大招时立即呼叫一次自动支援。',icon:'✧',category:'attack',max:1},
 {id:'salvage',name:'引航星图',text:'补给吸附范围扩大 70，得分碎片额外加 20 分。',icon:'↑',category:'survival',max:2},
 {id:'covenant',name:'潮息复苏',text:'每触发 10 次联动恢复 1 格生命；每局最多恢复 2 格。',icon:'♥',category:'survival',max:1}
];
export const TRIALS=[
 {id:'circuit',name:'雷潮回路',subtitle:'固定配队 · 连锁清场',detail:'霁弦与澜歌同行，雷链多跳一次。三重云境采用固定敌阵，每次都能比较自己的进步。',main:'lune',support:'nerine',hard:false,seed:271828,rule:'雷链目标 +1；专长固定为均衡'},
 {id:'fracture',name:'碎晶航线',subtitle:'深空试炼 · 破甲攻坚',detail:'岚珀与夜珩同行，守卫护甲提高。利用晶雷破甲与侧翼破坏，抓住短暂的输出窗口。',main:'ember',support:'vesper',hard:true,seed:161803,rule:'守卫护甲 +50%；专长固定为均衡'},
 {id:'pilgrim',name:'不灭星图',subtitle:'固定配队 · 生存试炼',detail:'青翎与绯穗同行。治疗补给转为得分，护盾依然有效；提前规划补给路线。',main:'aster',support:'sol',hard:true,seed:314159,rule:'治疗补给转为 500 分；专长固定为均衡'}
];
export const MEMORIES={
 ember:[['空白的第一页','岚珀一直把风图的第一页留白。那是故乡的位置，也是她不愿替任何人写下终点的地方。'],['灯火的方向','第一次并肩穿越雷暴时，她终于在空白页上画了一盏灯。航线会断，等候不会。'],['归航之约','她将新的风图分给每一位旅人。故乡不再只是地图上的一点，而是大家愿意一起回去的方向。']],
 lune:[['未署名的信','信袋最深处有一封没有收件人的信。霁弦每经过一座浮岛，都会多停留片刻。'],['雷声之外','暴风夜里，澜歌用歌声替她辨认航向。霁弦发现，有些回信从来不用纸笔。'],['长夜有回声','她终于拆开那封信，里面是一张自己幼时画的星图。原来追寻的那句等你归来，一直握在手里。']],
 nerine:[['沉城的回声','云海深处有一段旋律，只有澜歌听得见。她把它记在衣袖的结绳里。'],['有人记得','破碎的守卫核心中留着旧城的钟声。她唱给旅伴听，第一次有人接上了下半句。'],['万潮归航','城池不会从海底升起，但它的故事有了新的听众。澜歌开始为明天谱曲。']],
 sol:[['失灵的指南针','绯穗修好过上百台引擎，自己的指南针却始终指向清晨的第一束光。'],['借来的一盏灯','星桥停摆时，她拆下自己的引擎替陌生旅人点灯。那天，她是被朋友拖回营地的。'],['朝阳万里','新引擎的铭牌上刻着所有旅伴的名字。绯穗说，这次就算指南针坏了，也有人带路。']],
 vesper:[['无人灯塔','夜珩离开灯塔前，仍将灯芯换成了新的。他不知道会不会有人经过，只知道不能让灯熄灭。'],['星光落在身旁','第一次出航，他把沉默当作盾牌。直到伙伴挡住那枚敌弹，他才学会说出谢谢。'],['群星为证','他寄回灯塔一张合照。塔里不再只有一个守望者的影子，远行的人也有了自己的归处。']],
 aster:[['最后一袋种子','青翎每天数一次种子。每少一颗，就意味着又有一座荒岛值得等待春天。'],['风经过的地方','伙伴问她，种子真的会发芽吗？她指了指石缝里细小的绿芽，没有回答。'],['春风入海','云木的新叶替浮岛挡住了第一场风暴。青翎留下半袋种子，把另一半交给下一位引航员。']]
};
export const MASTERY_STEPS=[0,80,220,450];
