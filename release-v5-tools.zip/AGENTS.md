# Project preferences

- The user connects from a phone and cannot access this computer's localhost or local file paths. Deliver playable demos, previews, screenshots, and documents through verified public HTTPS links. Local URLs are for internal testing only.
- When iterating this game, complete and publish a playable demo rather than stopping at a local design preview, unless the user specifically asks for planning only.
- Use the imagegen skill for creative raster assets, then deterministic preparation and validation as needed.

- Keep this game a vertically scrolling bullet-hell shooter with single-thumb relative drag, automatic shooting and three stages. The user explicitly requested healing, six-level firepower growth and a progressive difficulty curve on 2026-10-24; balance changes in this scope are authorized. Preserve movement latency, swept collision, limited ultimates and stage order.
- The game must be fully offline and single-player. No multiplayer, required accounts, server-dependent gameplay, online leaderboards, runtime asset downloads or network-dependent SDKs. Bundle playable content locally and store progression on the device. A main/support character squad means one player's local team with automatic support actions. Design replayable challenges as local, permanently available trials rather than server-run events. This runtime constraint does not revoke previously authorized TestFlight distribution or public HTTPS previews.

- For native iOS changes, follow `native-ios/TESTING.md` and run `npm run test:native`. Use the dedicated Starborne QA simulators; save failing logs and XCTest attachments, then fix and rerun the affected checks.
- Profile Release builds with sound enabled. Keep audio decoding and playback scheduling off the game frame thread. Compare identical seeded scenes and retain measured before/after results; simulator success does not establish physical-device GPU or thermal performance.
- Keep diagnostics disabled on physical-device distributions. Publish only an explicit allowlist of QA artifacts, never raw signing files, device details, reviewer contacts, or the entire artifacts directory.
