import {normalizeProgress,settleProgress} from '../src/flight-progress.js';
import {TRIALS} from '../src/flight-expedition-data.js';
import {VerticalShooter} from '../src/flight-game.js';
import {FLIGHT_CHARACTERS} from '../src/flight-characters.js';
import {HeroMotion} from '../src/hero-motion.js';
import {SingleThumbInput} from '../src/single-thumb-input.js';

function seeded(seed){return ()=>((seed=(seed*1664525+1013904223)>>>0)/4294967296);}
let game=new VerticalShooter(),motion=new HeroMotion(),thumb=new SingleThumbInput(),accumulator=0,character='lune';
const api={
  reset(options){const trial=options.strategy&&TRIALS.find(t=>t.id===options.trial);character=trial?trial.main:FLIGHT_CHARACTERS[options.character]?options.character:'lune';game=new VerticalShooter(options.seed===undefined?Math.random:seeded(options.seed),{height:options.height||850});game.reset({...options,character,weapon:FLIGHT_CHARACTERS[character].weapon,hard:!!options.hard});motion.reset();thumb.reset();accumulator=0;return api.frame();},
  ready(options){api.reset(options);game.state='ready';game.events=[];return api.frame();},
  benchmark(options){if(options.draft){game.strategy?.offer();return api.frame()}game.enterStage(Math.max(0,Math.min(2,options.stage||0)));game.stageTime=game.stage.duration*.65;game.player.power=Math.max(1,Math.min(6,options.power||1));if(options.draft)game.strategy?.offer();if(options.finish)game.finish(false);return api.frame();},
  choose(id){thumb.reset();accumulator=0;return game.strategy?.choose(id)||false;},
  profile(raw){return JSON.stringify(normalizeProgress(raw));},
  settle(raw){return JSON.stringify(game.state==='over'&&game.strategy?settleProgress(raw,game.strategy.result()):normalizeProgress(raw));},
  resize(height){game.resize(height);thumb.reset();return api.frame();},
  pause(){thumb.reset();accumulator=0;return game.pause();},
  resume(){thumb.reset();accumulator=0;return game.resume();},
  bomb(){return game.useBomb();},
  touchBegin(x,y,time){return thumb.begin(1,x,y,time);},
  touchMove(x,y){thumb.move(1,x,y);},
  touchEnd(x,y,time){return thumb.end(1,x,y,time);},
  cancelTouch(){thumb.reset();},
  step(dt,input){
    dt=Math.max(0,Math.min(.08,dt));
    if(game.state==='playing'){
      accumulator+=dt;
      while(accumulator>=1/120&&game.state==='playing'){game.update(1/120,input||{});accumulator-=1/120;}
    }else accumulator=0;
    const events=game.events.splice(0);for(const event of events)motion.emit(event);
    motion.step(game.player,dt,{paused:['paused','draft'].includes(game.state)});
    return api.frame(events);
  },
  frame(events=[]){
    const p=game.player;
    return JSON.stringify({state:game.state,character,expedition:game.strategy?.snapshot()||null,hard:game.hard,worldHeight:game.world.height,elapsed:game.elapsed,scroll:game.scroll,score:game.score,tension:game.tension,grazes:game.grazes,maxTension:game.maxTension,threatLevel:game.threatLevel,breather:game.breather,stageIndex:game.stageIndex,phase:game.phase,progress:game.progress,stage:game.stage,won:!!game.won,player:p,shake:game.shake,bombCooldown:game.bombCooldown,bombTime:game.bombTime,motion:motion.frame(),enemies:game.enemies,bullets:game.bullets,shots:game.shots,pickups:game.pickups,hazards:game.hazards,laser:game.laser,spirit:game.spirit,events});
  },
  debugState(){return JSON.stringify(game);}
};
globalThis.NativeStarborne=api;
