import SwiftUI
import SpriteKit

struct FlightHUD:Equatable {
    var state="ready",character="lune",stageName="云海遗庭",bossName="",support="nerine",trial="voyage"
    var score=0,lives=3,bombs=2,power=1,tension=1,grazes=0,stage=0,maxTension=1,shield=0,reactions=0,choices=0,threatLevel=1
    var progress=0.0,bossHP=0.0,bombCooldown=0.0,elapsed=0.0,supportCharge=0.0,armor=0.0,exposed=0.0
    var won=false,breather=false
    init(){}
    init(_ f:GameFrame){state=f.state;character=f.character;stageName=f.stage.name;bossName=f.boss == nil ? "":f.stage.boss;score=Int(f.score);lives=f.player.lives;bombs=f.player.bombs;power=f.player.power;tension=f.tension;grazes=f.grazes;stage=f.stageIndex;maxTension=f.maxTension;progress=f.progress;bossHP=f.boss.map{$0.hp/$0.maxHp} ?? 0;bombCooldown=f.bombCooldown;won=f.won;elapsed=f.elapsed;threatLevel=f.threatLevel;breather=f.breather;shield=f.player.shield;support=f.expedition?.support ?? "nerine";supportCharge=f.expedition?.supportCharge ?? 0;reactions=f.expedition?.reactions ?? 0;choices=f.expedition?.choiceCount ?? 0;trial=f.expedition?.trial ?? "voyage";armor=f.boss?.armor ?? 0;exposed=f.boss?.exposed ?? 0}
}
final class GameStore:ObservableObject,FlightSceneObserver {
    let scene=FlightScene(size:CGSize(width:480,height:1000))
    let travellers=Traveller.load()
    let content=ExpeditionContent.shared
    @Published var selected="lune"
    @Published var support="nerine"
    @Published var trial="voyage"
    @Published var talent="balanced"
    @Published var hard=false
    @Published var muted=false
    @Published var musicMuted=false
    @Published var hud=FlightHUD()
    @Published var gallery=false
    @Published var journal=false
    @Published var trials=false
    @Published var portraitTier="healthy"
    @Published var best=UserDefaults.standard.integer(forKey:"starborne.native.best")
    @Published var error=""
    @Published var progress=FlightProgress()
    @Published var awardedXP=0
    private var progressRaw="{}",lastHUD:Double = -1,settled=false
    var traveller:Traveller?{travellers.first{$0.id==selected}}
    var partner:Traveller?{travellers.first{$0.id==support}}
    var heroProgress:HeroProgress{progress.heroes[selected] ?? HeroProgress()}
    var squadSummary:String{let pair=[content.roles[selected]?.element ?? "",content.roles[support]?.element ?? ""].sorted().joined(separator:"+");return pair=="thunder+tide" ? "雷潮连锁 · 波及附近敌人":pair=="crystal+thunder" ? "晶雷破甲 · 打出守卫破绽":pair=="crystal+tide" ? "晶潮星帆 · 掉落抵伤护盾":"同元素 · 专注支援火力"}
    var draft:[ExpeditionBlessing]{scene.gameFrame?.expedition?.draft ?? []}
    var owned:[ExpeditionBlessing]{scene.gameFrame?.expedition?.blessings ?? []}
    var qaSnapshot:String {
        let f=scene.gameFrame
        let state:[String:Any]=["state":hud.state,"character":selected,"support":support,"trial":trial,"talent":talent,"profileRuns":progress.runs,"xp":heroProgress.xp,"draft":draft.map{$0.id},"choices":hud.choices,"reactions":hud.reactions,"shield":hud.shield,"hard":hard,"gallery":gallery,"tier":portraitTier,"elapsed":f?.elapsed ?? 0,"x":f?.player.x ?? 0,"y":f?.player.y ?? 0,"bombs":f?.player.bombs ?? 0,"lives":f?.player.lives ?? 0,"power":f?.player.power ?? 1,"threatLevel":f?.threatLevel ?? 1,"musicMuted":musicMuted,"sceneID":String(describing:ObjectIdentifier(scene))]
        return (try? JSONSerialization.data(withJSONObject:state)).flatMap{String(data:$0,encoding:.utf8)} ?? "{}"
    }
    init(){
        let d=UserDefaults.standard
        progressRaw=scene.bridge.call("profile",[d.string(forKey:"starborne.expedition.progress.v1") ?? "{}"] )?.toString() ?? "{}";progress=FlightProgress.decode(progressRaw)
        let saved=NativeQA.value("--qa-character") ?? d.string(forKey:"starborne.native.character") ?? "lune"
        if travellers.contains(where:{$0.id==saved}){selected=saved}
        support=NativeQA.value("--qa-support") ?? d.string(forKey:"starborne.native.support") ?? "nerine";validateSupport()
        talent=heroProgress.level>0 ? d.string(forKey:"starborne.talent.\(selected)") ?? "balanced":"balanced"
        muted=NativeQA.value("--qa-muted").map{$0=="true"} ?? d.bool(forKey:"starborne.native.muted");musicMuted=NativeQA.value("--qa-muted").map{$0=="true"} ?? d.bool(forKey:"starborne.native.musicMuted");hard=NativeQA.value("--qa-hard")=="true";scene.audio.muted=muted;scene.audio.musicMuted=musicMuted;scene.observer=self;home()
    }
    private func validateSupport(){if !travellers.contains(where:{$0.id==support}) || support==selected{support=selected=="nerine" ? "lune":"nerine"}}
    func select(_ id:String){selected=id;trial="voyage";validateSupport();talent=heroProgress.level>0 ? UserDefaults.standard.string(forKey:"starborne.talent.\(id)") ?? "balanced":"balanced";UserDefaults.standard.set(id,forKey:"starborne.native.character");home()}
    func selectSupport(_ id:String){guard id != selected else{return};support=id;trial="voyage";UserDefaults.standard.set(id,forKey:"starborne.native.support");home()}
    func selectTalent(_ value:String){guard value=="balanced" || heroProgress.level>0 else{return};talent=value;UserDefaults.standard.set(value,forKey:"starborne.talent.\(selected)");home()}
    func cycle(_ direction:Int){guard let i=travellers.firstIndex(where:{$0.id==selected}),!travellers.isEmpty else{return};select(travellers[(i+direction+travellers.count)%travellers.count].id)}
    func start(){settled=false;awardedXP=0;lastHUD = -1;scene.start(character:selected,hard:hard,support:support,trial:trial,talent:talent)}
    func home(){scene.home(character:selected,hard:hard,support:support,trial:trial,talent:talent)}
    func voyage(){trial="voyage";home()}
    func beginTrial(_ t:ExpeditionTrial){selected=t.main;support=t.support;hard=t.hard;trial=t.id;talent="balanced";trials=false;start()}
    func sound(){muted.toggle();scene.audio.muted=muted;UserDefaults.standard.set(muted,forKey:"starborne.native.muted")}
    func music(){musicMuted.toggle();scene.audio.musicMuted=musicMuted;UserDefaults.standard.set(musicMuted,forKey:"starborne.native.musicMuted")}
    func sceneUpdated(_ frame:GameFrame){
        let stateChanged=frame.state != hud.state
        if stateChanged || frame.character != hud.character || frame.player.lives != hud.lives || frame.player.power != hud.power || frame.player.bombs != hud.bombs || frame.elapsed-lastHUD>=0.08 {lastHUD=frame.elapsed;hud=FlightHUD(frame)}
        if stateChanged{UIApplication.shared.isIdleTimerDisabled=frame.state=="playing"}
        if frame.state=="over" && !settled{
            settled=true;let before=heroProgress.xp
            progressRaw=scene.bridge.call("settle",[progressRaw])?.toString() ?? progressRaw;progress=FlightProgress.decode(progressRaw);awardedXP=heroProgress.xp-before
            UserDefaults.standard.set(progressRaw,forKey:"starborne.expedition.progress.v1")
            if trial=="voyage" && Int(frame.score)>best{best=Int(frame.score);UserDefaults.standard.set(best,forKey:"starborne.native.best")}
        }
    }
    func sceneFailed(_ message:String){if error.isEmpty{error=message;scene.pause()}}
}
