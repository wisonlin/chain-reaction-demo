import SwiftUI

private let epPaper=Color(hex:"f4eedc"),epGold=Color(hex:"e7ce96"),epMist=Color(hex:"b6d2df")
private func epArt(_ name:String)->Image{Image(uiImage:UIImage(named:name) ?? UIImage())}
private func epPanel()->Color{Color(hex:"18394d")}
struct VoyageLobby:View {
    @ObservedObject var game:GameStore
    let top,bottom:CGFloat
    var body:some View{
        VStack(spacing:0){
            ScrollView{
                VStack(alignment:.leading,spacing:14){
                    HStack{Text("STARBORNE 2.0").tracking(2);Spacer();Text("离线 · 共鸣之旅")}.font(.system(size:12,weight:.medium)).foregroundStyle(epMist)
                    HStack{Text("并肩，穿越云海。").font(.system(size:27,weight:.medium,design:.serif));Spacer();Button{game.journal=true}label:{Image(systemName:"book.closed").font(.system(size:21)).frame(width:44,height:44)}.accessibilityLabel("旅人手记").accessibilityIdentifier("open-journal")}.foregroundStyle(epPaper)
                    HStack(spacing:12){
                        Button{game.portraitTier="healthy";game.gallery=true}label:{epArt("\(game.selected)-healthy").resizable().scaledToFit().frame(maxWidth:.infinity).frame(height:170)}.buttonStyle(.plain).accessibilityLabel("查看全身立绘").accessibilityIdentifier("open-gallery")
                        VStack(alignment:.leading,spacing:8){
                            Text("主战 / \(game.traveller?.name ?? "")").font(.system(size:20,weight:.semibold,design:.serif)).foregroundStyle(epGold)
                            Text(game.content.roles[game.selected]?.passive ?? "").font(.system(size:14)).foregroundStyle(epPaper)
                            Divider().overlay(epMist.opacity(0.3))
                            Text("支援 / \(game.partner?.name ?? "")").font(.system(size:17,weight:.semibold)).foregroundStyle(epPaper)
                            Text(game.content.roles[game.support]?.detail ?? "").font(.system(size:13)).foregroundStyle(epMist).fixedSize(horizontal:false,vertical:true)
                            Text("熟练 \(game.heroProgress.level) · \(game.heroProgress.xp) 星忆").font(.system(size:13,weight:.medium)).foregroundStyle(epGold)
                        }.frame(maxWidth:.infinity,alignment:.leading)
                    }.padding(10).background(LinearGradient(colors:[Color(hex:"31516a"),epPanel()],startPoint:.topLeading,endPoint:.bottomTrailing),in:RoundedRectangle(cornerRadius:16))
                    Text(game.squadSummary).font(.system(size:16,weight:.semibold)).foregroundStyle(epGold).padding(.vertical,3)
                    HStack{Text("选择主战");Spacer();Text("\(game.content.elements[game.content.roles[game.selected]?.element ?? ""]?.name ?? "") · \(game.traveller?.normal ?? "")").foregroundStyle(epMist)}.font(.system(size:14,weight:.semibold))
                    LazyVGrid(columns:Array(repeating:GridItem(.flexible(),spacing:7),count:3),spacing:7){ForEach(game.travellers){t in
                        Button{game.select(t.id)}label:{HStack(spacing:5){epArt("\(t.id)-face").resizable().scaledToFill().frame(width:33,height:36).clipShape(RoundedRectangle(cornerRadius:8));Text(t.name).font(.system(size:15,weight:.medium)).lineLimit(1).minimumScaleFactor(0.8)}.foregroundStyle(epPaper).frame(maxWidth:.infinity,minHeight:51).background(game.selected==t.id ? Color(hex:"49667d"):epPanel(),in:RoundedRectangle(cornerRadius:9)).overlay(RoundedRectangle(cornerRadius:9).stroke(game.selected==t.id ? epGold:epMist.opacity(0.15),lineWidth:1))}.buttonStyle(.plain).accessibilityLabel("选择\(t.name)").accessibilityAddTraits(game.selected==t.id ? .isSelected:[])
                    }}
                    HStack{Text("选择自动支援");Spacer();Text("不增加操作按钮").foregroundStyle(epMist)}.font(.system(size:14,weight:.semibold))
                    ScrollView(.horizontal){HStack(spacing:8){ForEach(game.travellers.filter{$0.id != game.selected}){t in
                        Button{game.selectSupport(t.id)}label:{VStack(spacing:5){epArt("\(t.id)-face").resizable().scaledToFill().frame(width:40,height:40).clipShape(Circle());Text(t.name).font(.system(size:14,weight:.medium))}.foregroundStyle(epPaper).frame(width:67,height:79).background(game.support==t.id ? Color(hex:"49667d"):epPanel(),in:RoundedRectangle(cornerRadius:10)).overlay(RoundedRectangle(cornerRadius:10).stroke(game.support==t.id ? epGold:.clear,lineWidth:1.5))}.buttonStyle(.plain).accessibilityLabel("支援\(t.name)")
                    }}}.scrollIndicators(.hidden)
                    if game.heroProgress.level>0{
                        HStack(spacing:8){Button("均衡专长"){game.selectTalent("balanced")}.foregroundStyle(game.talent=="balanced" ? epGold:epMist);Button(game.content.roles[game.selected]?.talent ?? "角色专长"){game.selectTalent("signature")}.foregroundStyle(game.talent=="signature" ? epGold:epMist)}.font(.system(size:14,weight:.medium)).buttonStyle(.bordered)
                        if game.talent=="signature"{Text(game.content.roles[game.selected]?.tradeoff ?? "").font(.system(size:13)).foregroundStyle(epMist)}
                    }
                    HStack(spacing:10){Button{game.hard=false;game.voyage()}label:{Text("云海初行").frame(minHeight:44)}.foregroundStyle(!game.hard ? epGold:epMist);Button{game.hard=true;game.voyage()}label:{Text("深空试炼").frame(minHeight:44)}.foregroundStyle(game.hard ? epGold:epMist);Spacer();Button{game.trials=true}label:{Label("常驻试炼",systemImage:"flag.checkered").frame(minHeight:44)}.foregroundStyle(epGold).accessibilityIdentifier("open-trials")}.font(.system(size:14,weight:.medium)).buttonStyle(.plain).frame(minHeight:44)
                    if game.trial != "voyage"{Text("当前试炼：\(game.content.trials.first{$0.id==game.trial}?.name ?? "")").font(.system(size:14)).foregroundStyle(epGold)}
                }.padding(.horizontal,20).padding(.top,max(top,18)+12).padding(.bottom,12)
            }.scrollIndicators(.hidden)
            VStack(spacing:8){Button(action:game.start){HStack{Text(game.trial=="voyage" ? "启程云海":"再次挑战");Spacer();Image(systemName:"arrow.up.right")}.font(.system(size:19,weight:.semibold)).foregroundStyle(Color(hex:"254052")).padding(.horizontal,20).frame(height:55).background(epPaper,in:RoundedRectangle(cornerRadius:10))}.buttonStyle(.plain).accessibilityIdentifier("primary-action");Text("单指拖动 · 双击大招 · 补给时三选一").font(.system(size:13)).foregroundStyle(epMist)}.padding(.horizontal,20).padding(.top,10).padding(.bottom,max(bottom,14)+4).background(Color(hex:"102b3e"))
        }.background(LinearGradient(colors:[Color(hex:"203f57").opacity(0.96),Color(hex:"102a3d").opacity(0.97)],startPoint:.topLeading,endPoint:.bottomTrailing))
    }
}
struct BlessingDraftView:View {
    @ObservedObject var game:GameStore
    let top,bottom:CGFloat
    var body:some View{
        ZStack{
            Color(hex:"0b2237").opacity(0.96).ignoresSafeArea()
            ScrollView{VStack(alignment:.leading,spacing:15){
                Text("STARBORNE / 本局构筑").font(.system(size:13)).tracking(2).foregroundStyle(epGold)
                Text("选择航路祝福").font(.system(size:32,weight:.medium,design:.serif)).foregroundStyle(epPaper)
                Text("时间已暂停。选择一项，继续并肩航行。").font(.system(size:15)).foregroundStyle(epMist)
                HStack{Text("\(game.traveller?.name ?? "") ＋ \(game.partner?.name ?? "")");Spacer();Text("已选 \(game.hud.choices)/6")}.font(.system(size:14,weight:.semibold)).foregroundStyle(epGold).padding(.vertical,7)
                ForEach(game.draft){b in
                    Button{game.scene.choose(b.id)}label:{HStack(alignment:.center,spacing:14){Text(b.icon).font(.system(size:31,weight:.medium)).foregroundStyle(b.category=="risk" ? Color(hex:"ffa49a"):epGold).frame(width:48,height:56).background(Color(hex:"31516b"),in:RoundedRectangle(cornerRadius:10));VStack(alignment:.leading,spacing:7){HStack{Text(b.name).font(.system(size:21,weight:.semibold,design:.serif));Spacer();Text("\((b.stacks ?? 0)+1)/\(b.max)").font(.system(size:13))}.foregroundStyle(epPaper);Text(b.text).font(.system(size:16)).foregroundStyle(epMist).multilineTextAlignment(.leading).fixedSize(horizontal:false,vertical:true)}}.padding(16).frame(maxWidth:.infinity,minHeight:126).background(epPanel(),in:RoundedRectangle(cornerRadius:14)).overlay(RoundedRectangle(cornerRadius:14).stroke(epGold.opacity(0.4),lineWidth:1))}.buttonStyle(.plain).accessibilityIdentifier("blessing-\(b.id)").accessibilityLabel("\(b.name)，\(b.text)")
                }
                Text(game.owned.isEmpty ? "祝福只对本局生效，角色星忆会留在本机。":"已有："+game.owned.map{"\($0.name) \($0.stacks ?? 1)"}.joined(separator:" · ")).font(.system(size:14)).foregroundStyle(epMist).padding(.top,8)
            }.padding(.horizontal,20).padding(.top,max(top,20)+24).padding(.bottom,max(bottom,18)+20)}.scrollIndicators(.hidden)
        }.accessibilityIdentifier("blessing-screen")
    }
}
struct TrialLibrary:View {
    @ObservedObject var game:GameStore
    @Environment(\.dismiss) private var dismiss
    var body:some View{
        NavigationStack{ScrollView{VStack(alignment:.leading,spacing:16){Text("固定敌阵，随时重试。成绩只保存在本机。").font(.system(size:16)).foregroundStyle(epMist)
            ForEach(game.content.trials){t in VStack(alignment:.leading,spacing:10){Text(t.subtitle).font(.system(size:13)).foregroundStyle(epGold);Text(t.name).font(.system(size:26,weight:.medium,design:.serif)).foregroundStyle(epPaper);Text(t.detail).font(.system(size:16)).foregroundStyle(epMist);Text(t.rule).font(.system(size:14,weight:.medium)).foregroundStyle(epGold);HStack{Text("本机纪录 \(game.progress.trialBest[t.id] ?? 0)").font(.system(size:14)).foregroundStyle(epMist);Spacer();Button("开始挑战"){dismiss();game.beginTrial(t)}.font(.system(size:17,weight:.semibold)).buttonStyle(.borderedProminent).tint(Color(hex:"526b81")).accessibilityIdentifier("trial-\(t.id)")}}.padding(18).background(epPanel(),in:RoundedRectangle(cornerRadius:15))}
        }.padding(20)}.background(Color(hex:"102b3e")).scrollContentBackground(.hidden).navigationTitle("常驻试炼").toolbar{ToolbarItem(placement:.topBarTrailing){Button("关闭"){dismiss()}}}.preferredColorScheme(.dark)}
    }
}
struct TravellerJournal:View {
    @ObservedObject var game:GameStore
    @Environment(\.dismiss) private var dismiss
    @State private var hero=""
    var body:some View{
        let id=hero.isEmpty ? game.selected:hero,h=game.progress.heroes[id] ?? HeroProgress(),t=game.travellers.first{$0.id==id}
        return NavigationStack{ScrollView{VStack(alignment:.leading,spacing:16){
            ScrollView(.horizontal){HStack(spacing:10){ForEach(game.travellers){c in Button{hero=c.id}label:{VStack{epArt("\(c.id)-face").resizable().scaledToFill().frame(width:48,height:48).clipShape(Circle());Text(c.name).font(.system(size:14))}.foregroundStyle(id==c.id ? epGold:epMist).padding(6)}.buttonStyle(.plain)}}}.scrollIndicators(.hidden)
            HStack{epArt("\(id)-healthy").resizable().scaledToFit().frame(width:130,height:230);VStack(alignment:.leading,spacing:10){Text(t?.name ?? "").font(.system(size:32,weight:.medium,design:.serif)).foregroundStyle(epPaper);Text("熟练 \(h.level) / 3").font(.system(size:19,weight:.semibold)).foregroundStyle(epGold);Text("\(h.xp) 星忆 · \(h.runs) 次同行").font(.system(size:15)).foregroundStyle(epMist);ProgressView(value:Double(min(h.xp,h.next)),total:Double(h.next)).tint(epGold);Text(h.level==0 ? "80 星忆解锁角色专长":"专长：\(game.content.roles[id]?.talent ?? "")").font(.system(size:14)).foregroundStyle(epGold)}}
            Text(game.content.roles[id]?.tradeoff ?? "").font(.system(size:15)).foregroundStyle(epMist)
            ForEach(0..<3,id:\.self){i in let memory=game.content.memories[id]?[i] ?? ["",""]
                VStack(alignment:.leading,spacing:8){HStack{Image(systemName:h.level>i ? "sparkle":"lock");Text(memory[0]).font(.system(size:20,weight:.semibold,design:.serif))}.foregroundStyle(h.level>i ? epGold:epMist);Text(h.level>i ? memory[1]:"累计 \([80,220,450][i]) 星忆后，揭开这段旅人记忆。").font(.system(size:16)).foregroundStyle(epMist).lineSpacing(5)}.frame(maxWidth:.infinity,alignment:.leading).padding(17).background(epPanel(),in:RoundedRectangle(cornerRadius:12))
            }
            Text("完成或结束航行可获得星忆，支援也会成长。故事与专长永久保存在本机。").font(.system(size:14)).foregroundStyle(epMist)
        }.padding(20)}.background(Color(hex:"102b3e")).scrollContentBackground(.hidden).navigationTitle("旅人手记").toolbar{ToolbarItem(placement:.topBarTrailing){Button("关闭手记"){dismiss()}}}.preferredColorScheme(.dark)}
    }
}
