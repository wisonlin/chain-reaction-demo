import Foundation

struct ExpeditionBlessing:Decodable,Identifiable {let id,name,text,icon,category:String;let max:Int;let stacks:Int?}
struct ExpeditionEffect:Decodable {let kind:String;let x,y,toX,toY,life:Double}
struct ExpeditionFrame:Decodable {
    let main,support,element,supportElement,trial,talent:String
    let supportCharge,castFlash:Double
    let reactions,assists,choiceCount:Int
    let draft,blessings:[ExpeditionBlessing]
    let fx:[ExpeditionEffect]
}
struct ExpeditionRole:Decodable {let element,passive,support,detail,talent,tradeoff:String;let interval:Double;let targets:Int}
struct ExpeditionElement:Decodable {let name,icon,color:String}
struct ExpeditionTrial:Decodable,Identifiable {let id,name,subtitle,detail,main,support,rule:String;let hard:Bool;let seed:Int}
struct ExpeditionContent:Decodable {
    let roles:[String:ExpeditionRole],elements:[String:ExpeditionElement],memories:[String:[[String]]]
    let trials:[ExpeditionTrial]
    static let shared:ExpeditionContent = {
        let u=Bundle.main.url(forResource:"expedition",withExtension:"json")!
        return try! JSONDecoder().decode(ExpeditionContent.self,from:Data(contentsOf:u))
    }()
}
struct HeroProgress:Decodable {var xp=0,runs=0,wins=0,reactions=0;var level:Int{[80,220,450].filter{xp >= $0}.count};var next:Int{[80,220,450].first{$0>xp} ?? 450}}
struct FlightProgress:Decodable {
    var schema=1,runs=0,wins=0,totalScore=0
    var heroes:[String:HeroProgress]=[:],trialBest:[String:Int]=[:],recent:[String]=[]
    static func decode(_ raw:String)->FlightProgress{(try? JSONDecoder().decode(FlightProgress.self,from:Data(raw.utf8))) ?? FlightProgress()}
}
