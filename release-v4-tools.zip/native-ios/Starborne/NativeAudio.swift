import AVFoundation

/// Short effects stay in PCM; full music tracks stream from disk. All audio work is serial and off the game thread.
final class NativeAudio {
    private struct Clip {
        let buffers:[AVAudioPCMBuffer]
        let voices:[AVAudioPlayerNode]
        var next=0
    }
    private let queue=DispatchQueue(label:"com.wison.starborne.audio",qos:.userInitiated)
    private let engine=AVAudioEngine()
    private let effectsBus=AVAudioMixerNode()
    private var clips:[String:Clip]=[:]
    private var music:[String:AVAudioPlayer]=[:]
    private var effectsOff=false,musicOff=false
    private var lastEffects:[String:Double]=[:]
    private var scene="ready",boss=false,requestedScene="",duckUntil=0.0
    var muted=false {didSet{let value=muted;queue.async{[self] in effectsOff=value}}}
    var musicMuted=false {didSet{let value=musicMuted;queue.async{[self] in musicOff=value;refreshMusic()}}}
    init(){queue.async{[self] in prepare()}}
    private func prepare(){
        try? AVAudioSession.sharedInstance().setCategory(.playback,mode:.default,options:[.mixWithOthers])
        engine.attach(effectsBus);engine.connect(effectsBus,to:engine.mainMixerNode,format:nil);effectsBus.outputVolume=0.6
        for key in ["shot","kill","bomb","hurt","pickup","powerup","heal"] {
            let names=(key=="shot" || key=="kill") ? [key,key+"-2",key+"-3"]:[key]
            let buffers=names.compactMap{name -> AVAudioPCMBuffer? in
                guard let url=Bundle.main.url(forResource:name,withExtension:"wav"),let file=try? AVAudioFile(forReading:url),let buffer=AVAudioPCMBuffer(pcmFormat:file.processingFormat,frameCapacity:AVAudioFrameCount(file.length)),(try? file.read(into:buffer)) != nil else{return nil};return buffer
            }
            guard let first=buffers.first else{continue}
            let voices=(0..<((key=="shot" || key=="kill") ? 4:2)).map{_ -> AVAudioPlayerNode in
                let voice=AVAudioPlayerNode();engine.attach(voice);engine.connect(voice,to:effectsBus,format:first.format)
                voice.volume=key=="shot" ? 0.16:key=="pickup" ? 0.22:key=="kill" ? 0.4:0.8;return voice
            }
            clips[key]=Clip(buffers:buffers,voices:voices)
        }
        for key in ["voyage","guardian"] {
            guard let url=Bundle.main.url(forResource:key,withExtension:"m4a"),let player=try? AVAudioPlayer(contentsOf:url) else{continue}
            player.numberOfLoops = -1;player.volume=0;player.prepareToPlay();music[key]=player
        }
        engine.prepare();try? engine.start();refreshMusic()
    }
    func play(_ key:String){
        queue.async{[self] in
            guard !effectsOff,var clip=clips[key],!clip.voices.isEmpty else{return}
            let now=Date.timeIntervalSinceReferenceDate,limit=key=="shot" ? 0.085:key=="kill" ? 0.07:key=="pickup" ? 0.1:0
            guard now-(lastEffects[key] ?? -99)>=limit else{return};lastEffects[key]=now
            if !engine.isRunning{try? engine.start()}
            let voice=clip.voices[clip.next % clip.voices.count],buffer=clip.buffers[clip.next % clip.buffers.count]
            clip.next+=1;clips[key]=clip;voice.scheduleBuffer(buffer,at:nil,options:.interrupts)
            if !voice.isPlaying{voice.play()}
            if key=="bomb" || key=="hurt" {
                duckUntil=Date.timeIntervalSinceReferenceDate+0.8;refreshMusic()
                queue.asyncAfter(deadline:.now()+0.85){[self] in refreshMusic()}
            }
        }
    }
    func setScene(state:String,boss:Bool){
        let key=state+(boss ? ":boss":"");guard key != requestedScene else{return};requestedScene=key
        queue.async{[self] in scene=state;self.boss=boss;refreshMusic()}
    }
    private func refreshMusic(){
        let active=scene=="playing",selected=boss ? "guardian":"voyage"
        let level:Float=musicOff ? 0:Date.timeIntervalSinceReferenceDate<duckUntil ? 0.09:scene=="ready" ? 0.16:0.32
        for (key,player) in music {
            if scene=="paused" || scene=="over" {player.pause();continue}
            if key==selected || !active&&key=="voyage" {if !player.isPlaying{player.play()};player.setVolume(level,fadeDuration:0.8)}
            else{player.setVolume(0,fadeDuration:0.8)}
        }
    }
    deinit{engine.stop();for player in music.values{player.stop()}}
}
