import SwiftUI
import SpriteKit

private let paper=Color(red:0.95,green:0.92,blue:0.84)
private let gold=Color(red:0.91,green:0.80,blue:0.57)
private func artwork(_ name:String)->Image { Image(uiImage:UIImage(named:name) ?? UIImage()) }
private let mist=Color(red:0.67,green:0.79,blue:0.85)
extension Color { init(hex:String){self.init(uiColor:UIColor(hex:hex))} }
struct StarborneView:View {
    @ObservedObject var game:GameStore
    var body:some View {
        GeometryReader{geometry in canvas(geometry)}
            .ignoresSafeArea()
            .fullScreenCover(isPresented:$game.gallery){PortraitGallery(game:game)}
    }
    private func viewport(_ size:CGSize){
        let width=min(size.width,size.height*0.625)
        game.scene.configure(height:Double(size.height/width*480))
    }
    private func canvas(_ geometry:GeometryProxy)->some View {
        let width=min(geometry.size.width,geometry.size.height*0.625)
        let windowInsets=UIApplication.shared.connectedScenes.compactMap{$0 as? UIWindowScene}.flatMap{$0.windows}.first(where:{$0.isKeyWindow})?.safeAreaInsets ?? .zero
        let top=max(geometry.safeAreaInsets.top,windowInsets.top)
        let bottom=max(geometry.safeAreaInsets.bottom,windowInsets.bottom)
        return ZStack {
            LinearGradient(colors:[Color(hex:"264e63"),Color(hex:"0d2234")],startPoint:.topLeading,endPoint:.bottomTrailing).ignoresSafeArea()
            ZStack {
                SpriteView(scene:game.scene,preferredFramesPerSecond:60,debugOptions:NativeQA.enabled ? [.showsFPS,.showsNodeCount,.showsDrawCount]:[])
                    .frame(width:width,height:geometry.size.height)
                    .accessibilityLabel("云海弹幕战场，单指拖动，原地双击大招")
                    .accessibilityIdentifier("flight-battlefield")
                if game.hud.state=="playing"{battleHUD(top:top,bottom:bottom)}
                if game.hud.state != "playing"{menu(width:width,height:geometry.size.height,top:top,bottom:bottom)}
                if NativeQA.enabled {Text("QA").font(.system(size:7)).foregroundStyle(.clear).frame(width:2,height:2).accessibilityIdentifier("qa-state").accessibilityValue(game.qaSnapshot).allowsHitTesting(false)}
            }.frame(width:width,height:geometry.size.height).clipped()
        }.frame(maxWidth:.infinity,maxHeight:.infinity)
        .onAppear{
            viewport(geometry.size)
            if NativeQA.value("--qa-autostart")=="true" {
                DispatchQueue.main.asyncAfter(deadline:.now()+1){if game.hud.state=="ready"{game.start()}}
            }
        }
        .onChange(of:geometry.size){_,newSize in viewport(newSize)}
    }
    private func battleHUD(top:CGFloat,bottom:CGFloat)->some View {
        VStack(spacing:9){
            HStack(alignment:.center){
                VStack(alignment:.leading,spacing:2){Text("得分").font(.system(size:13,weight:.medium)).foregroundStyle(mist);Text(String(format:"%07d",game.hud.score)).font(.system(size:25,weight:.semibold,design:.serif)).monospacedDigit().foregroundStyle(paper)}.allowsHitTesting(false)
                Spacer(minLength:6)
                HStack(spacing:6){
                    hudButton(game.musicMuted ? "music.note":"music.note.list",label:game.musicMuted ? "开启音乐":"关闭音乐",action:game.music)
                    hudButton(game.muted ? "speaker.slash":"speaker.wave.1",label:game.muted ? "开启音效":"关闭音效",action:game.sound)
                    hudButton("pause",label:"暂停游戏",action:game.scene.pause)
                }
            }
            HStack(spacing:8){
                Text("生命 \(game.hud.lives)/3").font(.system(size:17,weight:.bold)).foregroundStyle(game.hud.lives==1 ? Color(hex:"ffb0b1"):paper)
                HStack(spacing:4){ForEach(0..<3,id:\.self){i in Capsule().fill(i<game.hud.lives ? Color(hex:game.hud.lives==1 ? "ff7c91":"80edba"):Color(hex:"3e5364")).frame(width:26,height:11)}}
                Spacer(minLength:4)
                Text(game.hud.breather ? "补给间歇":"威胁 \(game.hud.threatLevel)").font(.system(size:15,weight:.semibold)).foregroundStyle(game.hud.breather ? Color(hex:"80edba"):gold)
            }.accessibilityElement(children:.ignore).accessibilityLabel("生命 \(game.hud.lives)/3，威胁 \(game.hud.threatLevel)").accessibilityIdentifier("health-status").allowsHitTesting(false)
            HStack(spacing:10){Text("0\(game.hud.stage+1) · \(game.hud.stageName)").font(.system(size:14,weight:.medium)).foregroundStyle(mist);ProgressView(value:game.hud.progress).tint(gold)}.allowsHitTesting(false)
            if !game.hud.bossName.isEmpty{VStack(spacing:6){HStack{Text(game.hud.bossName);Spacer();Text("\(Int(game.hud.bossHP*100))%")};ProgressView(value:max(0,game.hud.bossHP)).tint(Color(hex:"f29fbc"))}.font(.system(size:15,weight:.semibold)).foregroundStyle(paper).padding(10).background(Color(hex:"102b40").opacity(0.9),in:RoundedRectangle(cornerRadius:8)).allowsHitTesting(false)}
            Spacer()
            HStack(alignment:.bottom){
                VStack(alignment:.leading,spacing:7){
                    Text("火力 \(game.hud.power)/6").font(.system(size:20,weight:.bold)).monospacedDigit()
                    HStack(spacing:4){ForEach(0..<6,id:\.self){i in RoundedRectangle(cornerRadius:2).fill(i<game.hud.power ? gold:mist.opacity(0.2)).frame(width:15,height:7)}}
                    Text("原地双击 · 大招").font(.system(size:14,weight:.medium)).foregroundStyle(mist)
                }.foregroundStyle(paper).padding(12).background(Color(hex:"102c41").opacity(0.82),in:RoundedRectangle(cornerRadius:10)).accessibilityElement(children:.ignore).accessibilityLabel("火力 \(game.hud.power)/6，原地双击释放大招").accessibilityIdentifier("power-status").allowsHitTesting(false)
                Spacer()
                Button(action:game.scene.cast){VStack(spacing:2){Image(systemName:"sparkle").font(.system(size:25));Text("大招 ×\(game.hud.bombs)").font(.system(size:18,weight:.bold))}.foregroundStyle(gold).frame(width:88,height:88).background(RadialGradient(colors:[Color(hex:"64738b"),Color(hex:"263c55")],center:.topLeading,startRadius:0,endRadius:90),in:Circle()).overlay(Circle().stroke(gold.opacity(0.85),lineWidth:2))}.buttonStyle(.plain).disabled(game.hud.bombs<=0 || game.hud.bombCooldown>0).opacity(game.hud.bombs<=0 ? 0.45:1).accessibilityLabel("释放大招，剩余\(game.hud.bombs)次").accessibilityIdentifier("ultimate-button")
            }
        }.padding(.horizontal,16).padding(.top,max(top,18)+6).padding(.bottom,max(bottom,16)+6)
        .background(alignment:.top){LinearGradient(colors:[Color(hex:"0c263b").opacity(0.95),Color(hex:"0c263b").opacity(0.65),.clear],startPoint:.top,endPoint:.bottom).frame(height:240).allowsHitTesting(false)}
    }
    private func hudButton(_ icon:String,label:String,action:@escaping()->Void)->some View { Button(action:action){Image(systemName:icon).font(.system(size:19,weight:.medium)).foregroundStyle(paper).frame(width:44,height:44).background(Color(hex:"0e263a").opacity(0.9),in:RoundedRectangle(cornerRadius:9))}.buttonStyle(.plain).accessibilityLabel(label) }
    private func menu(width:CGFloat,height:CGFloat,top:CGFloat,bottom:CGFloat)->some View {
        let compact=height<740
        return ZStack {
            LinearGradient(colors:[Color(hex:"112e42").opacity(0.92),Color(hex:"16384d").opacity(0.75),Color(hex:"0d263a").opacity(0.98)],startPoint:.top,endPoint:.bottom)
            ScrollView {
                VStack(spacing:compact ? 12:17){
                    HStack{Text("STARBORNE").tracking(3);Spacer();Text("云海异闻 / BUILD 3")}.font(.system(size:8,design:.monospaced)).foregroundStyle(mist).padding(.bottom,9).overlay(alignment:.bottom){Rectangle().fill(mist.opacity(0.22)).frame(height:1)}
                    if game.hud.state=="ready" {
                        ZStack(alignment:.leading){
                            HStack{Spacer();Button{game.portraitTier="healthy";game.gallery=true} label:{artwork("\(game.selected)-healthy").resizable().scaledToFit().frame(width:width*0.61,height:compact ? 190:270).overlay(alignment:.bottomTrailing){Text("查看全身立绘 ↗").font(.system(size:8)).foregroundStyle(paper).padding(6).background(Color(hex:"0e263a").opacity(0.85))}}.buttonStyle(.plain).accessibilityLabel("查看全身立绘").accessibilityIdentifier("open-gallery")}
                            VStack(alignment:.leading,spacing:8){Text("STARBORNE / 云海异闻").font(.system(size:7,design:.monospaced)).tracking(1).foregroundStyle(gold);Text("星渡\n云海").font(.system(size:compact ? 42:53,weight:.medium,design:.serif)).lineSpacing(-5).foregroundStyle(paper);Spacer(minLength:3);Text(game.traveller?.title ?? "").font(.system(size:7)).tracking(0.7).foregroundStyle(Color(hex:game.traveller?.color ?? "c7a0ff"));Text(game.traveller?.name ?? "").font(.system(size:25,design:.serif)).tracking(4).foregroundStyle(paper)}.frame(height:compact ? 174:245).allowsHitTesting(false)
                        }.frame(height:compact ? 192:275)
                        HStack{Text("选择旅人");Spacer();Text("6 位角色 · 3 种射击方式")}.font(.system(size:9)).foregroundStyle(mist)
                        LazyVGrid(columns:Array(repeating:GridItem(.flexible(),spacing:7),count:3),spacing:7){ForEach(game.travellers){character in
                            Button{game.select(character.id)}label:{VStack(spacing:4){artwork("\(character.id)-face").resizable().scaledToFill().frame(width:compact ? 34:40,height:compact ? 34:40).clipShape(Circle());Text(character.name).font(.system(size:12,weight:.medium,design:.serif)).tracking(2).foregroundStyle(paper);Text(character.normal).font(.system(size:8)).foregroundStyle(mist)}.frame(maxWidth:.infinity).padding(.vertical,7).background(Color(hex:game.selected==character.id ? "3b5671":"18384d").opacity(0.8)).overlay(Rectangle().stroke(game.selected==character.id ? Color(hex:character.color):mist.opacity(0.22),lineWidth:1))}.buttonStyle(.plain).accessibilityLabel("选择\(character.name)").accessibilityAddTraits(game.selected==character.id ? .isSelected:[])
                        }}
                        HStack(spacing:0){difficulty("云海初行",hard:false);Rectangle().fill(mist.opacity(0.25)).frame(width:1,height:15);difficulty("深空试炼",hard:true)}.padding(.vertical,2)
                        primary("启程云海",action:game.start)
                        Text("单指拖动 · 双击大招").font(.system(size:14)).foregroundStyle(mist)
                        HStack(spacing:14){Text("● 敌弹").foregroundStyle(Color(hex:"ff7d72"));Text("↑ 火力").foregroundStyle(Color(hex:"8dcaff"));Text("+ 回血").foregroundStyle(Color(hex:"8df0b8"))}.font(.system(size:14,weight:.semibold))
                    } else {
                        VStack(alignment:.leading,spacing:14){Text(game.hud.state=="paused" ? "THE SKY HOLDS STILL":game.hud.won ? "ASTRAL JOURNEY COMPLETE":"ASTRAL RECORD").font(.system(size:9,design:.monospaced)).tracking(2).foregroundStyle(gold);Text(game.hud.state=="paused" ? "暂歇\n云海，等你。":game.hud.won ? "云海明\n星轨，重连。":"再赴云海\n借险成势。").font(.system(size:41,weight:.medium,design:.serif)).foregroundStyle(paper);Text(game.hud.state=="paused" ? "此刻时间静止。准备好后，继续穿过云海。":"\(game.hud.stageName) · 每一次航行，都是新的星图。").font(.system(size:12)).foregroundStyle(mist).lineSpacing(5)}.frame(maxWidth:.infinity,alignment:.leading).padding(.vertical,25)
                        if game.hud.state=="over"{HStack{result("本局得分",String(format:"%07d",game.hud.score));Spacer();result("擦弹次数","\(game.hud.grazes)");Spacer();result("最高星势","×\(game.hud.maxTension)")}.padding(.bottom,16)}
                        primary(game.hud.state=="paused" ? "继续作战":"再赴云海",action:game.hud.state=="paused" ? game.scene.resume:game.start)
                        Button("返回云海",action:game.home).font(.system(size:12)).foregroundStyle(mist).padding(8)
                    }
                    if !game.error.isEmpty{Text(game.error).font(.system(size:11)).foregroundStyle(.orange)}
                }.padding(.horizontal,25).padding(.top,max(top,18)+20).padding(.bottom,max(bottom,18)+15).frame(minHeight:height)
            }.scrollIndicators(.hidden)
        }
    }
    private func difficulty(_ title:String,hard:Bool)->some View {Button{game.hard=hard} label:{Text((game.hard==hard ? "• ":"")+title).font(.system(size:11)).foregroundStyle(game.hard==hard ? gold:mist.opacity(0.7)).frame(maxWidth:.infinity).padding(.vertical,8)}.buttonStyle(.plain).accessibilityLabel(title)}
    private func primary(_ text:String,action:@escaping()->Void)->some View {Button(action:action){HStack{Text(text).font(.system(size:16,weight:.semibold));Spacer();Image(systemName:"arrow.up.right").font(.system(size:22))}.foregroundStyle(Color(hex:"294453")).padding(.horizontal,19).frame(height:52).background(paper).overlay(Rectangle().stroke(gold.opacity(0.6),lineWidth:1).padding(3))}.buttonStyle(.plain).accessibilityIdentifier("primary-action")}
    private func result(_ label:String,_ value:String)->some View{VStack(alignment:.leading,spacing:7){Text(value).font(.system(size:20,weight:.semibold,design:.serif)).foregroundStyle(gold);Text(label).font(.system(size:9)).foregroundStyle(mist)}}
}
struct PortraitGallery:View {
    @ObservedObject var game:GameStore
    @Environment(\.dismiss) private var dismiss
    var body:some View {
        GeometryReader{g in
            ZStack {
                RadialGradient(colors:[Color(hex:game.traveller?.color ?? "c7a0ff").opacity(0.18),Color(hex:"142c40")],center:.center,startRadius:0,endRadius:g.size.height*0.7).ignoresSafeArea()
                VStack(spacing:12){
                    artwork("\(game.selected)-\(game.portraitTier)").resizable().scaledToFit().frame(maxWidth:.infinity,maxHeight:.infinity).padding(.top,14)
                    HStack(spacing:7){ForEach(["healthy","wounded","critical"],id:\.self){tier in Button{game.portraitTier=tier} label:{Text(tier=="healthy" ? "满血 · 从容":tier=="wounded" ? "负伤 · 破损":"濒危 · 战损").font(.system(size:10)).foregroundStyle(game.portraitTier==tier ? gold:mist).padding(.horizontal,11).padding(.vertical,9).background(Color(hex:"1e3c53")).overlay(Rectangle().stroke(game.portraitTier==tier ? gold:mist.opacity(0.3),lineWidth:1))}.buttonStyle(.plain)}}
                    Text(game.traveller?.title ?? "").font(.system(size:9)).tracking(2).foregroundStyle(gold).padding(.top,5)
                    Text(game.traveller?.name ?? "").font(.system(size:30,design:.serif)).tracking(6).foregroundStyle(paper)
                    Text(game.traveller?.quote ?? "").font(.system(size:11)).foregroundStyle(mist).multilineTextAlignment(.center).lineSpacing(4)
                }.padding(.horizontal,20).padding(.bottom,max(g.safeAreaInsets.bottom,18)+10)
                HStack{Button{game.cycle(-1)}label:{Image(systemName:"chevron.left").padding(14)};Spacer();Button{game.cycle(1)}label:{Image(systemName:"chevron.right").padding(14)}}.foregroundStyle(paper).buttonStyle(.plain)
                VStack{HStack{Spacer();Button{dismiss()}label:{Image(systemName:"xmark").font(.system(size:18)).foregroundStyle(paper).frame(width:40,height:40).background(Color(hex:"102536").opacity(0.8),in:Circle()).overlay(Circle().stroke(mist.opacity(0.3),lineWidth:1))}.buttonStyle(.plain).accessibilityLabel("关闭立绘")};Spacer()}.padding(.top,max(g.safeAreaInsets.top,15)).padding(.horizontal,16)
            }
        }.ignoresSafeArea()
    }
}
