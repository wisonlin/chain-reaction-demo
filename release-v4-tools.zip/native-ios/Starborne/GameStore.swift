import SwiftUI
import SpriteKit

struct FlightHUD:Equatable {
    var state="ready",character="lune",stageName="云海遗庭",bossName=""
    var score=0,lives=3,bombs=2,power=1,tension=1,grazes=0,stage=0,maxTension=1,threatLevel=1
    var progress=0.0,bossHP=0.0,bombCooldown=0.0,elapsed=0.0
    var won=false,breather=false
    init(){}
    init(_ f:GameFrame){state=f.state;character=f.character;stageName=f.stage.name;bossName=f.boss == nil ? "":f.stage.boss;score=Int(f.score);lives=f.player.lives;bombs=f.player.bombs;power=f.player.power;tension=f.tension;grazes=f.grazes;stage=f.stageIndex;maxTension=f.maxTension;progress=f.progress;bossHP=f.boss.map{$0.hp/$0.maxHp} ?? 0;bombCooldown=f.bombCooldown;won=f.won;elapsed=f.elapsed;threatLevel=f.threatLevel;breather=f.breather}
}
final class GameStore:ObservableObject,FlightSceneObserver {
    let scene=FlightScene(size:CGSize(width:480,height:1000))
    let travellers=Traveller.load()
    @Published var selected="lune"
    @Published var hard=false
    @Published var muted=false
    @Published var musicMuted=false
    @Published var hud=FlightHUD()
    @Published var gallery=false
    @Published var portraitTier="healthy"
    @Published var best=UserDefaults.standard.integer(forKey:"starborne.native.best")
    @Published var error=""
    private var lastHUD:Double = -1,settled=false
    var traveller:Traveller?{travellers.first{$0.id==selected}}
    var qaSnapshot:String {
        let f=scene.gameFrame
        let state:[String:Any]=["state":hud.state,"character":selected,"hard":hard,"gallery":gallery,"tier":portraitTier,"elapsed":f?.elapsed ?? 0,"x":f?.player.x ?? 0,"y":f?.player.y ?? 0,"bombs":f?.player.bombs ?? 0,"lives":f?.player.lives ?? 0,"power":f?.player.power ?? 1,"threatLevel":f?.threatLevel ?? 1,"musicMuted":musicMuted,"sceneID":String(describing:ObjectIdentifier(scene))]
        return (try? JSONSerialization.data(withJSONObject:state)).flatMap{String(data:$0,encoding:.utf8)} ?? "{}"
    }
    init(){
        let saved=UserDefaults.standard.string(forKey:"starborne.native.character") ?? "lune"
        if travellers.contains(where:{$0.id==saved}){selected=saved}
        if let qa=NativeQA.value("--qa-character"),travellers.contains(where:{$0.id==qa}){selected=qa}
        muted=NativeQA.value("--qa-muted").map{$0=="true"} ?? UserDefaults.standard.bool(forKey:"starborne.native.muted");musicMuted=NativeQA.value("--qa-muted").map{$0=="true"} ?? UserDefaults.standard.bool(forKey:"starborne.native.musicMuted");hard=NativeQA.value("--qa-hard")=="true";scene.audio.muted=muted;scene.audio.musicMuted=musicMuted;scene.observer=self;scene.home(character:selected,hard:hard)
    }
    func select(_ id:String){selected=id;UserDefaults.standard.set(id,forKey:"starborne.native.character");scene.home(character:id,hard:hard)}
    func cycle(_ direction:Int){guard let i=travellers.firstIndex(where:{$0.id==selected}),!travellers.isEmpty else{return};select(travellers[(i+direction+travellers.count)%travellers.count].id)}
    func start(){settled=false;lastHUD = -1;scene.start(character:selected,hard:hard)}
    func home(){scene.home(character:selected,hard:hard)}
    func sound(){muted.toggle();scene.audio.muted=muted;UserDefaults.standard.set(muted,forKey:"starborne.native.muted")}
    func music(){musicMuted.toggle();scene.audio.musicMuted=musicMuted;UserDefaults.standard.set(musicMuted,forKey:"starborne.native.musicMuted")}
    func sceneUpdated(_ frame:GameFrame){
        let stateChanged=frame.state != hud.state
        if stateChanged || frame.character != hud.character || frame.player.lives != hud.lives || frame.player.power != hud.power || frame.player.bombs != hud.bombs || frame.elapsed-lastHUD>=0.08 {lastHUD=frame.elapsed;hud=FlightHUD(frame)}
        if stateChanged{UIApplication.shared.isIdleTimerDisabled=frame.state=="playing"}
        if frame.state=="over" && !settled{settled=true;if Int(frame.score)>best{best=Int(frame.score);UserDefaults.standard.set(best,forKey:"starborne.native.best")}}
    }
    func sceneFailed(_ message:String){if error.isEmpty{error=message;scene.pause()}}
}
