import {AUDIO_ASSETS} from './audio-assets.js';

// Cached short effects and two streamed, composed music sections. No synthesis in the frame loop.
export class FlightAudio {
  constructor(){this.state='ready';this.boss=false;this.muted=false;this.musicMuted=false;this.buffers=new Map();this.music=[];this.next={};this.last={};this.active=0;}
  init(){
    if(this.context){this.context.resume().catch(()=>{});this.sync();return;}
    const Context=window.AudioContext||window.webkitAudioContext;if(!Context)return;
    const c=this.context=new Context();this.sfx=c.createGain();this.sfx.gain.value=.6;this.sfx.connect(c.destination);
    for(const key of ['voyage','guardian']){
      const element=new Audio(AUDIO_ASSETS[key]);element.loop=true;element.preload='auto';
      const gain=c.createGain();gain.gain.value=0;c.createMediaElementSource(element).connect(gain);gain.connect(c.destination);this.music.push({key,element,gain});
    }
    for(const [key,url]of Object.entries(AUDIO_ASSETS))if(!['voyage','guardian'].includes(key)){
      fetch(url).then(r=>r.arrayBuffer()).then(b=>c.decodeAudioData(b)).then(b=>this.buffers.set(key,b)).catch(()=>{});
    }
    c.resume().catch(()=>{});this.sync();
  }
  setScene(state,boss=false){if(this.state===state&&this.boss===boss)return;this.state=state;this.boss=boss;this.sync();}
  settings(muted,musicMuted){this.muted=muted;this.musicMuted=musicMuted;this.sync();}
  sync(){
    const c=this.context;if(!c)return;this.sfx.gain.setTargetAtTime(this.muted?0:.6,c.currentTime,.03);
    for(const m of this.music){
      if(this.state==='paused'||this.state==='over'){m.element.pause();continue;}
      const selected=this.boss&&this.state==='playing'?'guardian':'voyage';
      const level=this.musicMuted?0:this.state==='ready'?.16:.32;
      m.gain.gain.setTargetAtTime(m.key===selected?level:0,c.currentTime,.24);
      m.element.play().catch(()=>{});
    }
  }
  play(key){
    const c=this.context;if(!c||this.muted||c.state!=='running'||this.active>=16)return;
    const limit=key==='shot'?.085:key==='kill'?.07:key==='pickup'?.1:0;
    if(c.currentTime-(this.last[key]??-99)<limit)return;this.last[key]=c.currentTime;
    const count=key==='shot'||key==='kill'?3:1,index=(this.next[key]||0)%count;this.next[key]=(this.next[key]||0)+1;
    const buffer=this.buffers.get(key+(index?'-'+(index+1):''));if(!buffer)return;
    const source=c.createBufferSource(),gain=c.createGain();source.buffer=buffer;
    source.playbackRate.value=.97+Math.random()*.06;gain.gain.value=key==='shot'?.16:key==='pickup'?.22:key==='kill'?.4:.8;
    source.connect(gain);gain.connect(this.sfx);source.start();this.active++;
    source.onended=()=>{this.active--;source.disconnect();gain.disconnect();};
    if(key==='bomb'||key==='hurt')for(const m of this.music){const target=m.gain.gain.value;m.gain.gain.cancelScheduledValues(c.currentTime);m.gain.gain.setTargetAtTime(target*.3,c.currentTime,.025);m.gain.gain.setTargetAtTime(target,c.currentTime+.8,.25);}
  }
}
