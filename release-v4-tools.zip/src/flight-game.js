export const flightClamp = (n, lo, hi) => Math.max(lo, Math.min(hi, n));
export const FLIGHT_BALANCE = Object.freeze({version:'4.0',maxLives:3,maxPower:6,supplyTimes:[10,25,39],recoveryDelay:12});
export const FLIGHT_WEAPONS = {
  spread: {name:'辉晶散射',short:'辉晶散射 / 追击',letter:'岩',color:'#f4ca79',description:'辉晶散射 · 星芒追击',hero:'redHero',familiar:'fox'},
  laser: {name:'弧光贯穿',short:'雷光贯穿 / 锁定',letter:'雷',color:'#c7a0ff',description:'贯穿雷光 · 电羽协战',hero:'blueHero',familiar:'sword'},
  homing: {name:'潮星追踪',short:'水星追踪 / 扇射',letter:'水',color:'#8fdbf5',description:'水星追踪 · 星轨扇射',hero:'greenHero',familiar:'crane'}
};
export const FLIGHT_STAGES = [
  {name:'云海遗庭',code:'GARDENS ABOVE THE CLOUDS',boss:'遗庭守卫 · 辉石之翼',duration:46,theme:'shrine',color:'#e5c995',scroll:86},
  {name:'暮光星桥',code:'THE ASTRAL CAUSEWAY',boss:'星桥守卫 · 暮光之翼',duration:52,theme:'lanterns',color:'#e1b9cf',scroll:98},
  {name:'月镜深空',code:'BEYOND THE MOON MIRROR',boss:'星核守卫 · 月镜之翼',duration:58,theme:'moon',color:'#a9c8ff',scroll:112}
];
const FLIGHT_WEAPON_IDS = Object.keys(FLIGHT_WEAPONS);
const flightDist = (a,b) => Math.hypot(a.x-b.x,a.y-b.y);
export function flightSegmentHit(ax,ay,bx,by,cx,cy,r) {
  const dx=bx-ax,dy=by-ay,t=flightClamp(((cx-ax)*dx+(cy-ay)*dy)/(dx*dx+dy*dy||1),0,1);
  return Math.hypot(ax+dx*t-cx,ay+dy*t-cy)<=r;
}
export function flightBoxHit(ax,ay,bx,by,left,top,right,bottom) {
  let near=0,far=1;
  for(const [a,d,min,max] of [[ax,bx-ax,left,right],[ay,by-ay,top,bottom]]) {
    if(Math.abs(d)<1e-9){if(a<min||a>max)return false;continue;}
    let t1=(min-a)/d,t2=(max-a)/d;if(t1>t2)[t1,t2]=[t2,t1];near=Math.max(near,t1);far=Math.min(far,t2);if(near>far)return false;
  }
  return true;
}
export class VerticalShooter {
  constructor(random=Math.random,world={width:480,height:850}) {
    this.random=random;this.world={width:480,height:Math.max(640,world.height||850)};this.reset();this.state='ready';this.events=[];
  }
  reset({weapon='spread',hard=false}={}) {
    this.state='playing';this.hard=hard;this.elapsed=0;this.scroll=0;this.score=0;this.kills=0;this.chain=0;this.chainTimer=0;this.bestChain=0;this.medals=0;this.shotsFired=0;this.shotsHit=0;this.damageTaken=0;this.bombsUsed=0;this.nextId=1;this.tension=1;this.tensionHold=0;this.grazes=0;this.maxTension=1;this.spiritKills=0;
    this.player={x:240,y:this.world.height*.79,r:4.5,lives:3,invincible:2.2,weapon:FLIGHT_WEAPONS[weapon]?weapon:'spread',power:1,bombs:2,fireTimer:0,missileTimer:0,spiritTimer:0,spirit:false,bank:0};
    this.enemies=[];this.bullets=[];this.shots=[];this.pickups=[];this.hazards=[];this.events=[];this.laser={time:0,ends:[]};this.spirit={time:0,beams:[],targetIds:[]};this.bombTime=0;this.bombCooldown=0;this.shake=0;
    this.healing=0;this.lastHealDrop=-99;this.enterStage(0);
  }
  get spiritRange(){return Math.max(520,this.world.height*.8);}
  get attackBoost(){return this.tension===8?1.35:1;}
  get stage(){return FLIGHT_STAGES[this.stageIndex];}
  get boss(){return this.enemies.find(e=>e.type==='boss'&&!e.dead);}
  get progress(){return this.phase==='approach'?Math.min(1,this.stageTime/this.stage.duration):1;}
  get remaining(){return Math.max(0,this.stage.duration-this.stageTime);}
  get pressure(){return this.stageIndex*.38+flightClamp(this.stageTime/this.stage.duration,0,1)*.62;}
  get threatLevel(){return 1+Math.min(4,Math.floor(this.pressure*2.5));}
  get breather(){return this.phase==='approach'&&this.supplyIndex>0&&this.stageTime<this.lastSupplyTime+2.6;}
  get fireRateScale(){return (1+this.pressure*.55)*(this.hard?1.13:1)*(this.breather?.78:1);}
  get waveInterval(){return Math.max(1.25,3.15-this.pressure*1.65-(this.hard?.25:0))+(this.breather?1.1:0);}
  event(type,data={}){this.events.push({type,...data});if(this.events.length>400)this.events.splice(0,this.events.length-400);}
  enterStage(index) {
    this.stageIndex=index;this.stageTime=0;this.phase='approach';this.phaseTime=0;this.waveNumber=0;this.waveTimer=1.1;this.miniSpawned=false;
    this.supplyIndex=0;this.lastSupplyTime=-99;
    this.enemies=[];this.bullets=[];this.shots=[];this.hazards=[];this.pickups=[];this.tension=1;this.tensionHold=0;this.player.spirit=false;this.spirit={time:0,beams:[],targetIds:[]};
    this.player.invincible=Math.max(this.player.invincible,2.2);
    this.event('stage',{index,name:this.stage.name,code:this.stage.code});
    this.spawnFormation('opening');
    this.pickups.push(this.makePickup('power',240,this.player.y-210));
  }
  resize(height) {
    height=Math.max(640,height);const ratio=height/this.world.height;
    if(Math.abs(ratio-1)<.00001)return;
    for(const q of [this.player,...this.enemies,...this.bullets,...this.shots,...this.pickups])q.y*=ratio;
    this.world.height=height;this.laser.time=0;
  }
  bounds(){return {left:24,right:456,top:100,bottom:this.world.height-70};}
  targetFor(shot) {
    let best=null,score=Infinity;
    for(const e of this.enemies){if(e.dead||e.y<100||e.y>this.world.height+30||shot.spirit&&flightDist(e,this.player)>this.spiritRange+50)continue;const d=flightDist(e,shot);if(d<score){score=d;best=e;}}
    return best;
  }
  spawnEnemy(type,x,y,extra={}) {
    if(this.enemies.length>=56)return null;
    const stats={fighter:[3,16,20],sweeper:[6,23,22],diver:[4,17,22],tank:[13,21,24],carrier:[28,34,37],gunship:[160+this.stageIndex*70,52,48],boss:[1550+this.stageIndex*650,84,64]}[type];
    const hp=stats[0]*(type==='boss'||type==='gunship'?(this.hard?1.12:1):1+this.pressure*.48);
    const e={id:this.nextId++,type,x,y,baseX:x,age:0,enteredAt:-1,hp,maxHp:hp,rx:stats[1],ry:stats[2],timer:.85+this.random()*.6,burstTimer:2.2,flash:0,dead:false,ground:type==='tank',seed:this.random()*6.28,...extra};
    if(type==='boss'){e.intro=2;e.secondPhase=false;e.parts=[{x:-66,y:22,hp:52+this.stageIndex*12,maxHp:52+this.stageIndex*12},{x:66,y:22,hp:52+this.stageIndex*12,maxHp:52+this.stageIndex*12}];}
    this.enemies.push(e);return e;
  }
  spawnFormation(kind) {
    const wave=this.waveNumber++,s=this.stageIndex,side=wave%2?1:-1;
    if(kind==='opening'){for(let i=0;i<5;i++)this.spawnEnemy('fighter',100+i*70,-35-Math.abs(i-2)*37,{pattern:'sine',speed:105});return;}
    const sequence=['v','sweep','tanks','cross','carrier','divers','line','cross','tanks','sweep','v','carrier'];
    kind=kind||sequence[(wave-1+s*2)%sequence.length];
    if(kind==='v'||kind==='line')for(let i=0;i<5;i++)this.spawnEnemy('fighter',65+i*87,-40-(kind==='v'?Math.abs(i-2)*38:i*20),{pattern:kind==='v'?'sine':'straight',speed:120+s*14});
    if(kind==='cross')for(let i=0;i<4;i++)this.spawnEnemy('fighter',side<0?40:440,-35-i*57,{pattern:'cross',side,speed:115+s*18});
    if(kind==='sweep')for(let i=0;i<3;i++)this.spawnEnemy('sweeper',80+i*160,-45-i*45,{pattern:'sine',speed:89+s*11});
    if(kind==='tanks'){this.spawnEnemy('tank',76, -32,{speed:this.stage.scroll});this.spawnEnemy('tank',404,-130,{speed:this.stage.scroll});for(let i=0;i<3;i++)this.spawnEnemy('fighter',170+i*70,-50-i*30,{speed:145});}
    if(kind==='carrier'){this.spawnEnemy('carrier',side<0?140:340,-60,{speed:62+s*6});for(let i=0;i<3;i++)this.spawnEnemy('fighter',90+i*150,-150-i*35,{speed:140});}
    if(kind==='divers')for(let i=0;i<4;i++)this.spawnEnemy('diver',55+i*122,-40-i*48,{speed:200+s*20,drift:(240-(55+i*122))*.12});
  }
  addBullet(x,y,angle,speed=180,kind='aimed',radius=4.5) {
    if(this.bullets.length>=520)return;
    const scale=(1+this.pressure*.25)*(this.hard?1.17:1);
    this.bullets.push({x,y,px:x,py:y,vx:Math.cos(angle)*speed*scale,vy:Math.sin(angle)*speed*scale,r:radius,kind,age:0,dead:false});
  }
  aimedFan(e,count=3,spread=.15,speed=170,x=e.x,y=e.y) {
    const angle=Math.atan2(this.player.y-y,this.player.x-x);
    for(let i=0;i<count;i++)this.addBullet(x,y,angle+(i-(count-1)/2)*spread,speed,'aimed');
    this.event('enemyFire',{x,y});
  }
  addShot(x,y,angle,damage,kind='spread') {
    if(this.shots.length>=250)return;
    const shot={id:this.nextId++,x,y,px:x,py:y,vx:Math.cos(angle)*(kind==='missile'?580:1040),vy:Math.sin(angle)*(kind==='missile'?580:1040),angle,damage:damage*this.attackBoost,kind,r:kind==='missile'?5:4,age:0,life:kind==='missile'?2.8:1.65,dead:false};this.shots.push(shot);this.shotsFired++;return shot;
  }
  fire() {
    const p=this.player,power=p.power;
    if(p.weapon==='spread'){
      const count=[3,5,7,7,9,11][power-1],spread=.065;
      for(let i=0;i<count;i++)this.addShot(p.x+(i-(count-1)/2)*4,p.y-26,-Math.PI/2+(i-(count-1)/2)*spread,1+power*.12);
      p.fireTimer=.125-(power-1)*.006;
    } else if(p.weapon==='laser') {
      const lanes=power>=5?[-22,0,22]:power>=3?[-11,11]:[0];this.laser={time:.13,ends:[]};
      for(const offset of lanes){
        const x=p.x+offset,targets=this.enemies.filter(e=>!e.dead&&e.y<p.y&&e.y>=100&&Math.abs(e.x-x)<e.rx+5).sort((a,b)=>b.y-a.y);
        let endY=-15;
        for(const e of targets.slice(0,power>=6?3:power>=4?2:1)){this.damageEnemy(e,(1.8+power*.6)*this.attackBoost);this.shotsHit++;this.event('hit',{x,y:e.y+e.ry,color:'#63dcff'});endY=e.y+e.ry;}
        this.laser.ends.push({x,y:endY});this.shotsFired++;
      }
      p.fireTimer=.098-power*.002;
    } else {
      for(const offset of (power>=5?[-22,-7,7,22]:power>=3?[-16,0,16]:[-10,10]))this.addShot(p.x+offset,p.y-24,-Math.PI/2,.8+power*.16,'pulse');
      p.fireTimer=.14-(power-1)*.004;
      if(p.missileTimer<=0){for(const side of (power>=5?[-2,-1,1,2]:[-1,1]))this.addShot(p.x+side*23,p.y-1,-Math.PI/2+side*.24,1.6+power*.6,'missile');p.missileTimer=.29-(power-1)*.02;}
    }
    p.fireTimer*=this.tension===8?.85:1;
    this.event('shoot',{x:p.x,y:p.y,weapon:p.weapon,power});
  }
  fireSpirit() {
    const p=this.player,range=this.spiritRange,targets=this.enemies.filter(e=>!e.dead&&e.y>=100&&e.y<p.y+50&&!(e.type==='boss'&&e.intro>0)&&flightDist(e,p)<=range).sort((a,b)=>flightDist(a,p)-flightDist(b,p));
    if(!targets.length){p.spiritTimer=.08;return;}
    // A short automatic volley supplements the main weapon without affecting movement.
    this.spirit={time:.24,beams:[],targetIds:targets.slice(0,3).map(e=>e.id)};
    p.spirit=true;p.spiritTimer=p.weapon==='homing'?.85:p.weapon==='laser'?.75:.8;
    if(p.weapon==='spread'){
      for(let i=0;i<3;i++){const target=targets[i%targets.length],x=p.x+(i-1)*28,y=p.y-48,a=Math.atan2(target.y-y,target.x-x);const shot=this.addShot(x,y,a,1.8+p.power*.34,'missile');if(shot)Object.assign(shot,{spirit:true,targetId:target.id,life:1.15});}
    } else if(p.weapon==='laser'){
      for(let i=0;i<2;i++){
        const target=targets[i%targets.length],part=target.parts?.filter(q=>q.hp>0)[i%Math.max(1,target.parts?.filter(q=>q.hp>0).length||0)];
        const x=target.x+(part?.x||0),y=target.y+(part?.y||0),fromX=p.x+(i?33:-33),fromY=p.y-40,damage=1.5+p.power*.38;
        if(part)this.damagePart(target,part,damage,true);else this.damageEnemy(target,damage,true);
        this.spirit.beams.push({x:fromX,y:fromY,endX:x,endY:y});this.event('hit',{x,y,color:'#c6eaff'});
      }
    }else{
      const target=targets[0],a=Math.atan2(target.y-(p.y-40),target.x-p.x);
      for(let i=-2;i<=2;i++){const shot=this.addShot(p.x+i*11,p.y-40,a+i*.16,1.1+p.power*.26,'feather');if(shot)Object.assign(shot,{spirit:true,pierce:1,hit:new Set(),life:.62});}
    }
    this.event('spiritShot',{x:p.x,y:p.y,weapon:p.weapon});
  }
  updateTension(dt) {
    const p=this.player;
    if(p.invincible>0||this.bombTime>0||this.phase==='clear'||this.state!=='playing'){this.tension=1;this.tensionHold=0;return;}
    let clearance=Infinity;
    for(const b of this.bullets){
      if(b.dead)continue;const gap=flightDist(b,p)-b.r-p.r;clearance=Math.min(clearance,gap);
      if(gap>=0&&gap<20&&!b.grazed){b.grazed=true;this.grazes++;this.score+=20;this.event('graze',{x:p.x,y:p.y,bulletX:b.x,bulletY:b.y});}
    }
    for(const e of this.enemies)if(!e.dead&&!e.ground&&e.y>0)clearance=Math.min(clearance,flightDist(e,p)-Math.max(e.rx,e.ry)*.7-p.r);
    const value=clearance<15?8:clearance<27?6:clearance<45?4:clearance<70?2:1;
    if(value>1){const rising=value===8&&this.tension!==8;this.tension=value;this.tensionHold=.65;this.maxTension=Math.max(this.maxTension,value);if(rising)this.event('tensionMax',{x:p.x,y:p.y});}
    else{this.tensionHold=Math.max(0,this.tensionHold-dt);if(this.tensionHold===0)this.tension=1;}
  }
  damagePart(e,part,damage,spirit=false) {
    if(e.dead||part.hp<=0)return;part.hp=Math.max(0,part.hp-damage);e.flash=.045;
    if(part.hp===0){this.score+=1800;this.event('partDown',{x:e.x+part.x,y:e.y+part.y,size:42});this.damageEnemy(e,28,spirit);this.pickups.push(this.makePickup('medal',e.x+part.x,e.y+part.y));}
  }
  damageEnemy(e,damage,spirit=false) {
    if(e.dead||e.y<100)return;
    if(e.type==='boss'&&e.intro>0)return;
    e.hp-=damage;e.flash=.055;if(e.hp<=0)this.killEnemy(e,spirit);
  }
  killEnemy(e,spirit=false) {
    if(e.dead)return;e.dead=true;this.kills++;this.chain++;this.bestChain=Math.max(this.bestChain,this.chain);this.chainTimer=2.4;
    const base={fighter:120,diver:160,sweeper:240,tank:350,carrier:700,gunship:2400,boss:15000}[e.type];
    const multiplier=this.tension,value=Math.round(base*multiplier*(spirit?1.5:1));if(spirit)this.spiritKills++;
    this.score+=value;this.event('kill',{x:e.x,y:e.y,size:e.type==='boss'?115:e.rx,enemyType:e.type,value,fast:false,multiplier,spirit});this.shake=Math.max(this.shake,e.type==='boss'?9:e.type==='gunship'?5:1.3);
    if(e.type==='boss'){
      this.phase='clear';this.phaseTime=0;this.bullets=[];this.hazards=[];this.player.invincible=5;this.player.bombs=Math.min(3,this.player.bombs+1);this.score+=this.player.lives*1200;
      this.event('stageClear',{index:this.stageIndex,score:this.score});return;
    }
    const count=(e.type==='gunship'?5:e.type==='carrier'?3:e.ground?2:1)*(spirit?2:1);
    for(let i=0;i<count;i++){const q=this.makePickup('medal',e.x+(i-(count-1)/2)*12,e.y);q.homing=spirit;q.multiplier=multiplier;this.pickups.push(q);}
    if(e.type==='carrier')this.pickups.push(this.makePickup('power',e.x,e.y-12));
    if(e.type==='gunship'){this.pickups.push(this.makePickup('power',e.x-25,e.y-20));this.pickups.push(this.makePickup('bomb',e.x+25,e.y-20));}
    else if(this.kills%13===0)this.pickups.push(this.makePickup('power',e.x,e.y-20));
    if((e.type==='carrier'||e.type==='gunship')&&this.player.lives<FLIGHT_BALANCE.maxLives)this.dropHeal(e.x,e.y-38);
    if(this.pickups.length>110)this.pickups.splice(0,this.pickups.length-110);
  }
  makePickup(type,x,y){return {id:this.nextId++,type,x,y,age:0,seed:this.random()*6.28,dead:false};}
  dropHeal(x=this.player.x,y=Math.max(145,this.player.y-240)){
    if(this.elapsed-this.lastHealDrop<FLIGHT_BALANCE.recoveryDelay||this.pickups.some(q=>q.type==='heal'&&!q.dead))return false;
    this.pickups.push(this.makePickup('heal',flightClamp(x,50,430),y));this.lastHealDrop=this.elapsed;this.event('recoverySupply',{x,y});return true;
  }
  pickupWeapon(q){return FLIGHT_WEAPON_IDS[Math.floor(q.age/1.35)%3];}
  collect(q) {
    if(q.dead)return;q.dead=true;
    const p=this.player;
    if(q.type==='heal'){
      const restored=Math.min(FLIGHT_BALANCE.maxLives-p.lives,1);p.lives+=restored;this.healing+=restored;
      if(restored){p.invincible=Math.max(p.invincible,1.2);this.event('heal',{lives:p.lives,amount:restored,x:p.x,y:p.y});}
      else{this.score+=300;this.event('pickup',{kind:q.type,x:q.x,y:q.y});}return;
    }
    if(q.type==='medal'){this.medals++;this.score+=(60+Math.min(180,this.chain*4))*(q.multiplier||1);this.event('pickup',{kind:q.type,x:q.x,y:q.y});return;}
    if(q.type==='bomb')p.bombs=Math.min(3,p.bombs+1);
    else {if(p.power===FLIGHT_BALANCE.maxPower)this.score+=250;p.power=Math.min(FLIGHT_BALANCE.maxPower,p.power+1);p.fireTimer=0;}
    this.event('powerup',{kind:q.type,weapon:p.weapon,power:p.power,x:p.x,y:p.y});
  }
  useBomb() {
    const p=this.player;if(this.state!=='playing'||p.bombs<=0||this.bombCooldown>0||this.phase==='clear')return false;
    p.bombs--;this.bombsUsed++;this.bombTime=1.3;this.bombCooldown=1.6;p.invincible=Math.max(p.invincible,2.1);this.bullets=[];this.hazards=[];this.shake=7;
    for(const e of this.enemies){if(e.dead||e.y<-60)continue;if(e.parts)for(const part of e.parts)this.damagePart(e,part,30);this.damageEnemy(e,e.type==='boss'?90:150);}
    this.event('bomb',{x:p.x,y:p.y,weapon:p.weapon,lives:p.lives});return true;
  }
  hurtPlayer() {
    const p=this.player;if(this.state!=='playing'||p.invincible>0||this.bombTime>0||this.phase==='clear')return false;
    p.lives--;this.damageTaken++;p.power=Math.max(1,p.power-1);p.invincible=2.8;this.chain=0;this.chainTimer=0;this.tension=1;this.tensionHold=0;this.shake=8;
    for(const b of this.bullets)if(flightDist(b,p)<160)b.dead=true;
    this.event('hurt',{x:p.x,y:p.y,lives:p.lives});
    if(p.lives<=0)this.finish(false);return true;
  }
  finish(won) {if(this.state==='over')return;this.state='over';this.player.spirit=false;this.won=won;this.event('over',{won,score:this.score});}
  pause(){if(this.state!=='playing')return false;this.state='paused';this.player.spirit=false;this.spirit={time:0,beams:[],targetIds:[]};return true;}
  resume(){if(this.state!=='paused')return false;this.state='playing';return true;}
  updateEnemy(e,dt) {
    e.age+=dt;e.flash=Math.max(0,e.flash-dt);
    if(e.enteredAt<0&&e.y>=-20)e.enteredAt=this.elapsed;
    const s=this.stageIndex,p=this.player;
    if(e.type==='boss'){
      e.intro=Math.max(0,e.intro-dt);
      const targetY=Math.min(210,this.world.height*.2);
      e.y+=(targetY-e.y)*Math.min(1,dt*1.8);e.x=240+Math.sin(e.age*.6)*92;
      if(e.intro>0)return;
      if(e.hp<e.maxHp*.5&&!e.secondPhase){e.secondPhase=true;e.timer=.65;this.event('bossPhase',{name:this.stage.boss});}
      e.timer-=dt*this.fireRateScale;e.burstTimer-=dt*this.fireRateScale;
      if(e.timer<=0){for(const part of e.parts)if(part.hp>0)this.aimedFan(e,e.secondPhase?5:3,.18,170,e.x+part.x,e.y+part.y);e.timer=e.secondPhase?.98:1.35;}
      if(e.burstTimer<=0){
        const count=11+s*2+(e.secondPhase?2:0),offset=Math.sin(e.age)*.08;
        for(let i=0;i<count;i++)this.addBullet(e.x,e.y+30,.2+i*(Math.PI-.4)/(count-1)+offset,113+s*9,'petal',5);
        if(e.secondPhase)for(let i=0;i<12;i++)this.addBullet(e.x,e.y,Math.PI*2*i/12+e.age*.3,90+s*8,'petal',4.3);
        if(s>0&&e.secondPhase){const x=flightClamp(p.x+Math.sin(e.age)*45,45,435);this.hazards.push({x,warmup:1.2,age:0,active:.32,width:28});this.event('lock',{x});}
        e.burstTimer=e.secondPhase?2.3:3.0;
      }
    } else if(e.type==='gunship') {
      e.y+=(this.world.height*.25-e.y)*Math.min(1,dt*1.5);e.x=e.baseX+Math.sin(e.age*.8)*80;e.timer-=dt*this.fireRateScale;
      if(e.timer<=0){this.aimedFan(e,7,.17,132);for(const side of [-1,1])this.addBullet(e.x+side*42,e.y+22,Math.PI/2,145,'arc',5);e.timer=1.9;}
      if(e.age>15){e.y+=110*dt;if(e.age>20)e.dead=true;}
    } else {
      e.y+=(e.speed||110)*dt;
      if(e.pattern==='sine')e.x=flightClamp(e.baseX+Math.sin(e.age*1.8+e.seed)*36,25,455);
      if(e.pattern==='cross')e.x=flightClamp(e.baseX+(-e.side)*e.age*74,15,465);
      if(e.type==='diver')e.x=flightClamp(e.x+(e.drift||0)*dt,15,465);
      if(e.type==='tank')e.turretAngle=Math.atan2(p.y-e.y,p.x-e.x);
      e.timer-=dt*this.fireRateScale;
      if(e.timer<=0&&e.y>25&&e.y<p.y-50){
        if(e.type==='fighter'||e.type==='diver')this.aimedFan(e,this.pressure>.48?2:1,.2,155);
        else this.aimedFan(e,e.type==='carrier'?7:e.type==='tank'?2:4,.16,e.type==='tank'?185:163);
        e.timer=e.type==='fighter'?2.8:e.type==='tank'?1.8:2.0;
      }
      if(e.y>this.world.height+85||e.x<-100||e.x>580)e.dead=true;
    }
    if(!e.ground&&e.y>10&&Math.abs(e.x-p.x)<e.rx*.7+6&&Math.abs(e.y-p.y)<e.ry*.7+6)this.hurtPlayer();
  }
  update(dt,input={}) {
    if(this.state!=='playing')return;dt=Math.min(.034,Math.max(0,dt));
    this.elapsed+=dt;this.scroll+=this.stage.scroll*dt;this.stageTime+=dt;this.phaseTime+=dt;this.shake=Math.max(0,this.shake-dt*17);
    const p=this.player,bounds=this.bounds();p.spiritTimer-=dt;this.spirit.time=Math.max(0,this.spirit.time-dt);p.spirit=this.spirit.time>0&&this.phase!=='clear';p.invincible=Math.max(0,p.invincible-dt);p.fireTimer-=dt;p.missileTimer-=dt;this.laser.time=Math.max(0,this.laser.time-dt);this.bombCooldown=Math.max(0,this.bombCooldown-dt);this.bombTime=Math.max(0,this.bombTime-dt);
    const beforeX=p.x;
    if(input.target){const dx=input.target.x-p.x,dy=input.target.y-p.y,d=Math.hypot(dx,dy),step=1350*dt;p.x+=dx*(d>step?step/d:1);p.y+=dy*(d>step?step/d:1);}
    else{const len=Math.max(1,Math.hypot(input.x||0,input.y||0)),speed=360;p.x+=(input.x||0)/len*speed*dt;p.y+=(input.y||0)/len*speed*dt;}
    p.x=flightClamp(p.x,bounds.left,bounds.right);p.y=flightClamp(p.y,bounds.top,bounds.bottom);p.bank+=(flightClamp((p.x-beforeX)/(dt||1)/650,-1,1)-p.bank)*Math.min(1,dt*14);
    if(input.bomb)this.useBomb();
    this.chainTimer=Math.max(0,this.chainTimer-dt);if(!this.chainTimer)this.chain=0;
    if(this.phase==='clear'){
      if(this.phaseTime>3.1){if(this.stageIndex===2){this.score+=this.player.lives*3000+this.player.bombs*1000;this.finish(true);}else this.enterStage(this.stageIndex+1);}
    }else if(this.phase==='approach'){
      this.waveTimer-=dt;if(this.waveTimer<=0){this.spawnFormation();this.waveTimer=this.waveInterval;}
      if(this.supplyIndex<FLIGHT_BALANCE.supplyTimes.length&&this.stageTime>=FLIGHT_BALANCE.supplyTimes[this.supplyIndex]){
        this.supplyIndex++;this.lastSupplyTime=this.stageTime;this.waveTimer=Math.max(this.waveTimer,2.6);
        this.pickups.push(this.makePickup('power',flightClamp(p.x,60,420),Math.max(145,p.y-230)));
        if(p.lives<FLIGHT_BALANCE.maxLives)this.dropHeal(flightClamp(p.x+65,60,420),Math.max(145,p.y-180));
        this.event('supply',{x:p.x,y:p.y,level:this.threatLevel});
      }
      if(!this.miniSpawned&&this.stageTime>=18+this.stageIndex*3){this.miniSpawned=true;this.spawnEnemy('gunship',240,-70);this.event('incoming',{name:'守门妖灵接近'});}
      if(this.stageTime>=this.stage.duration){this.phase='boss';this.phaseTime=0;for(const e of this.enemies)e.dead=true;this.bullets=[];this.hazards=[];this.spawnEnemy('boss',240,-160);this.event('boss',{name:this.stage.boss});}
    }
    if(p.fireTimer<=0&&this.phase!=='clear')this.fire();
    if(p.spiritTimer<=0&&this.phase!=='clear')this.fireSpirit();
    for(const e of this.enemies)if(!e.dead)this.updateEnemy(e,dt);
    for(const shot of this.shots){
      if(shot.dead)continue;shot.px=shot.x;shot.py=shot.y;shot.age+=dt;
      if(shot.kind==='missile'){
        const target=this.targetFor(shot);if(target){const aim=Math.atan2(target.y-shot.y,target.x-shot.x),delta=Math.atan2(Math.sin(aim-shot.angle),Math.cos(aim-shot.angle));shot.angle+=flightClamp(delta,-dt*5,dt*5);const speed=580+shot.age*120;shot.vx=Math.cos(shot.angle)*speed;shot.vy=Math.sin(shot.angle)*speed;}
      }
      shot.x+=shot.vx*dt;shot.y+=shot.vy*dt;shot.life-=dt;
      if(shot.life<=0||shot.y<-80||shot.y>this.world.height+80||shot.x<-70||shot.x>550){shot.dead=true;continue;}
      for(const e of this.enemies){
        if(e.dead||shot.hit?.has(e)||e.y<100||e.type==='boss'&&e.intro>0)continue;
        let partHit=false;
        for(const part of e.parts||[])if(part.hp>0&&flightSegmentHit(shot.px,shot.py,shot.x,shot.y,e.x+part.x,e.y+part.y,18+shot.r)){this.damagePart(e,part,shot.damage,!!shot.spirit);partHit=true;break;}
        const bodyHit=partHit||flightBoxHit(shot.px,shot.py,shot.x,shot.y,e.x-e.rx*.73-shot.r,e.y-e.ry-shot.r,e.x+e.rx*.73+shot.r,e.y+e.ry+shot.r);
        if(bodyHit){if(shot.pierce>0){(shot.hit||=new Set()).add(e);shot.pierce--;}else shot.dead=true;this.shotsHit++;if(!partHit)this.damageEnemy(e,shot.damage,!!shot.spirit);this.event('hit',{x:shot.x,y:shot.y,color:FLIGHT_WEAPONS[p.weapon].color});break;}
      }
    }
    for(const bullet of this.bullets){
      bullet.px=bullet.x;bullet.py=bullet.y;bullet.x+=bullet.vx*dt;bullet.y+=bullet.vy*dt;bullet.age+=dt;
      if(this.bombTime>0||bullet.age>12||bullet.x<-50||bullet.x>530||bullet.y<-60||bullet.y>this.world.height+50)bullet.dead=true;
      if(!bullet.dead&&flightSegmentHit(bullet.px,bullet.py,bullet.x,bullet.y,p.x,p.y,bullet.r+p.r)){if(this.hurtPlayer())bullet.dead=true;}
    }
    for(const hazard of this.hazards){hazard.age+=dt;if(hazard.age>hazard.warmup&&hazard.age<hazard.warmup+hazard.active&&Math.abs(p.x-hazard.x)<hazard.width/2+p.r)this.hurtPlayer();}
    for(const q of this.pickups){
      q.age+=dt;q.y+=(q.type==='medal'?102:94)*dt;q.x+=Math.sin(q.age*2+q.seed)*(q.type==='medal'?3:12)*dt;
      const distance=flightDist(q,p),magnet=q.type==='medal'?(q.homing?1800:110):q.type==='heal'?115:70;
      if(distance<magnet){const k=Math.min(1,dt*(q.type==='medal'?9:5));q.x+=(p.x-q.x)*k;q.y+=(p.y-q.y)*k;}
      if(distance<(q.type==='medal'?24:30))this.collect(q);
      if(q.y>this.world.height+35)q.dead=true;
    }
    this.updateTension(dt);
    this.enemies=this.enemies.filter(e=>!e.dead);this.bullets=this.bullets.filter(b=>!b.dead);this.shots=this.shots.filter(s=>!s.dead);this.pickups=this.pickups.filter(q=>!q.dead);this.hazards=this.hazards.filter(h=>h.age<h.warmup+h.active);
  }
}
