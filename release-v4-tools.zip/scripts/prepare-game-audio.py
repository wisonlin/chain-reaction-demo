"""Offline, reproducible CC0 audio preparation. No network during app builds."""
from pathlib import Path
import json,subprocess,hashlib,wave
import numpy as np
ROOT=Path(__file__).resolve().parents[1];OUT=ROOT/'assets/audio-v4';SOURCE=OUT/'source';OUT.mkdir(exist_ok=True)
def ff(source,target,filters,extra):
 subprocess.run(['ffmpeg','-hide_banner','-loglevel','error','-y','-i',str(source),'-af',filters,*extra,str(target)],check=True)
# Author-supplied complete loop sections, normalized with headroom, streamed by the clients.
for source,target in [('hope.ogg','voyage.m4a'),('boss.wav','guardian.m4a')]:
 ff(SOURCE/source,OUT/target,'loudnorm=I=-19:TP=-2:LRA=9,aresample=44100',['-c:a','aac','-b:a','128k','-movflags','+faststart'])
files={'shot':'laserSmall_000','shot-2':'laserSmall_001','shot-3':'laserSmall_002','kill':'explosionCrunch_000','kill-2':'explosionCrunch_001','kill-3':'explosionCrunch_002','bomb':'lowFrequency_explosion_000','hurt':'impactMetal_002'}
for key,source in files.items():
 ff(SOURCE/'kenney/Audio'/f'{source}.ogg',OUT/f'{key}.wav','highpass=f=70,lowpass=f=6800,alimiter=limit=0.8:level=false,afade=t=in:d=0.004',['-ac','1','-ar','22050','-c:a','pcm_s16le'])
# Bell transients with harmonics, stereo-free for small speakers. Different interval signatures.
rate=22050
for key,notes,duration in [('pickup',[880,1320],.24),('powerup',[523.25,659.25,783.99,1046.5],.65),('heal',[659.25,783.99,987.77,1318.5],.85)]:
 data=np.zeros(int(rate*duration),dtype=np.float64)
 for i,freq in enumerate(notes):
  offset=int(i*.072*rate);t=np.arange(len(data)-offset)/rate
  bell=(np.sin(2*np.pi*freq*t)*np.exp(-t*8)+.32*np.sin(2*np.pi*freq*2.002*t)*np.exp(-t*14)+.12*np.sin(2*np.pi*freq*3*t)*np.exp(-t*18))
  data[offset:]+=bell*np.minimum(1,t/.004)*.16
 data*=np.minimum(1,(duration-np.arange(len(data))/rate)/.045)
 with wave.open(str(OUT/f'{key}.wav'),'wb') as w:w.setparams((1,2,rate,0,'NONE','not compressed'));w.writeframes((np.clip(data,-.8,.8)*32767).astype('<i2').tobytes())
license={'license':'CC0-1.0','sources':[{'title':'Hope (Orchestral battle music)','author':'MintoDog','url':'https://opengameart.org/content/hopeorchestral-battle-music','use':'voyage.m4a — normalized/transcoded complete loop'},{'title':'Determined Pursuit','author':'Emma_MA','url':'https://opengameart.org/content/determined-pursuit-epic-orchestra-loop','use':'guardian.m4a — normalized/transcoded complete loop'},{'title':'Sci-fi Sounds','author':'Kenney','url':'https://kenney.nl/assets/sci-fi-sounds','use':'short lasers, explosions, impact; filtering/resampling'}],'original':['pickup.wav','powerup.wav','heal.wav']}
(OUT/'credits.json').write_text(json.dumps(license,ensure_ascii=False,indent=2)+'\n')
assets={p.stem:'data:'+('audio/mp4' if p.suffix=='.m4a' else 'audio/wav')+';base64,'+__import__('base64').b64encode(p.read_bytes()).decode() for p in OUT.iterdir() if p.suffix in ['.m4a','.wav']}
(ROOT/'src/audio-assets.js').write_text('// CC0 audio sources and preparation: assets/audio-v4/credits.json\nexport const AUDIO_ASSETS='+json.dumps(assets,separators=(',',':'))+';\n')
print('Prepared',len(assets),'audio assets;',sum(p.stat().st_size for p in OUT.iterdir() if p.is_file()),'bytes')
