import test from 'node:test';
import assert from 'node:assert/strict';
import {VerticalShooter,FLIGHT_BALANCE} from '../src/flight-game.js';
function game(weapon='spread'){const g=new VerticalShooter(()=>.5);g.reset({weapon});g.enemies=[];g.pickups=[];g.events=[];g.waveTimer=999;g.miniSpawned=true;return g;}
test('healing restores one life, caps at three, preserves firepower and can only collect once',()=>{
 const g=game();g.player.lives=1;g.player.power=5;
 const h=g.makePickup('heal',240,400);g.collect(h);g.collect(h);
 assert.equal(g.player.lives,2);assert.equal(g.healing,1);assert.equal(g.player.power,5);assert.ok(g.player.invincible>=1.2);
 g.collect(g.makePickup('heal',240,400));g.collect(g.makePickup('heal',240,400));
 assert.equal(g.player.lives,3);assert.equal(g.healing,2);assert.equal(g.events.filter(e=>e.type==='heal').length,2);
 assert.equal(g.score,300);assert.equal(g.state,'playing');
});
test('recovery supplies cannot stack or be farmed on every kill',()=>{
 const g=game();g.player.lives=2;
 assert.equal(g.dropHeal(),true);assert.equal(g.dropHeal(),false);
 g.pickups=[];assert.equal(g.dropHeal(),false);g.elapsed=FLIGHT_BALANCE.recoveryDelay;
 assert.equal(g.dropHeal(),true);g.collect(g.pickups[0]);assert.equal(g.player.lives,3);
});
test('timed supply reaches an injured player and creates a short breathing window',()=>{
 const g=game();g.player.lives=2;g.stageTime=9.999;g.elapsed=10;g.update(.008);
 assert.equal(g.supplyIndex,1);assert.ok(g.pickups.some(p=>p.type==='power'));assert.ok(g.pickups.some(p=>p.type==='heal'));
 assert.equal(g.breather,true);assert.ok(g.waveTimer>=2.5);
 const heal=g.pickups.find(p=>p.type==='heal');g.player.x=heal.x;g.player.y=heal.y;
 g.update(.008);assert.equal(g.player.lives,3);assert.equal(g.healing,1);
});
test('each stage ramps bullet speed, fire cadence and wave density with bounded growth',()=>{
 const g=game();let priorStage=0;
 for(let stage=0;stage<3;stage++){
  g.enterStage(stage);let prior={pressure:-1,speed:0,rate:0,interval:99};
  for(const fraction of [0,.2,.4,.6,.8,1]){
   g.stageTime=g.stage.duration*fraction;g.bullets=[];g.addBullet(100,100,Math.PI/2,180);
   const now={pressure:g.pressure,speed:g.bullets[0].vy,rate:g.fireRateScale,interval:g.waveInterval};
   assert.ok(now.pressure>=prior.pressure);assert.ok(now.speed>=prior.speed);assert.ok(now.rate>=prior.rate);assert.ok(now.interval<=prior.interval);
   assert.ok(now.speed<300);assert.ok(now.interval>=1.25);prior=now;
  }
  assert.ok(prior.pressure>priorStage);priorStage=prior.pressure;
 }
});
test('six firepower levels materially strengthen all three weapons without changing their identity',()=>{
 for(const weapon of ['spread','laser','homing']){
  const g=game(weapon),values=[];
  for(let power=1;power<=6;power++){
   g.player.power=power;g.player.missileTimer=0;g.shots=[];g.enemies=[];
   const target=g.spawnEnemy('boss',240,250,{hp:100000,maxHp:100000});target.intro=0;g.fire();
   const damage=weapon==='laser'?100000-target.hp:g.shots.reduce((s,p)=>s+p.damage,0);
   values.push({damage,shots:weapon==='laser'?g.laser.ends.length:g.shots.length,interval:g.player.fireTimer});
   assert.equal(g.player.weapon,weapon);
  }
  for(let p=1;p<6;p++)assert.ok(values[p].damage>=values[p-1].damage,weapon);
  assert.ok(values[5].damage>values[0].damage*2,weapon+' max firepower must feel distinct');assert.ok(values[5].shots>values[0].shots);
  assert.ok(values[5].interval<values[0].interval);
  for(let i=0;i<10;i++)g.collect(g.makePickup('power',240,500));assert.equal(g.player.power,6);
 }
});
test('maximum firepower and late-stage patterns remain inside object budgets',()=>{
 for(const weapon of ['spread','laser','homing']){
  const g=game(weapon);g.enterStage(2);g.player.power=6;g.player.invincible=999;g.stageTime=40;
  for(let frame=0;frame<1800&&g.state==='playing';frame++){
   g.update(1/120,{target:{x:240+Math.sin(frame/70)*130,y:720}});g.events=[];
   assert.ok(g.shots.length<=250);assert.ok(g.bullets.length<=520);assert.ok(g.enemies.length<=56);assert.ok(g.pickups.length<=110);
   for(const p of [...g.shots,...g.bullets])assert.ok(Number.isFinite(p.x)&&Number.isFinite(p.y));
  }
 }
});
