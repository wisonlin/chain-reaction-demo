import XCTest
import UIKit
@testable import Starborne
final class NativeEngineTests:XCTestCase {
    func testAudioSubmissionDoesNotBlockTheFrameThread() {
        let audio=NativeAudio(),start=CFAbsoluteTimeGetCurrent()
        for _ in 0..<100{audio.play("shot")}
        XCTAssertLessThan((CFAbsoluteTimeGetCurrent()-start)*1000,16.7,"Submitting cached effects must fit in one 60 Hz frame; playback belongs off the frame thread")
    }
    func testViewportResizePreservesPlayerResources() throws {
        let bridge=try GameBridge()
        _=try bridge.reset(character:"lune",hard:true,height:1000,seed:42)
        _=bridge.call("bomb");let before=try bridge.step(1/60,target:nil)
        let after=try bridge.frame(bridge.call("resize",[720]))
        XCTAssertEqual(after.worldHeight,720)
        XCTAssertEqual(after.player.bombs,before.player.bombs)
        XCTAssertEqual(after.player.lives,before.player.lives)
        XCTAssertEqual(after.score,before.score)
        XCTAssertEqual(after.hard,true)
        XCTAssertEqual(after.elapsed,before.elapsed)
    }
    func testSharedRulesAndTouchGesture() throws {
        let bridge=try GameBridge()
        let first=try bridge.reset(character:"aster",hard:false,height:1000,seed:42)
        XCTAssertEqual(first.player.weapon,"homing");XCTAssertEqual(first.player.lives,3);XCTAssertEqual(first.player.bombs,2)
        XCTAssertEqual(first.enemies.count,5)
        _=bridge.call("touchBegin",[40,600,0]);XCTAssertFalse(bridge.call("touchEnd",[40,600,50])!.toBool())
        _=bridge.call("touchBegin",[40,600,150]);XCTAssertTrue(bridge.call("touchEnd",[40,600,200])!.toBool())
        XCTAssertTrue(bridge.call("bomb")!.toBool());XCTAssertFalse(bridge.call("bomb")!.toBool())
        let next=try bridge.step(1/60,target:nil);XCTAssertEqual(next.player.bombs,1);XCTAssertTrue(next.events.contains{$0.type=="bomb"&&$0.lives==3})
        _=bridge.call("pause");let before=bridge.call("debugState")!.toString()
        for _ in 0..<60{_=try bridge.step(1/60,target:nil)}
        XCTAssertEqual(bridge.call("debugState")!.toString(),before)
    }
    func testAllOriginalHealthPortraitsAreBundled() throws {
        XCTAssertEqual(Traveller.load().count,6)
        for id in ["ember","lune","nerine","sol","vesper","aster"]{
            for tier in ["healthy","wounded","critical"]{
                let image=try XCTUnwrap(UIImage(named:"\(id)-\(tier)"));XCTAssertEqual(image.size,CGSize(width:512,height:1024))
            }
            for pose in 0..<4{XCTAssertNotNil(UIImage(named:"\(id)-\(pose)"))}
        }
    }
}
