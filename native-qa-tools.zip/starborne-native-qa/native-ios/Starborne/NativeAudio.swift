import AVFoundation

/// Decode once and schedule cached PCM buffers away from the render thread.
final class NativeAudio {
    private struct Clip {
        let buffer:AVAudioPCMBuffer
        let voices:[AVAudioPlayerNode]
        var next=0
    }
    private let queue=DispatchQueue(label:"com.wison.starborne.audio",qos:.userInitiated)
    private let engine=AVAudioEngine()
    private var clips:[String:Clip]=[:]
    var muted=false
    init(){queue.async{[self] in prepare()}}
    private func prepare(){
        try? AVAudioSession.sharedInstance().setCategory(.ambient,mode:.default)
        for key in ["shot","kill","bomb","hurt","pickup","powerup"] {
            guard let url=Bundle.main.url(forResource:key,withExtension:"wav"),
                  let file=try? AVAudioFile(forReading:url),
                  let buffer=AVAudioPCMBuffer(pcmFormat:file.processingFormat,frameCapacity:AVAudioFrameCount(file.length)),
                  (try? file.read(into:buffer)) != nil else{continue}
            let voices=(0..<(key=="shot" ? 4:2)).map{_ -> AVAudioPlayerNode in
                let voice=AVAudioPlayerNode();engine.attach(voice)
                engine.connect(voice,to:engine.mainMixerNode,format:buffer.format)
                voice.volume=key=="shot" ? 0.08:key=="bomb" ? 0.5:0.22
                return voice
            }
            clips[key]=Clip(buffer:buffer,voices:voices)
        }
        engine.prepare();try? engine.start()
    }
    func play(_ key:String){
        guard !muted else{return}
        queue.async{[self] in
            guard var clip=clips[key],!clip.voices.isEmpty else{return}
            if !engine.isRunning{try? engine.start()}
            let voice=clip.voices[clip.next % clip.voices.count]
            clip.next+=1;clips[key]=clip
            voice.scheduleBuffer(clip.buffer,at:nil,options:.interrupts)
            if !voice.isPlaying{voice.play()}
        }
    }
    deinit{engine.stop()}
}
