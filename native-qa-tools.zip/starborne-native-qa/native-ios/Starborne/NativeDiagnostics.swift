import Foundation
import SpriteKit
import QuartzCore
import os
import Darwin

/// Simulator diagnostics are opt-in and cannot be enabled on physical devices.
enum NativeQA {
    #if targetEnvironment(simulator)
    static let enabled=ProcessInfo.processInfo.arguments.contains("--native-qa")
    static func value(_ key:String)->String? {
        let args=ProcessInfo.processInfo.arguments
        guard enabled,let i=args.firstIndex(of:key),i+1<args.count else{return nil}
        return args[i+1]
    }
    #else
    static let enabled=false
    static func value(_ key:String)->String? { nil }
    #endif
    static let signposter=OSSignposter(subsystem:"com.wison.starborne",category:"Frame")
}

final class NativeDiagnostics {
    private var samples:[[String:Any]]=[]
    private var started:Double=0,lastTime:Double=0,lastWrite:Double=0
    private var completed=false
    func reset(){samples.removeAll(keepingCapacity:true);started=0;lastTime=0;lastWrite=0;completed=false}
    func sample(time:Double,engineMS:Double,renderMS:Double,observerMS:Double,eventsMS:Double,scene:SKScene,frame:GameFrame){
        guard NativeQA.enabled,!completed else{return}
        if started==0{started=time;lastTime=time;return}
        let wall=time-started
        let interval=(time-lastTime)*1000;lastTime=time
        let nodes=scene.children.reduce(1){$0+$1.children.count+1}
        samples.append(["wall":wall,"intervalMS":interval,"engineMS":engineMS,"eventsMS":eventsMS,"renderMS":renderMS,"observerMS":observerMS,"state":frame.state,"elapsed":frame.elapsed,"nodes":nodes,"shots":frame.shots.count,"bullets":frame.bullets.count,"enemies":frame.enemies.count])
        if wall-lastWrite>=1 {lastWrite=wall;write(scene:scene,frame:frame)}
        if wall >= (Double(NativeQA.value("--qa-duration") ?? "16") ?? 16) {completed=true;write(scene:scene,frame:frame)}
    }
    private func write(scene:SKScene,frame:GameFrame){
        let warmed=samples.filter{($0["wall"] as? Double ?? 0)>=2 && $0["state"] as? String=="playing"}
        func stats(_ key:String)->[String:Double]{
            let a=warmed.compactMap{$0[key] as? Double}.sorted();guard !a.isEmpty else{return [:]}
            return ["mean":a.reduce(0,+)/Double(a.count),"p50":a[Int(Double(a.count-1)*0.5)],"p95":a[Int(Double(a.count-1)*0.95)],"max":a.last!]
        }
        var info=mach_task_basic_info();var count=mach_msg_type_number_t(MemoryLayout<mach_task_basic_info>.size)/4
        let status=withUnsafeMutablePointer(to:&info){p in p.withMemoryRebound(to:integer_t.self,capacity:Int(count)){task_info(mach_task_self_,task_flavor_t(MACH_TASK_BASIC_INFO),$0,&count)}}
        let payload:[String:Any]=["schema":1,"completed":completed,"character":frame.character,"hard":frame.hard,"worldHeight":frame.worldHeight,"samples":samples,"summary":["warmupSeconds":2,"playingSamples":warmed.count,"intervalMS":stats("intervalMS"),"engineMS":stats("engineMS"),"eventsMS":stats("eventsMS"),"renderMS":stats("renderMS"),"observerMS":stats("observerMS"),"residentMB":status==KERN_SUCCESS ? Double(info.resident_size)/1048576:0,"sceneID":String(describing:ObjectIdentifier(scene))],"state":["mode":frame.state,"elapsed":frame.elapsed,"x":frame.player.x,"y":frame.player.y,"bombs":frame.player.bombs,"lives":frame.player.lives]]
        guard let data=try? JSONSerialization.data(withJSONObject:payload,options:[.sortedKeys]),let dir=FileManager.default.urls(for:.documentDirectory,in:.userDomainMask).first else{return}
        try? data.write(to:dir.appendingPathComponent("native-qa.json"),options:.atomic)
    }
}
