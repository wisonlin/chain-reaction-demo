#!/usr/bin/env python3
"""Parse xctrace time-profile XML with id/ref resolution, not text matching XML."""
import argparse,json,collections,xml.etree.ElementTree as E
from pathlib import Path
p=argparse.ArgumentParser();p.add_argument('xml',type=Path);p.add_argument('--output',type=Path,required=True);a=p.parse_args()
r=E.parse(a.xml).getroot();ids={e.get('id'):e for e in r.iter() if e.get('id')}
def resolve(e):
 seen=set()
 while e is not None and e.get('ref'):
  ref=e.get('ref')
  if ref in seen:raise ValueError('cyclic trace reference')
  seen.add(ref);e=ids.get(ref)
 return e
def value(e):
 e=resolve(e);return (e.get('fmt') or e.text or '') if e is not None else ''
inclusive=collections.Counter();own=collections.Counter();main=collections.Counter();total=0;main_total=0;rows=0
for row in r.iter('row'):
 bt=resolve(row.find('backtrace'));w=resolve(row.find('weight'))
 if bt is None or w is None:continue
 weight=int(w.text or 0)/1e6;total+=weight;rows+=1
 ismain='Main Thread' in value(row.find('thread'))
 if ismain:main_total+=weight
 stack=[]
 for entry in bt:
  f=resolve(entry)
  if f is None or f.tag!='frame':continue
  b=resolve(f.find('binary'));key=(f.get('name','<unresolved>'),b.get('name','<unknown>') if b is not None else '<unknown>')
  stack.append(key)
 if stack:own[stack[0]]+=weight
 for k in set(stack):
  inclusive[k]+=weight
  if ismain:main[k]+=weight
def records(counter,app=False):
 result=[]
 for (name,binary),ms in counter.most_common():
  if app and binary!='Starborne':continue
  result.append({'name':name,'binary':binary,'inclusiveMS':round(ms,3),'inclusivePct':round(ms/max(1,total)*100,2),'selfMS':round(own[(name,binary)],3)})
  if len(result)>=25:break
 return result
report={'schema':1,'support':{'cpu':'available' if rows else 'not_present','gpu':'not_measured','deviceFrameRate':'not_measured'},'sampleRows':rows,'sampledCPUms':round(total,3),'mainThreadCPUms':round(main_total,3),'topAppFrames':records(inclusive,True),'topMainThreadFrames':records(main),'topFrames':records(inclusive),'limitations':['CPU samples are inclusive and overlap; percentages must not be added.','Simulator CPU sampling does not establish iPhone GPU performance or energy use.']}
a.output.write_text(json.dumps(report,ensure_ascii=False,indent=2));print(json.dumps({'rows':rows,'topAppFrames':report['topAppFrames'][:8],'topMainThreadFrames':report['topMainThreadFrames'][:10]}))
