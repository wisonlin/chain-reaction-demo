#!/usr/bin/env python3
"""Bounded, repeatable Release simulator profiling. Never targets physical phones."""
import argparse,json,subprocess,time,shutil
from pathlib import Path

p=argparse.ArgumentParser()
p.add_argument('--udid',required=True)
p.add_argument('--app',type=Path,required=True)
p.add_argument('--output',type=Path,required=True)
p.add_argument('--character',choices=['lune','aster','ember','nerine','sol','vesper'],default='lune')
p.add_argument('--duration',type=int,default=14)
p.add_argument('--muted',action='store_true')
p.add_argument('--hard',action='store_true')
p.add_argument('--trace',action='store_true')
a=p.parse_args()
if not 6<=a.duration<=45:p.error('duration must be 6–45 seconds')
a.output.mkdir(parents=True,exist_ok=True)
def run(args,check=True):
 r=subprocess.run(args,capture_output=True,text=True,timeout=120)
 if check and r.returncode:raise RuntimeError(f'{args[0:3]}: {r.stderr or r.stdout}')
 return r.stdout.strip()
devices=json.loads(run(['xcrun','simctl','list','devices','-j']))
device=next((d for group in devices['devices'].values() for d in group if d['udid']==a.udid),None)
if not device or device['state']!='Booted':p.error('explicit booted simulator required')
run(['xcrun','simctl','terminate',a.udid,'com.wison.starborne'],check=False)
run(['xcrun','simctl','install',a.udid,str(a.app.resolve())])
container=Path(run(['xcrun','simctl','get_app_container',a.udid,'com.wison.starborne','data']))
metrics=container/'Documents/native-qa.json'
if metrics.exists():metrics.rename(metrics.with_suffix('.previous.json'))
run(['xcrun','simctl','launch',a.udid,'com.wison.starborne','--native-qa','--qa-autostart','true','--qa-character',a.character,'--qa-duration',str(a.duration),'--qa-muted',str(a.muted).lower(),'--qa-hard',str(a.hard).lower()])
# XCTest can leave the accessibility transport unavailable briefly. Performance
# capture starts through simulator-only launch arguments; real gestures remain
# covered independently by XCUITest, not inferred from this harness.
time.sleep(1.5)
started=time.monotonic()
trace=None
if a.trace:
 log=(a.output/'trace.log').open('w')
 trace=subprocess.Popen(['xcrun','xctrace','record','--device',a.udid,'--template','Time Profiler','--attach','Starborne','--time-limit',f'{a.duration-2}s','--output',str(a.output/'cpu.trace'),'--no-prompt'],stdout=log,stderr=log)
time.sleep(3)
run(['axe','screenshot','--udid',a.udid,'--output',str(a.output/'overlay.png')])
deadline=time.monotonic()+a.duration+8
while time.monotonic()<deadline:
 if metrics.exists():
  report=json.loads(metrics.read_text())
  if report.get('completed'):break
 time.sleep(.5)
else:raise RuntimeError('app failed to complete diagnostics in time')
shutil.copy2(metrics,a.output/'frames.json')
if trace:
 if trace.wait(timeout=90)!=0:raise RuntimeError('Time Profiler capture failed; see trace.log')
 log.close()
report['environment']={'device':device['name'],'simulator':True,'configuration':'Release','character':a.character,'hard':a.hard,'muted':a.muted,'requestedDuration':a.duration,'trace':a.trace}
(a.output/'frames.json').write_text(json.dumps(report,separators=(',',':')))
print(json.dumps({'output':str(a.output),'summary':report['summary'],'completed':report['completed']}))
