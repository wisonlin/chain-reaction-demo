#!/usr/bin/env python3
import argparse,json
from pathlib import Path

def check(report,budgets):
    errors=[];summary=report.get('summary',{});samples=report.get('samples',[])
    if not report.get('completed'):errors.append('capture incomplete')
    if summary.get('playingSamples',0)<budgets['minimumPlayingSamples']:errors.append('insufficient playing samples')
    for name,key in [('interval','intervalMS'),('engine','engineMS'),('events','eventsMS'),('render','renderMS')]:
        value=summary.get(key,{}).get('p95')
        if not isinstance(value,(int,float)):errors.append(f'{key} was not measured')
        elif value>budgets[name+'P95MS']:errors.append(f'{key} p95 {value:.2f} exceeds {budgets[name+"P95MS"]}')
    playing=[s for s in samples if s.get('wall',0)>=2 and s.get('state')=='playing']
    if not playing:errors.append('raw playing frame data missing')
    else:
        if max(s.get('nodes',0) for s in playing)>budgets['maximumNodes']:errors.append('node budget exceeded')
        fraction=sum(s.get('intervalMS',0)>budgets['slowFrameMS'] for s in playing)/len(playing)
        if fraction>budgets['maximumSlowFrameFraction']:errors.append(f'slow frame fraction {fraction:.3%} exceeds budget')
    return {'passed':not errors,'errors':errors,'playingSamples':summary.get('playingSamples',0),'p95FrameIntervalMS':summary.get('intervalMS',{}).get('p95')}

if __name__=='__main__':
    p=argparse.ArgumentParser();p.add_argument('frames',type=Path);p.add_argument('--config',type=Path,default=Path('.asc/native-qa.json'));p.add_argument('--output',type=Path);a=p.parse_args()
    result=check(json.loads(a.frames.read_text()),json.loads(a.config.read_text())['budgets'])
    if a.output:a.output.write_text(json.dumps(result,indent=2))
    print(json.dumps(result));raise SystemExit(0 if result['passed'] else 1)
