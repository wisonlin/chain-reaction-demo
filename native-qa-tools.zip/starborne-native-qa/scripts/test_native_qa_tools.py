import unittest,importlib.util,json,tempfile,subprocess,sys
from pathlib import Path
ROOT=Path(__file__).resolve().parents[1]
spec=importlib.util.spec_from_file_location('gate',ROOT/'scripts/check-native-performance.py');gate=importlib.util.module_from_spec(spec);spec.loader.exec_module(gate)
class QAToolTests(unittest.TestCase):
    def testMissingMeasurementCannotPass(self):
        budgets=json.loads((ROOT/'.asc/native-qa.json').read_text())['budgets']
        self.assertFalse(gate.check({'completed':True},budgets)['passed'])
    def testRecordedAudioRegressionFailsAndFixPasses(self):
        budgets=json.loads((ROOT/'.asc/native-qa.json').read_text())['budgets']
        # Small schema fixtures exercise the gate, not timing on the test host.
        sample={'wall':3,'state':'playing','nodes':80,'intervalMS':16.67}
        r={'completed':True,'samples':[sample],'summary':{'playingSamples':400,**{k:{'p95':v} for k,v in [('intervalMS',16.67),('engineMS',1),('eventsMS',.05),('renderMS',.5)]}}}
        self.assertTrue(gate.check(r,budgets)['passed'])
        r['summary']['eventsMS']['p95']=26
        self.assertFalse(gate.check(r,budgets)['passed'])
    def testTraceReferencesAreResolved(self):
        xml='<trace-query-result><row><weight id="w">1000000</weight><thread fmt="Main Thread"/><backtrace id="b"><frame id="f" name="work"><binary id="bin" name="Starborne"/></frame></backtrace></row><row><weight ref="w"/><thread fmt="Main Thread"/><backtrace ref="b"/></row></trace-query-result>'
        with tempfile.TemporaryDirectory() as td:
            p=Path(td);(p/'trace.xml').write_text(xml)
            subprocess.run([sys.executable,str(ROOT/'scripts/analyze-native-trace.py'),str(p/'trace.xml'),'--output',str(p/'cpu.json')],check=True,capture_output=True)
            r=json.loads((p/'cpu.json').read_text());self.assertEqual(r['sampleRows'],2);self.assertEqual(r['topAppFrames'][0]['inclusiveMS'],2)
if __name__=='__main__':unittest.main()
