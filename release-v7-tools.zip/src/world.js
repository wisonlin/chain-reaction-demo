import {WORLD_SIZE,WORLD_REGIONS,WORLD_POIS,worldRegion,worldPOI,worldMission} from './world-data.js';
import {ROLES} from './flight-expedition-data.js';
const clamp=(v,a,b)=>Math.max(a,Math.min(b,Number(v)||0)),dist=(a,b)=>Math.hypot(a.x-b.x,a.y-b.y),valid=id=>!!worldPOI(id);
const list=(x,check=valid)=>Array.isArray(x)?[...new Set(x.filter(v=>typeof v==='string'&&check(v)))]:[];
export function freshWorld(){return {version:1,region:'haven',positions:{haven:{x:800,y:1900},lagoon:{x:800,y:1900},ruins:{x:800,y:1900}},unlocked:['haven'],discovered:['haven-0','haven-1'],claimed:[],beacons:['haven-0'],cleared:[],talked:[],sideDone:[],puzzles:{'haven-8':0,'lagoon-8':0,'ruins-8':0},tiles:[],tracked:'haven-1',pending:null,lastMessage:'向北靠近风图绘师，听听群岛发生了什么。'};}
export function normalizeWorld(input){
 const b=freshWorld();if(!input||typeof input!=='object')return b;
 for(const k of ['discovered','claimed','beacons','cleared','talked'])b[k]=list(input[k]);
 b.unlocked=['haven',...list(input.unlocked,x=>['lagoon','ruins'].includes(x)&&list(input.cleared).includes(x==='lagoon'?'haven-10':'lagoon-10'))];
 b.region=b.unlocked.includes(input.region)?input.region:'haven';
 b.sideDone=list(input.sideDone,x=>WORLD_REGIONS.some(r=>r.id===x));
 for(const r of WORLD_REGIONS){const pos=input.positions?.[r.id];if(pos)b.positions[r.id]={x:clamp(pos.x,80,1520),y:clamp(pos.y,100,2100)};const id=r.id+'-8';b.puzzles[id]=Math.floor(clamp(input.puzzles?.[id],0,3));}
 b.beacons=[...new Set(['haven-0',...b.beacons.filter(id=>['camp','beacon'].includes(worldPOI(id).type)&&b.unlocked.includes(worldPOI(id).region))])];
 b.tiles=list(input.tiles,v=>/^(haven|lagoon|ruins):[0-7]:([0-9]|10)$/.test(v)).slice(-264);
 b.tracked=valid(input.tracked)&&worldPOI(input.tracked).region===b.region?input.tracked:b.region+'-1';
 const pending=input.pending,p=pending&&worldPOI(pending.id);if(p&&worldMission(p.id)&&b.unlocked.includes(p.region)&&typeof pending.runId==='string'&&pending.runId.length<150)b.pending={id:p.id,runId:pending.runId};
 b.lastMessage=typeof input.lastMessage==='string'?input.lastMessage.slice(0,300):b.lastMessage;
 for(const id of [b.region+'-0',b.region+'-1'])if(!b.discovered.includes(id))b.discovered.push(id);
 return b;
}
const reward=(camp,values)=>{for(const [k,v]of Object.entries(values))if(Object.hasOwn(camp.wallet,k))camp.wallet[k]=Math.min(999999,camp.wallet[k]+v);};
export function worldAction(world,camp,action,party={main:'lune',support:'nerine'}){
 const w=normalizeWorld(world),c=JSON.parse(JSON.stringify(camp)),p=worldPOI(action.id),r=worldRegion(w.region),pos=w.positions[w.region];
 const fail=message=>({world:w,camp:c,ok:false,message,dialog:null,mission:null});
 const result=(message,dialog=null,mission=null)=>{w.lastMessage=message;return {world:w,camp:c,ok:true,message,dialog,mission}};
 if(action.type==='track'){if(!p||p.region!==w.region)return fail('请在当前区域选择地点');w.tracked=p.id;return result('已标记 '+p.name+'，可自动巡航或单指拖动前往。');}
 if(action.type==='travel'){
  if(!p||!w.beacons.includes(p.id)||!w.unlocked.includes(p.region))return fail('先亲自抵达并点亮航标，才能传送。');
  w.region=p.region;w.positions[p.region]={x:p.x,y:Math.min(2100,p.y+60)};w.tracked=p.region+'-1';return result('已传送至 '+p.name);
 }
 if(!p||p.region!==w.region||dist(p,pos)>110)return fail('靠近地点后再互动；地图标记不会直接领取远处奖励。');
 if(!w.discovered.includes(p.id))w.discovered.push(p.id);
 if(action.type==='resonate'){
  if(p.type!=='puzzle')return fail('这里没有共鸣机关。');if(w.claimed.includes(p.id))return fail('共鸣碑已经点亮。');
  const element=action.element;if(![ROLES[party.main]?.element,ROLES[party.support]?.element].includes(element))return fail('队伍缺少这个元素，请先调整主战或支援。');
  const step=w.puzzles[p.id]||0;if(element!==r.sequence[step]){w.puzzles[p.id]=0;return result('回应错了，机关已归零。没有消耗材料。'+r.clue);}
  w.puzzles[p.id]=step+1;if(step===2){w.claimed.push(p.id);reward(c,{[r.element]:2,tickets:2});w.tracked=r.id+'-10';return result('共鸣碑点亮！元素印 +2，祈星券 +2。北方的守望者已苏醒。');}
  return result('共鸣 '+(step+1)+'/3。'+r.clue);
 }
 if(action.type!=='interact')return fail('未知探索操作');
 if(p.type==='camp'||p.type==='beacon'){
  if(!w.beacons.includes(p.id)){w.beacons.push(p.id);reward(c,{tickets:1,coins:80});return result('航标已点亮，祈星券 +1。地图中可免费传送到这里。');}
  return result(p.type==='camp'?'营地已保存当前位置。这里不会收取体力或等待时间。':'航标已点亮，可随时免费传送。');
 }
 if(p.type==='npc'){
  if(!w.talked.includes(p.id)){w.talked.push(p.id);w.tracked=r.id+'-8';return result('接到主线：'+r.chapter,{title:r.chapter,speaker:r.speaker,hero:r.hero,text:r.intro+'\n\n支线 · '+r.sideTitle+'：'+r.sideText});}
  const pieces=[r.id+'-5',r.id+'-6'].every(id=>w.claimed.includes(id));
  if(pieces&&!w.sideDone.includes(r.id)){w.sideDone.push(r.id);reward(c,{coins:300,books:6,ore:6,threads:8});return result('支线完成！织梦丝 +8，札记 +6，锻星矿 +6，铸币 +300。',{title:r.sideTitle,speaker:r.speaker,hero:r.hero,text:'谢谢。你带回来的不只是遗落的物件，还有一个仍被记得的名字。\n\n'+(w.cleared.includes(r.id+'-10')?r.ending:r.sideText)});}
  return result('与'+r.speaker+'交谈',{title:w.cleared.includes(r.id+'-10')?'本章回响':r.chapter,speaker:r.speaker,hero:r.hero,text:w.cleared.includes(r.id+'-10')?r.ending:r.intro+'\n\n支线 · '+r.sideTitle+'：'+r.sideText});
 }
 if(['chest','gather','relic','lore','vista'].includes(p.type)){
  if(w.claimed.includes(p.id))return result('这处发现已经记录，可在地图手记中重读。',p.type==='lore'||p.type==='vista'?{title:p.name,speaker:'探索手记',hero:r.hero,text:p.type==='lore'?r.lore:r.vista}:null);
  w.claimed.push(p.id);const gifts=p.type==='chest'?{coins:260,books:4,ore:4,tickets:2}:p.type==='gather'?{ore:8,[r.element]:2}:p.type==='relic'?{coins:50}:p.type==='vista'?{tickets:1,threads:1}:{books:3};reward(c,gifts);
  const message=p.type==='relic'?'找到支线物件 '+p.fragment+'/2；两件齐全后回到营地交给'+r.speaker+'。':p.type==='gather'?'采集成功：锻星矿 +8，'+r.drop.split(' · ')[0]+' +2。':p.type==='chest'?'宝箱已开启：祈星券 +2，札记 +4，锻星矿 +4，铸币 +260。':'发现已写入探索手记。';
  return result(message,['lore','vista'].includes(p.type)?{title:p.name,speaker:'探索手记',hero:r.hero,text:p.type==='lore'?r.lore:r.vista}:null);
 }
 if(p.type==='puzzle')return result(w.claimed.includes(p.id)?'共鸣碑已经点亮。':r.clue,{title:p.name,speaker:'共鸣机关',hero:r.hero,text:r.clue,puzzle:p.id});
 if(p.type==='portal'){
  if(!w.cleared.includes(r.id+'-10'))return fail('本章守望者尚未平息，北方航门还未开启。');
  const next=worldRegion(p.to);w.region=next.id;if(!w.unlocked.includes(next.id))w.unlocked.push(next.id);w.positions[next.id]={x:800,y:1900};w.tracked=next.id+'-1';if(!w.beacons.includes(next.id+'-0'))w.beacons.push(next.id+'-0');return result('抵达 '+next.name+'。不同区域拥有独特环境与材料。');
 }
 if(p.type==='battle'||p.type==='boss'){
  if(p.type==='boss'&&(!w.talked.includes(r.id+'-1')||!w.claimed.includes(r.id+'-8')))return fail('先与营地旅人交谈，并点亮本区域共鸣碑。');
  if(typeof action.runId!=='string'||!action.runId||action.runId.length>149)return fail('无法建立本机遭遇记录');
  w.pending={id:p.id,runId:action.runId};return result('遭遇开始：'+p.name,null,worldMission(p.id));
 }
 return fail('这里暂时没有可互动内容。');
}
export function settleWorld(world,camp,result){
 const w=normalizeWorld(world);if(!result?.worldMission||w.pending?.id!==result.worldMission||w.pending.runId!==result.runId)return {world:w,camp};
 const p=worldPOI(w.pending.id),r=worldRegion(p.region);w.pending=null;
 if(!result.won){w.lastMessage='未能突破'+p.name+'。已收集的战斗材料保留，调整队伍后可再来。';return {world:w,camp};}
 const c=JSON.parse(JSON.stringify(camp)),first=!w.cleared.includes(p.id);if(first){w.cleared.push(p.id);reward(c,p.type==='boss'?r.rewards:{[r.element]:2,ore:5,tickets:2});}
 else reward(c,{[r.element]:1,coins:60});
 w.lastMessage=first?'首次突破 '+p.name+'，区域奖励已入背包。':'再次突破，获得元素印 +1、铸币 +60。';
 if(p.type==='boss'){const next=WORLD_REGIONS[r.stage+1];if(next&&!w.unlocked.includes(next.id))w.unlocked.push(next.id);w.tracked=r.id+'-12';w.lastMessage=r.ending;}
 return {world:w,camp:c};
}
export class SkyWorld {
 constructor(state,options={}){this.state=normalizeWorld(state);this.height=clamp(options.height||850,640,1400);this.time=0;this.paused=false;this.cruise=false;this.bank=0;this.discover();}
 get player(){return this.state.positions[this.state.region]}
 track(){return worldPOI(this.state.tracked)}
 discover(){const w=this.state,p=this.player;for(const q of WORLD_POIS.filter(q=>q.region===w.region))if(dist(p,q)<270&&!w.discovered.includes(q.id))w.discovered.push(q.id);const cx=Math.floor(p.x/200),cy=Math.floor(p.y/200);for(let x=Math.max(0,cx-1);x<=Math.min(7,cx+1);x++)for(let y=Math.max(0,cy-1);y<=Math.min(10,cy+1);y++){const key=w.region+':'+x+':'+y;if(!w.tiles.includes(key))w.tiles.push(key)}}
 update(dt,input={}){if(this.paused)return;dt=clamp(dt,0,.05);this.time+=dt;const p=this.player,old=p.x,t=input.target||this.cruise&&this.track();if(t){const dx=t.x-p.x,dy=t.y-p.y,d=Math.hypot(dx,dy),max=(input.target?1350:260)*dt,stop=input.target?0:78;if(d>stop+0.001){const n=Math.min(max,d-stop)/(d||1);p.x+=dx*n;p.y+=dy*n}else this.cruise=false;}p.x=clamp(p.x,80,1520);p.y=clamp(p.y,100,2100);this.bank+=(clamp((p.x-old)/(dt||1)/650,-1,1)-this.bank)*Math.min(1,dt*14);this.discover();}
 frame(){const w=this.state,p=this.player,region=worldRegion(w.region),pois=WORLD_POIS.filter(q=>q.region===w.region).map(q=>({...q,discovered:w.discovered.includes(q.id),done:w.claimed.includes(q.id)||w.cleared.includes(q.id)||w.beacons.includes(q.id)||w.talked.includes(q.id)||(q.type==='portal'&&w.cleared.includes(q.region+'-10')),distance:Math.round(dist(p,q))}));const near=pois.filter(q=>q.distance<=110).sort((a,b)=>a.distance-b.distance)[0]||null;return {region:region.id,player:{...p,bank:this.bank},camera:{x:clamp(p.x-240,0,1120),y:clamp(p.y-this.height*.63,0,2200-this.height)},height:this.height,time:this.time,cruise:this.cruise,pois,near:near?.id||null,tracked:w.tracked,explored:pois.filter(q=>q.done).length,total:pois.length,chapter:region.subtitle,objective:w.cleared.includes(region.id+'-10')?'主线完成 · 可通过北方航门前往下一区域':!w.talked.includes(region.id+'-1')?'主线 · 靠近营地旅人，接取故事':!w.claimed.includes(region.id+'-8')?'主线 · 点亮共鸣碑，开启北方守望者':'主线 · 前往北方，平息守望者',message:w.lastMessage,tiles:w.tiles};}
}
