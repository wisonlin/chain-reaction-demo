import Foundation
struct WorldPosition:Decodable {let x,y:Double;let bank:Double?}
struct WorldRegion:Decodable,Identifiable {let id,name,subtitle,element,color,weather,mechanic,drop,chapter,boss,clue,speaker,hero,intro,ending,sideTitle,sideText,lore,vista:String;let stage:Int;let sequence:[String];let rewards:[String:Int]}
struct WorldPlace:Decodable,Identifiable {let id,region,type,name,icon:String;let x,y:Double;let to:String?;let fragment:Int?;let discovered,done:Bool?;let distance:Int?}
struct WorldPending:Decodable {let id,runId:String}
struct WorldState:Decodable {let version:Int;let region:String;let positions:[String:WorldPosition];let unlocked,discovered,claimed,beacons,cleared,talked,sideDone,tiles:[String];let puzzles:[String:Int];let tracked,lastMessage:String;let pending:WorldPending?}
struct WorldFrame:Decodable {let region:String;let player,camera:WorldPosition;let height,time:Double;let cruise:Bool;let pois:[WorldPlace];let near:String?;let tracked:String;let explored,total:Int;let chapter,objective,message:String;let tiles:[String]}
struct WorldDialogue:Decodable {let title,speaker,hero,text:String;let puzzle:String?}
struct WorldMission:Decodable {let id,region,name,boss,element,weather,mechanic,code:String;let stage,duration:Int;let bossFight:Bool;let hpScale:Double}
struct WorldActionResult:Decodable {let profile:FlightProgress;let ok:Bool;let message:String;let dialog:WorldDialogue?;let mission:WorldMission?}
struct WorldContent:Decodable {
 let regions:[WorldRegion],pois:[WorldPlace]
 static let shared:WorldContent={let u=Bundle.main.url(forResource:"world",withExtension:"json")!;return try! JSONDecoder().decode(WorldContent.self,from:Data(contentsOf:u))}()
 func region(_ id:String)->WorldRegion {regions.first{$0.id==id} ?? regions[0]}
 func place(_ id:String)->WorldPlace? {pois.first{$0.id==id}}
}
