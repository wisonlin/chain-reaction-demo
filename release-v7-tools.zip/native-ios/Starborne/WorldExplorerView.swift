import SwiftUI
import SpriteKit
private let woPaper=Color(hex:"f2ead4"),woGold=Color(hex:"eddaa7"),woMist=Color(hex:"bfd8da"),woInk=Color(hex:"102b40")

final class WorldController:ObservableObject,WorldSceneObserver {
 unowned let game:GameStore
 let scene:WorldScene
 let content=WorldContent.shared
 @Published var frame:WorldFrame?
 @Published var panel=""
 @Published var dialog:WorldDialogue?
 @Published var notice=""
 @Published var mapRegion="haven"
 @Published var pin="haven-1"
 private var savedAt=0.0
 init(game:GameStore){self.game=game;scene=WorldScene(bridge:game.scene.bridge);scene.observer=self}
 var region:WorldRegion {content.region(frame?.region ?? "haven")}
 var state:WorldState? {game.progress.world}
 func open(height:Double){scene.isPaused=false;scene.selected=game.selected;scene.skin=game.actor.skin;scene.resize(height);scene.open(game.worldRaw,height:height);game.saveWorld();if NativeQA.value("--qa-world") != nil{game.scene.bridge.call("worldCruise")}}
 func worldUpdated(_ frame:WorldFrame){self.frame=frame;if frame.time-savedAt>=4{savedAt=frame.time;game.saveWorld()}}
 func present(_ name:String){scene.clearInput();scene.isPaused=true;game.scene.bridge.call("worldPause",[true]);panel=name}
 func dismiss(){UIApplication.shared.isIdleTimerDisabled=true;panel="";dialog=nil;scene.isPaused=false;game.scene.bridge.call("worldPause",[false]);scene.clearInput();scene.refresh()}
 func action(_ type:String,id:String,element:String?=nil){
  var a:[String:Any]=["type":type,"id":id,"runId":UUID().uuidString];if let element{a["element"]=element}
  guard let r=game.actWorld(a) else{return};scene.selected=game.selected;scene.skin=game.actor.skin;scene.refresh()
  if let m=r.mission{scene.clearInput();game.beginWorldEncounter(m,runId:game.progress.world?.pending?.runId ?? "");return}
  if let d=r.dialog{dialog=d;present("story")}
  else if !r.ok{notice=r.message;present("notice")}
  else if type=="resonate"{if game.progress.world?.claimed.contains(id)==true{dismiss()}else{dialog=WorldDialogue(title:content.place(id)?.name ?? "共鸣碑",speaker:"共鸣机关",hero:region.hero,text:r.message,puzzle:id);present("story")}}
 }
 func cruise(){scene.clearInput();game.scene.bridge.call("worldCruise");scene.refresh()}
 func map(){game.saveWorld();mapRegion=frame?.region ?? "haven";pin=frame?.tracked ?? "haven-1";present("map")}
 func party(){present("party")}
 func pause(){UIApplication.shared.isIdleTimerDisabled=false;game.saveWorld();notice="位置与探索发现已保存。准备好后，继续沿着光前进。";present("paused")}
 func leave(){game.saveWorld();game.leaveWorld()}
 func selectMain(_ id:String){game.select(id);scene.selected=id;scene.skin=game.actor.skin;scene.refresh();game.scene.audio.setScene(state:"playing",boss:false);objectWillChange.send()}
 func selectSupport(_ id:String){game.selectSupport(id);objectWillChange.send()}
 var qa:String {let s:[String:Any]=["region":frame?.region ?? "","x":frame?.player.x ?? 0,"y":frame?.player.y ?? 0,"near":frame?.near ?? "","tracked":frame?.tracked ?? "","panel":panel,"explored":frame?.explored ?? 0,"claimed":game.progress.world?.claimed ?? [],"talked":game.progress.world?.talked ?? [],"tickets":game.progress.camp?.wallet["tickets"] ?? 0,"puzzles":game.progress.world?.puzzles ?? [:]];return (try? JSONSerialization.data(withJSONObject:s)).flatMap{String(data:$0,encoding:.utf8)} ?? "{}"}
}

struct WorldExplorerView:View {
 @ObservedObject var game:GameStore
 @StateObject private var world:WorldController
 @Environment(\.scenePhase) private var phase
 init(game:GameStore){self.game=game;_world=StateObject(wrappedValue:WorldController(game:game))}
 var body:some View{
  GeometryReader{g in surface(g)}.ignoresSafeArea()
   .onChange(of:phase){_,p in if p != .active{world.pause()}}
   .onDisappear{world.scene.clearInput();world.scene.isPaused=true}
 }
 private var qaProbe:some View {Text("QA").font(.system(size:7)).foregroundStyle(Color.clear).frame(width:2,height:2).accessibilityIdentifier("world-qa-state").accessibilityValue(world.qa).allowsHitTesting(false)}
 private func surface(_ g:GeometryProxy)->some View{
   let width=min(g.size.width,g.size.height*0.625)
   return ZStack{
    woInk.ignoresSafeArea()
    ZStack{
     SpriteView(scene:world.scene,preferredFramesPerSecond:60).accessibilityLabel("云海探索，单指拖动飞行").accessibilityIdentifier("world-scene")
     if let f=world.frame{hud(f).accessibilityHidden(!world.panel.isEmpty)}
     if !world.panel.isEmpty{panel}
     if NativeQA.enabled{qaProbe}
    }.frame(width:width,height:g.size.height).clipped()
   }.frame(maxWidth:.infinity,maxHeight:.infinity)
   .onAppear{world.open(height:Double(g.size.height/width*480))}
   .onChange(of:g.size){_,size in resize(size)}
 }
 private func resize(_ size:CGSize){let width=min(size.width,size.height*0.625);let height=Double(size.height/width*480);world.scene.resize(height)}
 private func art(_ name:String)->Image {Image(uiImage:UIImage(named:name) ?? UIImage())}
 private func button(_ text:String,id:String="",action:@escaping()->Void)->some View{Button(action:action){Text(text).font(.system(size:16,weight:.semibold)).frame(minHeight:46).padding(.horizontal,13).foregroundStyle(woGold).background(Color(hex:"17394c").opacity(0.95),in:RoundedRectangle(cornerRadius:9)).overlay(RoundedRectangle(cornerRadius:9).stroke(woGold.opacity(0.4),lineWidth:1))}.buttonStyle(.plain).accessibilityIdentifier(id)}
 private func hud(_ f:WorldFrame)->some View{
  let target=f.pois.first{$0.id==f.tracked},near=f.pois.first{$0.id==f.near}
  return VStack(spacing:0){
   VStack(alignment:.leading,spacing:7){HStack{VStack(alignment:.leading,spacing:4){Text("STARBORNE / 云海漫游").font(.system(size:10)).tracking(1.2).foregroundStyle(woMist);Text(world.region.name+" · \(f.explored)/\(f.total)").font(.system(size:23,weight:.medium,design:.serif)).foregroundStyle(woPaper)};Spacer(minLength:6);button("地图",id:"world-map",action:world.map);button("队伍",id:"world-party",action:world.party);button("营地",id:"world-exit",action:world.leave)};Text(f.objective).font(.system(size:14,weight:.medium)).foregroundStyle(woGold).accessibilityIdentifier("world-objective")}.padding(.horizontal,14).padding(.top,65).padding(.bottom,19).background(LinearGradient(colors:[woInk.opacity(0.98),woInk.opacity(0.7),.clear],startPoint:.top,endPoint:.bottom))
   Spacer()
   VStack(alignment:.leading,spacing:8){Text(f.message).font(.system(size:14)).foregroundStyle(woPaper).lineLimit(3).fixedSize(horizontal:false,vertical:true);HStack(spacing:8){button(f.cruise ? "停止巡航":"前往航标",id:"world-cruise",action:world.cruise);Button{if let near{world.action("interact",id:near.id)}}label:{Text(near.map{"互动 · "+$0.name} ?? "靠近地点互动").font(.system(size:17,weight:.semibold)).foregroundStyle(Color(hex:"244555")).frame(maxWidth:.infinity,minHeight:50).background(woGold,in:RoundedRectangle(cornerRadius:9))}.buttonStyle(.plain).disabled(near==nil).opacity(near==nil ? 0.6:1).accessibilityIdentifier("world-interact")};Text((target.map{$0.name+" · \($0.distance ?? 0) 米"} ?? "单指拖动探索")+"  |  "+world.region.weather).font(.system(size:12)).foregroundStyle(woMist)}.padding(.horizontal,16).padding(.top,22).padding(.bottom,40).background(LinearGradient(colors:[.clear,woInk.opacity(0.9),woInk],startPoint:.top,endPoint:.bottom))
  }
 }
 private var panel:some View{
  ZStack(alignment:.topTrailing){
   woInk.opacity(0.98).ignoresSafeArea()
   ScrollView{VStack(alignment:.leading,spacing:17){
    if world.panel=="map"{mapContent}
    else if world.panel=="party"{partyContent}
    else if world.panel=="story",let d=world.dialog{storyContent(d)}
    else{Text("云海手记").font(.system(size:13)).foregroundStyle(woMist);Text(world.panel=="paused" ? "云海，等你。":"沿着光，继续。").font(.system(size:31,weight:.medium,design:.serif)).foregroundStyle(woGold);Text(world.notice).font(.system(size:18)).lineSpacing(7).foregroundStyle(woPaper);button("继续探索",id:"world-notice-close",action:world.dismiss)}
   }.padding(.horizontal,22).padding(.top,120).padding(.bottom,50).frame(maxWidth:.infinity,alignment:.leading)}
   button("关闭面板",id:"world-panel-close",action:world.dismiss).padding(.top,61).padding(.trailing,17)
  }
 }
 private func storyContent(_ d:WorldDialogue)->some View{
  VStack(alignment:.leading,spacing:18){
   Text(d.speaker+" / "+world.region.subtitle).font(.system(size:13)).foregroundStyle(woMist)
   Text(d.title).font(.system(size:30,weight:.medium,design:.serif)).foregroundStyle(woGold)
   art(game.artName(d.hero,"healthy")).resizable().scaledToFit().frame(maxWidth:.infinity).frame(height:210).accessibilityLabel(d.speaker+"全身立绘")
   Text(d.text).font(.system(size:18)).lineSpacing(7).foregroundStyle(woPaper).fixedSize(horizontal:false,vertical:true).accessibilityIdentifier("world-story-text")
   if let id=d.puzzle{
    Text("共鸣 \(game.progress.world?.puzzles[id] ?? 0)/3 · 使用主战与支援的元素").font(.system(size:16)).foregroundStyle(woMist)
    HStack{ForEach(["crystal","thunder","tide"],id:\.self){e in button(game.content.elements[e]?.name ?? e,id:"world-element-\(e)"){world.action("resonate",id:id,element:e)}.disabled(![game.content.roles[game.selected]?.element,game.content.roles[game.support]?.element].contains(e)).opacity([game.content.roles[game.selected]?.element,game.content.roles[game.support]?.element].contains(e) ? 1:0.4)}}
    button("调整元素队伍",id:"world-puzzle-party",action:world.party)
   }else{button("继续探索",id:"world-story-close",action:world.dismiss)}
  }
 }
 private var partyContent:some View{
  VStack(alignment:.leading,spacing:18){Text("本机单人小队").font(.system(size:13)).foregroundStyle(woMist);Text("共鸣，从相遇开始。").font(.system(size:29,weight:.medium,design:.serif)).foregroundStyle(woGold);Text("主战与自动支援的元素可用于机关。战斗沿用角色等级、武器与命座。").font(.system(size:17)).foregroundStyle(woMist);Text("主战旅人").font(.system(size:19,weight:.semibold)).foregroundStyle(woPaper)
   LazyVGrid(columns:Array(repeating:GridItem(.flexible()),count:3),spacing:9){ForEach(game.travellers){t in Button{world.selectMain(t.id)}label:{VStack(spacing:7){art("\(t.id)-face").resizable().scaledToFit().frame(height:49);Text(t.name).font(.system(size:16));Text(game.content.elements[game.content.roles[t.id]?.element ?? ""]?.name ?? "").font(.system(size:13))}.foregroundStyle(game.selected==t.id ? woInk:woPaper).frame(maxWidth:.infinity,minHeight:108).background(game.selected==t.id ? woGold:Color(hex:"1b4053"),in:RoundedRectangle(cornerRadius:10))}.buttonStyle(.plain).accessibilityIdentifier("world-main-\(t.id)")}}
   Text("自动支援").font(.system(size:19,weight:.semibold)).foregroundStyle(woPaper)
   LazyVGrid(columns:Array(repeating:GridItem(.flexible()),count:3),spacing:9){ForEach(game.travellers.filter{$0.id != game.selected}){t in Button{world.selectSupport(t.id)}label:{VStack(spacing:7){Text(t.name).font(.system(size:16));Text(game.content.elements[game.content.roles[t.id]?.element ?? ""]?.name ?? "").font(.system(size:13))}.foregroundStyle(game.support==t.id ? woInk:woPaper).frame(maxWidth:.infinity,minHeight:70).background(game.support==t.id ? woGold:Color(hex:"1b4053"),in:RoundedRectangle(cornerRadius:10))}.buttonStyle(.plain).accessibilityIdentifier("world-support-\(t.id)")}}
   button("带着这支队伍出发",id:"world-party-done",action:world.dismiss)
  }
 }
 private var mapContent:some View{
  let r=world.content.region(world.mapRegion),w=game.progress.world,unlocked=w?.unlocked.contains(r.id)==true
  return VStack(alignment:.leading,spacing:16){
   Text("星图 / "+r.subtitle).font(.system(size:13)).foregroundStyle(woMist);Text(r.name).font(.system(size:31,weight:.medium,design:.serif)).foregroundStyle(woGold)
   HStack(spacing:7){ForEach(world.content.regions){reg in Button{world.mapRegion=reg.id;world.pin=reg.id+"-1"}label:{Text((w?.unlocked.contains(reg.id)==true ? "":"🔒 ")+reg.name).font(.system(size:14,weight:.medium)).foregroundStyle(world.mapRegion==reg.id ? woInk:woPaper).frame(maxWidth:.infinity,minHeight:48).background(world.mapRegion==reg.id ? woGold:Color(hex:"1c4053"),in:RoundedRectangle(cornerRadius:8))}.buttonStyle(.plain).accessibilityIdentifier("world-region-\(reg.id)")}}
   Text(r.weather+" · "+r.mechanic+"\n区域掉落："+r.drop).font(.system(size:16)).foregroundStyle(woMist).lineSpacing(5)
   if unlocked{
    WorldMapCanvas(world:world,region:r.id,discovered:w?.discovered ?? [],tiles:w?.tiles ?? [])
    if let p=world.content.place(world.pin),p.region==r.id{VStack(alignment:.leading,spacing:11){Text(p.name).font(.system(size:21,weight:.medium)).foregroundStyle(woGold);button("标记并返回探索",id:"world-pin-go"){world.action("track",id:p.id);world.dismiss()}.disabled(r.id != world.frame?.region);if w?.beacons.contains(p.id)==true{button("传送到已点亮航标",id:"world-travel"){world.action("travel",id:p.id);world.dismiss()}}}.padding(15).frame(maxWidth:.infinity,alignment:.leading).background(Color(hex:"1a3d50"),in:RoundedRectangle(cornerRadius:12))}
   }else{Text("完成上一章守望者，再沿北方航门抵达。首次抵达后可点亮营地航标。").font(.system(size:18)).foregroundStyle(woMist).lineSpacing(7).padding(.vertical,45)}
   DisclosureGroup("主线与支线手记"){VStack(alignment:.leading,spacing:15){Text(w?.cleared.contains(r.id+"-10")==true ? r.ending:r.intro);Text(r.sideTitle+"："+(w?.sideDone.contains(r.id)==true ? "已完成":r.sideText));if w?.claimed.contains(r.id+"-4")==true{Text(r.lore)};if w?.claimed.contains(r.id+"-11")==true{Text(r.vista)}}.font(.system(size:17)).lineSpacing(6).foregroundStyle(woMist).padding(.top,13)}.font(.system(size:19)).tint(woGold).foregroundStyle(woPaper)
  }
 }
}
private struct WorldMapCanvas:View {
 @ObservedObject var world:WorldController
 let region:String,discovered,tiles:[String]
 var body:some View{
  GeometryReader{g in
   ZStack(alignment:.topLeading){
    Image(uiImage:UIImage(named:"world-\(region)") ?? UIImage()).resizable().scaledToFill().frame(width:g.size.width,height:g.size.height).clipped()
    Canvas{c,size in for x in 0..<8{for y in 0..<11{if !tiles.contains("\(region):\(x):\(y)"){c.fill(Path(CGRect(x:Double(x)*size.width/8,y:Double(y)*size.height/11,width:size.width/8+1,height:size.height/11+1)),with:.color(woInk.opacity(0.37)))}}}}.allowsHitTesting(false)
    ForEach(world.content.pois.filter{$0.region==region}){p in
     let known=discovered.contains(p.id)||["camp","npc","puzzle","boss","portal"].contains(p.type)
     Button{world.pin=p.id}label:{VStack(spacing:1){Text(known ? p.icon:"?").font(.system(size:20)).foregroundStyle(world.pin==p.id ? woInk:woGold).frame(width:34,height:34).background(world.pin==p.id ? woGold:woInk.opacity(0.95),in:Circle());Text(known ? p.name:"未知发现").font(.system(size:10,weight:.semibold)).foregroundStyle(woPaper).shadow(color:woInk,radius:2).fixedSize()}}.buttonStyle(.plain).position(x:p.x/1600*g.size.width,y:p.y/2200*g.size.height).accessibilityLabel(known ? p.name:"未知发现").accessibilityIdentifier("world-pin-\(p.id)")
    }
    if let f=world.frame,f.region==region{Text("▲").font(.system(size:22,weight:.bold)).foregroundStyle(Color(hex:"9fe5ed")).shadow(color:woInk,radius:2).position(x:f.player.x/1600*g.size.width,y:f.player.y/2200*g.size.height).allowsHitTesting(false)}
   }.clipShape(RoundedRectangle(cornerRadius:12))
  }.aspectRatio(1600.0/2200.0,contentMode:.fit)
 }
}
