import SpriteKit
import UIKit
protocol WorldSceneObserver:AnyObject {func worldUpdated(_ frame:WorldFrame)}
final class WorldScene:SKScene {
 weak var observer:WorldSceneObserver?
 let bridge:GameBridge
 private let diagnostics=NativeDiagnostics()
 private var terrain=SKSpriteNode(),hero=SKSpriteNode(),shadow=SKSpriteNode(),marker=SKLabelNode(fontNamed:"AvenirNext-Bold")
 private var places:[String:SKNode]=[:],icons:[String:SKTexture]=[:]
 private var lastTime=0.0,lastNotice=0.0,currentRegion="",heroKey=""
 var selected="lune",skin="base"
 private var target:CGPoint?,activeTouch:UITouch?,lastTouch:CGPoint?
 private(set) var worldFrame:WorldFrame?
 init(bridge:GameBridge){self.bridge=bridge;super.init(size:CGSize(width:480,height:900));scaleMode = .aspectFill;isUserInteractionEnabled=true;backgroundColor=UIColor(hex:"1b5261");terrain.anchorPoint=CGPoint(x:0,y:1);terrain.zPosition=0;terrain.size=CGSize(width:1600,height:2200);addChild(terrain);shadow.color=UIColor.black.withAlphaComponent(0.25);shadow.size=CGSize(width:46,height:12);shadow.zPosition=20;addChild(shadow);hero.zPosition=25;hero.size=CGSize(width:86,height:108);addChild(hero);marker.text="➤";marker.fontSize=30;marker.fontColor=UIColor(hex:"ffe0a0");marker.zPosition=30;addChild(marker);prepareIcons()}
 required init?(coder:NSCoder){fatalError("Use init(bridge:)")}
 private func prepareIcons(){for p in WorldContent.shared.pois{if icons[p.type] != nil{continue};let renderer=UIGraphicsImageRenderer(size:CGSize(width:56,height:56));let image=renderer.image{c in let rect=CGRect(x:3,y:3,width:50,height:50);UIColor(hex:"19394e").withAlphaComponent(0.95).setFill();UIBezierPath(ovalIn:rect).fill();UIColor(hex:"efd5a0").setStroke();let ring=UIBezierPath(ovalIn:rect);ring.lineWidth=2;ring.stroke();let text=NSAttributedString(string:p.icon,attributes:[.font:UIFont.systemFont(ofSize:30,weight:.medium),.foregroundColor:UIColor(hex:"ffedbe")]);let s=text.size();text.draw(at:CGPoint(x:(56-s.width)/2,y:(56-s.height)/2))};icons[p.type]=SKTexture(image:image)}}
 func open(_ raw:String,height:Double){bridge.call("worldResize",[height]);if let next=decode(bridge.call("worldOpen",[raw,["height":height]])?.toString()){worldFrame=next;lastTime=0;lastNotice=0;render(next);observer?.worldUpdated(next)}}
 func resize(_ height:Double){size.height=CGFloat(max(640,min(1400,height)));bridge.call("worldResize",[Double(size.height)]);clearInput()}
 func clearInput(){activeTouch=nil;lastTouch=nil;target=nil}
 func refresh(){if let next=decode(bridge.call("worldStep",[0])?.toString()){worldFrame=next;render(next);observer?.worldUpdated(next)}}
 private func decode(_ raw:String?)->WorldFrame?{guard let raw else{return nil};return try? JSONDecoder().decode(WorldFrame.self,from:Data(raw.utf8))}
 override func update(_ time:TimeInterval){let begin=CACurrentMediaTime(),dt=lastTime==0 ? 0:min(0.05,time-lastTime);lastTime=time;let input:[String:Any]=target.map{["target":["x":Double($0.x),"y":Double($0.y)]]} ?? [:];guard let next=decode(bridge.call("worldStep",[dt,input])?.toString()) else{return};let engineEnd=CACurrentMediaTime();worldFrame=next;render(next);let renderEnd=CACurrentMediaTime();if time-lastNotice>0.12{lastNotice=time;observer?.worldUpdated(next)};diagnostics.sampleWorld(time:time,engineMS:(engineEnd-begin)*1000,renderMS:(renderEnd-engineEnd)*1000,observerMS:(CACurrentMediaTime()-renderEnd)*1000,scene:self,frame:next)}
 private func render(_ f:WorldFrame){
  if currentRegion != f.region{currentRegion=f.region;terrain.texture=SKTexture(imageNamed:"world-\(f.region)");for n in places.values{n.removeFromParent()};places.removeAll()}
  let h=Double(size.height),cx=f.camera.x,cy=f.camera.y
  terrain.position=CGPoint(x:-cx,y:h+cy)
  for p in f.pois{let node:SKNode;if let old=places[p.id]{node=old}else{node=SKNode();let icon=SKSpriteNode(texture:icons[p.type]);icon.size=CGSize(width:48,height:48);node.addChild(icon);let name=SKLabelNode(fontNamed:"PingFangSC-Medium");name.name="title";name.fontSize=15;name.fontColor=UIColor(hex:"fff0ca");name.position=CGPoint(x:0,y:-43);name.verticalAlignmentMode = .bottom;node.addChild(name);node.zPosition=10;addChild(node);places[p.id]=node};node.position=CGPoint(x:p.x-cx,y:h-(p.y-cy));node.alpha=p.done==true ? 0.55:1;node.isHidden=p.x-cx < -100 || p.x-cx>580 || p.y-cy < -100 || p.y-cy>h+100;(node.childNode(withName:"title") as? SKLabelNode)?.text=(p.discovered==true || ["npc","boss","puzzle","portal"].contains(p.type)) ? p.name:"未知发现";node.setScale(f.tracked==p.id ? 1.08+sin(f.time*3)*0.04:1)}
  let bank=f.player.bank ?? 0,pose=bank < -0.25 ? 1:bank>0.25 ? 2:0,key=skin=="base" ? "\(selected)-\(pose)":"skin-\(skin)-\(pose)";if key != heroKey{heroKey=key;hero.texture=SKTexture(imageNamed:key)}
  hero.position=CGPoint(x:f.player.x-cx,y:h-(f.player.y-cy)+sin(f.time*2)*3);hero.zRotation = -bank*0.08;shadow.position=CGPoint(x:hero.position.x,y:hero.position.y-25)
  if let t=f.pois.first(where:{$0.id==f.tracked}),(t.distance ?? 0)>130{marker.isHidden=false;marker.position=CGPoint(x:max(35,min(445,t.x-cx)),y:h-max(165,min(h-190,t.y-cy)));marker.zRotation = -atan2(t.y-f.player.y,t.x-f.player.x)}else{marker.isHidden=true}
 }
 override func touchesBegan(_ touches:Set<UITouch>,with event:UIEvent?){guard activeTouch==nil,let t=touches.first,let f=worldFrame else{return};activeTouch=t;lastTouch=t.location(in:self);target=CGPoint(x:f.player.x,y:f.player.y);if f.cruise{bridge.call("worldCruise")}}
 override func touchesMoved(_ touches:Set<UITouch>,with event:UIEvent?){guard let t=activeTouch,touches.contains(t),let before=lastTouch,var dest=target else{return};let p=t.location(in:self);dest.x=max(80,min(1520,dest.x+(p.x-before.x)*1.12));dest.y=max(100,min(2100,dest.y-(p.y-before.y)*1.12));target=dest;lastTouch=p}
 override func touchesEnded(_ touches:Set<UITouch>,with event:UIEvent?){if let t=activeTouch,touches.contains(t){clearInput()}}
 override func touchesCancelled(_ touches:Set<UITouch>,with event:UIEvent?){clearInput()}
}
