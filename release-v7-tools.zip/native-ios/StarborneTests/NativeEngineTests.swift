import XCTest
import UIKit
import AVFoundation
@testable import Starborne
final class NativeEngineTests:XCTestCase {
    func testAudioSubmissionDoesNotBlockTheFrameThread() {
        let audio=NativeAudio(),start=CFAbsoluteTimeGetCurrent()
        for _ in 0..<100{audio.play("shot")}
        XCTAssertLessThan((CFAbsoluteTimeGetCurrent()-start)*1000,16.7,"Submitting cached effects must fit in one 60 Hz frame; playback belongs off the frame thread")
    }
    func testViewportResizePreservesPlayerResources() throws {
        let bridge=try GameBridge()
        _=try bridge.reset(character:"lune",hard:true,height:1000,seed:42)
        _=bridge.call("bomb");let before=try bridge.step(1/60,target:nil)
        let after=try bridge.frame(bridge.call("resize",[720]))
        XCTAssertEqual(after.worldHeight,720)
        XCTAssertEqual(after.player.bombs,before.player.bombs)
        XCTAssertEqual(after.player.lives,before.player.lives)
        XCTAssertEqual(after.score,before.score)
        XCTAssertEqual(after.hard,true)
        XCTAssertEqual(after.elapsed,before.elapsed)
    }
    func testSharedRulesAndTouchGesture() throws {
        let bridge=try GameBridge()
        let first=try bridge.reset(character:"aster",hard:false,height:1000,seed:42)
        XCTAssertEqual(first.player.weapon,"homing");XCTAssertEqual(first.player.lives,3);XCTAssertEqual(first.player.bombs,2)
        XCTAssertEqual(first.enemies.count,5)
        _=bridge.call("touchBegin",[40,600,0]);XCTAssertFalse(bridge.call("touchEnd",[40,600,50])!.toBool())
        _=bridge.call("touchBegin",[40,600,150]);XCTAssertTrue(bridge.call("touchEnd",[40,600,200])!.toBool())
        XCTAssertTrue(bridge.call("bomb")!.toBool());XCTAssertFalse(bridge.call("bomb")!.toBool())
        let next=try bridge.step(1/60,target:nil);XCTAssertEqual(next.player.bombs,1);XCTAssertTrue(next.events.contains{$0.type=="bomb"&&$0.lives==3})
        _=bridge.call("pause");let before=bridge.call("debugState")!.toString()
        for _ in 0..<60{_=try bridge.step(1/60,target:nil)}
        XCTAssertEqual(bridge.call("debugState")!.toString(),before)
    }
    func testComposedMusicAndVariedEffectsAreBundled()throws {
        for name in ["voyage","guardian"]{
            let url=try XCTUnwrap(Bundle.main.url(forResource:name,withExtension:"m4a"))
            let player=try AVAudioPlayer(contentsOf:url);XCTAssertGreaterThan(player.duration,60)
        }
        for name in ["shot","shot-2","shot-3","kill","kill-2","kill-3","heal","powerup"]{
            let url=try XCTUnwrap(Bundle.main.url(forResource:name,withExtension:"wav"));let f=try AVAudioFile(forReading:url);XCTAssertGreaterThan(f.length,100)
        }
        let b=try GameBridge();_=try b.reset(character:"ember",hard:true,height:1000,seed:42)
        let f=try b.frame(b.call("benchmark",[["power":6,"stage":2]]))
        XCTAssertEqual(f.player.power,6);XCTAssertEqual(f.stageIndex,2);XCTAssertGreaterThan(f.threatLevel,2);XCTAssertEqual(f.player.lives,3)
    }
    func testExpeditionDraftAndLocalSettlement()throws {
        let b=try GameBridge();_=try b.reset(character:"lune",hard:false,height:1000,seed:42,support:"nerine")
        let draft=try b.frame(b.call("benchmark",[["draft":true]]))
        XCTAssertEqual(draft.state,"draft");XCTAssertEqual(draft.expedition?.draft.count,3)
        _=try b.step(0,target:nil)
        let before=b.call("debugState")!.toString()
        for _ in 0..<60{_=try b.step(1/60,target:CGPoint(x:40,y:400))}
        XCTAssertEqual(b.call("debugState")!.toString(),before)
        XCTAssertFalse(b.call("choose",["forged"])!.toBool())
        let choice=try XCTUnwrap(draft.expedition?.draft.first?.id)
        XCTAssertTrue(b.call("choose",[choice])!.toBool());XCTAssertFalse(b.call("choose",[choice])!.toBool())
        let resumed=try b.step(1/60,target:nil);XCTAssertEqual(resumed.expedition?.choiceCount,1);XCTAssertEqual(resumed.state,"playing")
        _=b.call("benchmark",[["finish":true]])
        let raw=try XCTUnwrap(b.call("settle",["{}"])?.toString()),p=FlightProgress.decode(raw)
        XCTAssertEqual(p.runs,1);XCTAssertGreaterThan(p.heroes["lune"]?.xp ?? 0,p.heroes["nerine"]?.xp ?? 0)
        XCTAssertEqual(b.call("settle",[raw])?.toString(),raw)
        XCTAssertEqual(FlightProgress.decode(b.call("profile",["broken"])!.toString()).runs,0)
    }
    func testPermanentTrialStartsWithFixedSquadAndArmor()throws {
        let b=try GameBridge(),content=ExpeditionContent.shared
        XCTAssertEqual(content.trials.count,3);XCTAssertEqual(content.memories.count,6)
        let f=try b.reset(character:"sol",hard:false,height:1000,seed:1,support:"ember",trial:"fracture",talent:"signature")
        XCTAssertEqual(f.character,"ember");XCTAssertEqual(f.expedition?.support,"vesper");XCTAssertEqual(f.expedition?.talent,"balanced");XCTAssertTrue(f.hard)
        for memories in content.memories.values{XCTAssertEqual(memories.count,3)}
    }
    func testCollectionTransactionsAndCosmeticsUseSharedSavedState()throws {
        let b=try GameBridge(),raw=try XCTUnwrap(b.call("profile",["{}"] )?.toString())
        XCTAssertEqual(FlightProgress.decode(raw).camp?.wallet["tickets"],30)
        func transact(_ raw:String,_ action:[String:Any])throws->String {
            let r=try XCTUnwrap(b.call("camp",[raw,action])?.toString()),obj=try XCTUnwrap(JSONSerialization.jsonObject(with:Data(r.utf8)) as? [String:Any]);XCTAssertEqual(obj["ok"] as? Bool,true)
            return String(data:try JSONSerialization.data(withJSONObject:try XCTUnwrap(obj["profile"])),encoding:.utf8)!
        }
        var saved=try transact(raw,["type":"wish","pool":"weapon","count":10])
        XCTAssertEqual(FlightProgress.decode(saved).camp?.wallet["tickets"],20)
        XCTAssertEqual(FlightProgress.decode(saved).camp?.weapons.count,16)
        saved=try transact(saved,["type":"levelHero","hero":"lune"])
        saved=try transact(saved,["type":"skin","hero":"lune","skin":"moonlit"])
        let camp=FlightProgress.decode(saved).camp;XCTAssertEqual(camp?.actors["lune"]?.level,2);XCTAssertEqual(camp?.wallet["threads"],15)
        let f=try b.reset(character:"lune",hard:false,height:1000,seed:42,campRaw:saved);XCTAssertEqual(f.expedition?.skin,"moonlit");XCTAssertEqual(f.player.power,1);XCTAssertEqual(f.player.lives,3)
        for skin in CollectionContent.shared.skins{for suffix in ["healthy","wounded","critical","0","1","2","3"]{XCTAssertNotNil(UIImage(named:"skin-\(skin.id)-\(suffix)"))}}
        for w in CollectionContent.shared.weapons{XCTAssertNotNil(UIImage(named:"weapon-\(w.id)"))}
    }
    func testAllOriginalHealthPortraitsAreBundled() throws {
        XCTAssertEqual(Traveller.load().count,6)
        for id in ["ember","lune","nerine","sol","vesper","aster"]{
            for tier in ["healthy","wounded","critical"]{
                let image=try XCTUnwrap(UIImage(named:"\(id)-\(tier)"));XCTAssertEqual(image.size,CGSize(width:512,height:1024))
            }
            for pose in 0..<4{XCTAssertNotNil(UIImage(named:"\(id)-\(pose)"))}
        }
    }
    func testWorldExplorationUsesLocalDistanceAndPersistsDialogue()throws {
        let b=try GameBridge(),raw=try XCTUnwrap(b.call("profile",["{}"] )?.toString())
        let first=try XCTUnwrap(b.call("worldOpen",[raw,["height":900]])?.toString())
        XCTAssertEqual(try JSONDecoder().decode(WorldFrame.self,from:Data(first.utf8)).region,"haven")
        let remote=try XCTUnwrap(b.call("worldAct",[raw,["type":"interact","id":"haven-2"],["main":"lune","support":"nerine"]])?.toString())
        XCTAssertFalse(try JSONDecoder().decode(WorldActionResult.self,from:Data(remote.utf8)).ok)
        b.call("worldCruise")
        for _ in 0..<120{b.call("worldStep",[1.0/60.0])}
        let stopped=try XCTUnwrap(b.call("worldStep",[0])?.toString());XCTAssertFalse(try JSONDecoder().decode(WorldFrame.self,from:Data(stopped.utf8)).cruise)
        let result=try XCTUnwrap(b.call("worldAct",[raw,["type":"interact","id":"haven-1"],["main":"lune","support":"nerine"]])?.toString()),r=try JSONDecoder().decode(WorldActionResult.self,from:Data(result.utf8))
        XCTAssertTrue(r.ok);XCTAssertEqual(r.dialog?.title,"失踪的风图");XCTAssertTrue(r.profile.world?.talked.contains("haven-1")==true)
        let saved=try XCTUnwrap(b.call("worldSave",[raw])?.toString());XCTAssertTrue(FlightProgress.decode(saved).world?.talked.contains("haven-1")==true)
        XCTAssertEqual(WorldContent.shared.regions.count,3);XCTAssertEqual(WorldContent.shared.pois.count,39)
        for region in WorldContent.shared.regions{XCTAssertNotNil(UIImage(named:"world-\(region.id)"));XCTAssertNotNil(UIImage(named:"world-battle-\(region.id)"))}
    }
    func testRegionalEncounterReturnsToPersistedWorldWithoutClearingOnAbandon()throws {
        let b=try GameBridge(),raw=try XCTUnwrap(b.call("profile",["{}"] )?.toString())
        b.call("worldOpen",[raw])
        for _ in 0..<40{b.call("worldStep",[0.05,["target":["x":1150,"y":800]]])}
        let action=try XCTUnwrap(b.call("worldAct",[raw,["type":"interact","id":"haven-9","runId":"native-world"],["main":"lune","support":"nerine"]])?.toString()),a=try JSONDecoder().decode(WorldActionResult.self,from:Data(action.utf8));XCTAssertTrue(a.ok);XCTAssertEqual(a.mission?.region,"haven")
        let saved=try XCTUnwrap(b.call("worldSave",[raw])?.toString()),f=try b.reset(character:"lune",hard:false,height:900,seed:42,campRaw:saved,worldMission:"haven-9",runId:"native-world")
        XCTAssertEqual(f.stage.region,"haven");XCTAssertEqual(f.stage.name,"巡空哨站");XCTAssertEqual(f.player.lives,3);XCTAssertEqual(f.player.bombs,2)
        b.call("abandon");let after=try XCTUnwrap(b.call("settle",[saved])?.toString()),p=FlightProgress.decode(after);XCTAssertNil(p.world?.pending);XCTAssertFalse(p.world?.cleared.contains("haven-9")==true);XCTAssertEqual(b.call("settle",[after])?.toString(),after)
    }
}
