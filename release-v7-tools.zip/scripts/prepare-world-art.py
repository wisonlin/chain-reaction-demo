"""Prepare the three imagegen world paintings; no creative art is synthesized here."""
from pathlib import Path
from PIL import Image
import base64,json,hashlib
R=Path(__file__).resolve().parents[1];P=R/'assets/world-v7';assets={};manifest=[]
for region in ['haven','lagoon','ruins']:
 source=P/'source'/f'{region}.png';im=Image.open(source).convert('RGB');assert im.height>im.width
 image=im.resize((1200,1650),Image.Resampling.LANCZOS)
 path=P/f'world-{region}.webp';image.save(path,quality=89,method=6)
 assets[region]='data:image/webp;base64,'+base64.b64encode(path.read_bytes()).decode()
 # A narrower environmental crop reads at combat scale, while the original
 # geography remains available in the freely scrolling overworld.
 w,h=im.size;combat=im.crop((int(w*.2),int(h*.16),int(w*.8),int(h*.86))).resize((480,720),Image.Resampling.LANCZOS)
 edge=48;top=combat.crop((0,0,480,edge));bottom=combat.crop((0,720-edge,480,720));seam=Image.blend(top,bottom,.5);combat.paste(seam,(0,0));combat.paste(seam,(0,720-edge))
 battle=P/f'world-battle-{region}.webp';combat.save(battle,quality=89,method=6)
 assets['battle-'+region]='data:image/webp;base64,'+base64.b64encode(battle.read_bytes()).decode()
 for file in [path,battle]:
  check=Image.open(file);check.load();manifest.append({'file':file.name,'width':check.width,'height':check.height,'bytes':file.stat().st_size,'sha256':hashlib.sha256(file.read_bytes()).hexdigest()})
module=R/'src/world-assets.js';pending=module.with_suffix('.pending.js');pending.write_text('export const WORLD_ART='+json.dumps(assets,separators=(',',':'))+';\n');pending.replace(module)
(P/'manifest.json').write_text(json.dumps({'method':'Built-in image_gen; deterministic Pillow preparation','assets':manifest},indent=2)+'\n')
print('Validated three complete world paintings and three bundled combat terrain crops.')
